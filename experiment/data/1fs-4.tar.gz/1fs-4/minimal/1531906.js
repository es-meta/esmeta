"use strict";
[ ] . flatMap ( [ ] ) ; 
