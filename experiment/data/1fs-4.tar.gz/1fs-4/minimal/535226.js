"use strict";
0n . isPrototypeOf ( { } ) ; 
