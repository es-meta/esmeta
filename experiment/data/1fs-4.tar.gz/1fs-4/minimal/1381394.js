"use strict";
Array . prototype . splice ( ~ typeof x ) ; 
