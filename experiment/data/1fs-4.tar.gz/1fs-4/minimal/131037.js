"use strict";
String . prototype . repeat ( null ) ; 
