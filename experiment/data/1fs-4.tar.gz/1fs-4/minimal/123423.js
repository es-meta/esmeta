"use strict";
Symbol ( [ ] ) ; 
