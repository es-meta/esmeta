"use strict";
new Uint16Array ( x => x ) ; 
