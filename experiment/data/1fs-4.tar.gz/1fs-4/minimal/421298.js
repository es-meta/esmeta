"use strict";
[ ] . findLast . call ( true ) ; 
