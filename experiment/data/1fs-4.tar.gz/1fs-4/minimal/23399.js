"use strict";
String . prototype . startsWith . call ( null ) ; 
