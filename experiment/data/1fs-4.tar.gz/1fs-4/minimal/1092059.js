"use strict";
[ ] . forEach . call ( 0n ) ; 
