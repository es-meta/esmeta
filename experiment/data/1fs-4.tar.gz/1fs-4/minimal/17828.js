"use strict";
new Function ( 1n ) ; 
