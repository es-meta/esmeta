"use strict";
[ ] . toLocaleString . call ( '' ) ; 
