"use strict";
Array . prototype . join . call ( typeof x ) ; 
