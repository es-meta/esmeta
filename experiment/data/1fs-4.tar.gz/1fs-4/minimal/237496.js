"use strict";
String . prototype . matchAll ( ) ; 
