"use strict";
[ ] . reverse . call ( typeof x ) ; 
