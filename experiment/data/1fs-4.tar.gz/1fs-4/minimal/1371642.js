"use strict";
`` . __lookupGetter__ . call ( null ) ; 
