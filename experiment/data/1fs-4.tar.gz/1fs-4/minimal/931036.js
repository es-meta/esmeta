"use strict";
`` . replaceAll ( 0n ) ; 
