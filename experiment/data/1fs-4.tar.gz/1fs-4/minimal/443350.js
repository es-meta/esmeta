"use strict";
[ ] . some . call ( true ) ; 
