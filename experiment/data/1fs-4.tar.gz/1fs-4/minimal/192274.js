"use strict";
BigInt . asUintN . call ( 0 , 0 , 0n ) ; 
