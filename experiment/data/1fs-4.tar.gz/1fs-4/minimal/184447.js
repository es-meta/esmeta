"use strict";
String . prototype . slice ( ) ; 
