"use strict";
Math . asin ( 1 ) ; 
