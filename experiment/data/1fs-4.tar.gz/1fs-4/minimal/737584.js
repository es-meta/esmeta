"use strict";
'' . startsWith ( null ) ; 
