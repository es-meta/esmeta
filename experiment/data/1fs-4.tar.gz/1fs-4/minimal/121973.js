"use strict";
Math . cosh ( [ ] ) ; 
