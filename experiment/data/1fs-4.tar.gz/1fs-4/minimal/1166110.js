"use strict";
[ , ] . findLastIndex ( x => null ) ; 
