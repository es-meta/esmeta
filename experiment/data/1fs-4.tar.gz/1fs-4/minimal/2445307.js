"use strict";
Iterator . prototype . drop ( { [ Symbol . toPrimitive ] : function ( ) { } } ) ; 
