"use strict";
true . isPrototypeOf ( [ ] ) ; 
