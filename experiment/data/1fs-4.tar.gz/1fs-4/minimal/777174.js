"use strict";
[ ] . pop . call ( true ) ; 
