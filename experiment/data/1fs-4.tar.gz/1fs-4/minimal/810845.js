"use strict";
Math . acosh ( [ ] ) ; 
