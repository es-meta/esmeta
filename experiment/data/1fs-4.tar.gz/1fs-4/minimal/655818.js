"use strict";
Array . fromAsync . call ( function ( ) { x ; } , `` ) ; 
