"use strict";
String . prototype . replace . call ( 0 , 0 , '' ) ; 
