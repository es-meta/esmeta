"use strict";
[ ] . toSorted . call ( true ) ; 
