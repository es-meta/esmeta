"use strict";
Object . getOwnPropertyNames ( this ) ; 
