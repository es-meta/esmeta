"use strict";
[ , ] . find ( x => null ) ; 
