"use strict";
`` . matchAll ( { [ Symbol . match ] : '' } ) ; 
