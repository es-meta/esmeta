"use strict";
Array . prototype . find . call ( 1n ) ; 
