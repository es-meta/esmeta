"use strict";
Object . hasOwn ( 0 , false ) ; 
