"use strict";
'' . endsWith ( 1 ) ; 
