"use strict";
Math . acos ( [ ] ) ; 
