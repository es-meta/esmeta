"use strict";
'' . slice . call ( false ) ; 
