"use strict";
[ ] . at ( x => x ) ; 
