"use strict";
new Error ( 0n ) ; 
