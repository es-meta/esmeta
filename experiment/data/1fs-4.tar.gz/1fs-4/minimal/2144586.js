"use strict";
[ ] . splice ( x => x , 1 ) ; 
