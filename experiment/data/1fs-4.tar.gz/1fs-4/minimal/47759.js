"use strict";
String . prototype . endsWith ( ) ; 
