"use strict";
parseInt ( true ) ; 
