"use strict";
`` . charCodeAt ( x => x ) ; 
