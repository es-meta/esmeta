"use strict";
[ ] . copyWithin ( `` , 1n ) ; 
