"use strict";
`` . matchAll ( { [ Symbol . match ] : 1 } ) ; x ; 
