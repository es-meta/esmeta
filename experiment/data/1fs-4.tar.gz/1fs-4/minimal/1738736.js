"use strict";
[ ] . toReversed . call ( `${ x => x }` ) ; 
