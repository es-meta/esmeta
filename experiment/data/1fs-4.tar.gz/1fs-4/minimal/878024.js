"use strict";
Object . groupBy ( 0n , x => x ) ; 
