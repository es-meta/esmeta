"use strict";
Math . min ( null ) ; 
