"use strict";
BigInt . asIntN ( { } ) ; 
