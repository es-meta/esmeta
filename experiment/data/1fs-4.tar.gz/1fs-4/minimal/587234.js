"use strict";
Math . tan ( { } ) ; 
