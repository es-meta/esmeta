"use strict";
Array . prototype . find . call ( null ) ; 
