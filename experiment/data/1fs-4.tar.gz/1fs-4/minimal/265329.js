"use strict";
[ , ] . reduce ( ) ; 
