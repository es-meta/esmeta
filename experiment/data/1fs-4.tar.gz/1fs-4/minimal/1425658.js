"use strict";
Math . log ( { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
