"use strict";
Object . getOwnPropertySymbols ( 1n ) ; 
