"use strict";
[ , ] . findLast ( x => 1 ) ; 
