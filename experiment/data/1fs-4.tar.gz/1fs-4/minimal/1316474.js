"use strict";
async function * x ( ) { } Array . fromAsync ( async function * ( ) { yield * x ( ) ; } ( ) ) ; 
