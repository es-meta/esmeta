"use strict";
[ ] . findIndex . call ( ) ; 
