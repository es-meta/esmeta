"use strict";
[ ] . keys . call ( '' ) ; 
