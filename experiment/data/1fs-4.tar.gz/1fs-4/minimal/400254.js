"use strict";
0 . __defineSetter__ ( `` , x => x ) ; 
