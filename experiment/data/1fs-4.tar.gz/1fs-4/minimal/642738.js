"use strict";
Reflect . set . call ( 0 , [ ] , true ) ; 
