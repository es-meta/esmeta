"use strict";
[ ] . unshift . call ( 1 ) ; 
