"use strict";
Reflect . deleteProperty . call ( 0 , { } , [ ] ) ; 
