"use strict";
`` . replaceAll . call ( { } ) ; 
