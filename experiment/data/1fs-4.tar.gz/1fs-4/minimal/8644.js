"use strict";
[ ] . concat . call ( 1n ) ; 
