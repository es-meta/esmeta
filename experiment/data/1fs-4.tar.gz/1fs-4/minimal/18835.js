"use strict";
String . prototype . trimStart . call ( null ) ; 
