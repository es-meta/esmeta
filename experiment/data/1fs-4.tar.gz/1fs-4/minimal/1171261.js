"use strict";
[ , ] . findLastIndex ( x => 0 ) ; 
