"use strict";
Map . groupBy ( { [ Symbol . iterator ] : '' } , x => x ) ; 
