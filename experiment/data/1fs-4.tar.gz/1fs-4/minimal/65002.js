"use strict";
Object . values ( 1n ) ; 
