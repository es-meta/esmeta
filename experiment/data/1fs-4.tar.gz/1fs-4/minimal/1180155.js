"use strict";
String . prototype . codePointAt ( true ) ; 
