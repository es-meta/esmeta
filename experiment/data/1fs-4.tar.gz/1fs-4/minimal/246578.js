"use strict";
isNaN ( [ , , ] ) ; 
