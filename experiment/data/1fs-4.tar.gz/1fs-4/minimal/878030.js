"use strict";
Object . groupBy ( '' , x => x ) ; 
