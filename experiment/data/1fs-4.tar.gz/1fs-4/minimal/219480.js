"use strict";
'' . propertyIsEnumerable ( '' ) ; 
