"use strict";
true . __defineSetter__ ( ) ; 
