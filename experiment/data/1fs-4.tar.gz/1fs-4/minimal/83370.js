"use strict";
new SyntaxError ( `` ) ; 
