"use strict";
[ ] . entries . call ( null ) ; 
