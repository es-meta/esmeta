"use strict";
String . prototype . charCodeAt . call ( 1n ) ; 
