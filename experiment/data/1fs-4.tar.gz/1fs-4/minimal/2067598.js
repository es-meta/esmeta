"use strict";
Object . groupBy ( { [ Symbol . iterator ] : async function * ( ) { } } , x => x ) ; 
