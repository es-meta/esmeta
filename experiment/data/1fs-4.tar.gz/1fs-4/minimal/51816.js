"use strict";
new WeakMap ( [ , ] ) ; 
