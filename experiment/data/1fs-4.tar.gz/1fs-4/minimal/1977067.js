"use strict";
; [ ] . sort . call ( ) ; 
