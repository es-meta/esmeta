"use strict";
Object . getOwnPropertyDescriptors ( null ) ; 
