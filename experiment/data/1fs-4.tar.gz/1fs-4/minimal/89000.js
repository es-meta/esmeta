"use strict";
'' . endsWith . call ( ) ; 
