"use strict";
new WeakMap ( function * ( ) { ; yield * x ( ) ; } `` ) ; function * x ( ) { } 
