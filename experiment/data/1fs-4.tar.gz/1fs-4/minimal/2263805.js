"use strict";
new Float32Array ( [ x => ! x ] ) ; 
