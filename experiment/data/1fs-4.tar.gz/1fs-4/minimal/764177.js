"use strict";
[ ] . pop . call ( typeof x ) ; 
