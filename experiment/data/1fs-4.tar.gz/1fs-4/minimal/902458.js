"use strict";
( Object ( Int8Array ) ) . prototype . some ( 0 , 0 ) ; 
