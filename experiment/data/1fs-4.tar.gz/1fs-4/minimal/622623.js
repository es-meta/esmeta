"use strict";
String . prototype . codePointAt ( 1 ) ; 
