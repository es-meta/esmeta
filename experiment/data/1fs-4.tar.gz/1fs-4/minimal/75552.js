"use strict";
Array . prototype . toSpliced ( 1n ) ; 
