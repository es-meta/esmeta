"use strict";
; [ ] . __proto__ = null ; 
