"use strict";
Math . clz32 ( `` ) ; 
