"use strict";
Math . tan ( `` ) ; 
