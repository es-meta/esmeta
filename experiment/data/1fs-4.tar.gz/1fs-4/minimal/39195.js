"use strict";
Promise . resolve . call ( function ( ) { } ) ; 
