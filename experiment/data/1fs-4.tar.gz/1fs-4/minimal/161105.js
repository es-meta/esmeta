"use strict";
true . __defineGetter__ ( ) ; 
