"use strict";
Promise . any ( ) ; 
