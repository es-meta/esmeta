"use strict";
[ ] . filter . call ( x => x , x => x ) ; 
