"use strict";
Set . prototype . has ( ) ; 
