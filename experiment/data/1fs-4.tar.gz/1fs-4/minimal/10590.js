"use strict";
( Object ( Int8Array ) ) . from ( 1n ) ; 
