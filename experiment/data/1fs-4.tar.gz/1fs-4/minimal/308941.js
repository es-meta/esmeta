"use strict";
Object . fromEntries ( [ , ] ) ; 
