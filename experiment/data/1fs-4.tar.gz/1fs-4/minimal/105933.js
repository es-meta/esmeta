"use strict";
String . prototype . trimStart . call ( 1n ) ; 
