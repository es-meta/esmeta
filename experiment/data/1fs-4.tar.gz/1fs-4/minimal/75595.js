"use strict";
Reflect . construct . call ( 0 , function ( ) { } , [ ] ) ; 
