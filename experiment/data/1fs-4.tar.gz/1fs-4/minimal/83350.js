"use strict";
new SyntaxError ( true ) ; 
