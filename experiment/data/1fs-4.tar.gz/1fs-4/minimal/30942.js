"use strict";
String . prototype . matchAll . call ( 0n ) ; 
