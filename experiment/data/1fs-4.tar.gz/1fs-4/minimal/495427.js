"use strict";
0n . __lookupGetter__ ( ) ; 
