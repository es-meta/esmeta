"use strict";
[ ] . keys . call ( 0 ) ; 
