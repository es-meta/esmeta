"use strict";
'' . replace ( `` , x => x ) ; 
