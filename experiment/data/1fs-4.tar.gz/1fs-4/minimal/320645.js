"use strict";
'' . repeat ( x => x ) ; 
