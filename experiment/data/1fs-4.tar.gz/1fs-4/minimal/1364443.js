"use strict";
isFinite ( { } ) ; 
