"use strict";
Math . atan2 ( null ) ; 
