"use strict";
new TypeError ( 0 , { } ) ; 
