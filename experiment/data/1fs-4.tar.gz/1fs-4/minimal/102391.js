"use strict";
'' . __lookupSetter__ ( ) ; 
