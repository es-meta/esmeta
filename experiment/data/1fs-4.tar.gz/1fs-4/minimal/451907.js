"use strict";
Promise . any ( null ) ; 
