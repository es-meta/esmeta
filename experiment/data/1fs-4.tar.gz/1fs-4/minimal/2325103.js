"use strict";
Reflect . defineProperty ( x => x , '' , { enumerable : typeof x } ) ; 
