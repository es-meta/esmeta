"use strict";
Object . getOwnPropertyDescriptors ( [ ] ) ; 
