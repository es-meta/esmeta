"use strict";
Array . prototype . every ( { } ) ; 
