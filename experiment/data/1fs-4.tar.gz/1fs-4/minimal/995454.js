"use strict";
'' . lastIndexOf ( null ) ; 
