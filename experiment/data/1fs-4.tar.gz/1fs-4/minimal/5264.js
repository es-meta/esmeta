"use strict";
Array . prototype . filter . call ( true ) ; 
