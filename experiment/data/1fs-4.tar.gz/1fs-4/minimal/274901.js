"use strict";
[ ] . filter . call ( ) ; 
