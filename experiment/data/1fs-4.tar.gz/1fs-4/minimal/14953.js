"use strict";
Array . prototype . push . call ( true ) ; 
