"use strict";
; for ( { } in typeof x ) ; 
