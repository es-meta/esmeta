"use strict";
Math . log2 ( { } ) ; 
