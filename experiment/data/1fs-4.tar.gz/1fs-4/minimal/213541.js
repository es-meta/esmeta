"use strict";
WeakMap . prototype . getOrInsertComputed ( 0 ) ; 
