"use strict";
Map . groupBy ( 1n , x => x ) ; 
