"use strict";
1n . __defineSetter__ ( ) ; 
