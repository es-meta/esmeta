"use strict";
isNaN ( { [ Symbol . toPrimitive ] : class { } } ) ; 
