"use strict";
[ ] . toSorted ( x => x ) ; 
