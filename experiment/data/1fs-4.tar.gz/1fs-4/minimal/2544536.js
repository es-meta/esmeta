"use strict";
'' . padEnd ( true , '' ) ; 
