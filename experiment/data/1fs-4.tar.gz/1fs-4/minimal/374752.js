"use strict";
String . prototype . matchAll . call ( false ) ; 
