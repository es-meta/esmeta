"use strict";
Math . abs ( [ ] ) ; 
