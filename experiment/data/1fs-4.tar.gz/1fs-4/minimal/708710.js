"use strict";
String . fromCharCode ( null ) ; 
