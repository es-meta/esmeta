"use strict";
BigInt . asUintN ( `` ) ; 
