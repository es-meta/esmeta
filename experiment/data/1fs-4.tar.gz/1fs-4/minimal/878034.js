"use strict";
Object . groupBy ( true , x => x ) ; 
