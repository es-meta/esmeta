"use strict";
BigInt . asIntN ( ~ typeof x ) ; 
