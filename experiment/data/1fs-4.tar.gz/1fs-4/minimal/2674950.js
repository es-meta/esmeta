"use strict";
String . prototype . padStart ( 1 ) ; x : ; 
