"use strict";
Math . tan ( true ) ; 
