"use strict";
1 . toString ( '' ) ; 
