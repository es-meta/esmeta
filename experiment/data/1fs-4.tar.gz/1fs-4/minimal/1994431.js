"use strict";
new Uint8Array ( { [ Symbol . iterator ] : async function * ( ) { } } ) ; 
