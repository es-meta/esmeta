"use strict";
Object . values ( this ) ; 
