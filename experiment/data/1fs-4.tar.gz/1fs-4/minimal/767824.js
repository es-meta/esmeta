"use strict";
( Object ( function * ( ) { } ) ) . prototype . find ( ) ; 
