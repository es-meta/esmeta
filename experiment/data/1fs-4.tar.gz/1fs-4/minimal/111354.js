"use strict";
Iterator . prototype . filter ( ) ; 
