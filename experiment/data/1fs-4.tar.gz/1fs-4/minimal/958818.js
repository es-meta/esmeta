"use strict";
Number ( 1n ) ; 
