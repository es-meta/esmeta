"use strict";
'' . split ( { } ) ; 
