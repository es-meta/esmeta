"use strict";
`` . concat ( [ ] ) ; 
