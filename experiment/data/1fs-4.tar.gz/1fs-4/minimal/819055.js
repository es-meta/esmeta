"use strict";
Symbol . for ( false ) ; 
