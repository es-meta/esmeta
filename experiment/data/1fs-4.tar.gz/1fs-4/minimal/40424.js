"use strict";
Array . prototype . shift . call ( typeof x ) ; 
