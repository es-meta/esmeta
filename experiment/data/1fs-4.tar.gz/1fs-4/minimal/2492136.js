"use strict";
[ ] . splice ( x => x , null ) ; 
