"use strict";
String . prototype . replaceAll ( { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
