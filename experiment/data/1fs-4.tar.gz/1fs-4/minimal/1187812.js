"use strict";
String . prototype . indexOf ( 0 , '' ) ; 
