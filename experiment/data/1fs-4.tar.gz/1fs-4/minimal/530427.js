"use strict";
[ ] . at . call ( ! typeof x ) ; 
