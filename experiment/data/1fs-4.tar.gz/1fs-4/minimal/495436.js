"use strict";
new Number ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
