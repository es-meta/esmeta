"use strict";
new TypeError ( { [ Symbol . toPrimitive ] : x => { } } ) ; 
