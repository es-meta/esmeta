"use strict";
Reflect . set . call ( 0 , [ ] , 1n ) ; 
