"use strict";
'' . replaceAll ( null ) ; 
