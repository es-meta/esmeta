"use strict";
0 . __defineSetter__ ( true , x => x ) ; 
