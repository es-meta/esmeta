"use strict";
new TypeError ( { [ Symbol . toPrimitive ] : class { } } ) ; 
