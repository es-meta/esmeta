"use strict";
Math . fround ( { [ Symbol . toPrimitive ] : x => x } ) ; 
