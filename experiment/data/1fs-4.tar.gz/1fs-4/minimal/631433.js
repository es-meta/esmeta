"use strict";
[ ] . values . call ( 0 ) ; 
