"use strict";
Iterator . prototype . find ( { } ) ; 
