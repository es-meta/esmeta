"use strict";
[ ] . findLast . call ( ) ; 
