"use strict";
[ ] . flat ( ! typeof x ) ; 
