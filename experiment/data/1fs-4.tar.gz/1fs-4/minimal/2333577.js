"use strict";
Reflect . defineProperty ( x => x , '' , { enumerable : true } ) ; 
