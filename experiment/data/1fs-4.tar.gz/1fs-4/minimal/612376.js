"use strict";
Math . acos ( true ) ; 
