"use strict";
Math . asin ( null ) ; 
