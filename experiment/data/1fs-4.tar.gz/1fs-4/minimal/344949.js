"use strict";
Math . sinh ( { } ) ; 
