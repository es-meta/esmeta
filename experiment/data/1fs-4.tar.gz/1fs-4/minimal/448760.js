"use strict";
Promise . any ( [ ] ) ; 
