"use strict";
Math . tanh ( null ) ; 
