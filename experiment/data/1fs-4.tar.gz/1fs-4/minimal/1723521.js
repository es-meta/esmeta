"use strict";
new Uint8Array ( { [ Symbol . iterator ] : function ( ) { } } ) ; 
