"use strict";
Math . pow ( [ ] ) ; 
