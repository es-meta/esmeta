"use strict";
'' . toString . call ( ) ; 
