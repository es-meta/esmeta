"use strict";
[ x => x ] . filter ( x => ! x ) ; 
