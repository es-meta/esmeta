"use strict";
`` . trimEnd . call ( 0 ) ; 
