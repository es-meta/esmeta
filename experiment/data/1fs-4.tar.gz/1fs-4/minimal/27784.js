"use strict";
Promise . allSettled ( true ) ; 
