"use strict";
[ ] . toReversed . call ( 0 ) ; 
