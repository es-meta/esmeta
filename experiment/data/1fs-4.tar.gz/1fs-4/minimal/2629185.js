"use strict";
Number . prototype . toFixed . call ( ~ async function * x ( ) { } ) ; 
