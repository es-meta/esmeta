"use strict";
Array . fromAsync ( { [ Symbol . iterator ] : async function * ( ) { } } ) ; 
