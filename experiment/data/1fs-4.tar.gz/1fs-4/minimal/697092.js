"use strict";
[ ] . values . call ( '' ) ; 
