"use strict";
[ ] . valueOf . call ( true ) ; 
