"use strict";
new Float32Array ( { [ Symbol . iterator ] : x => [ ] } ) ; 
