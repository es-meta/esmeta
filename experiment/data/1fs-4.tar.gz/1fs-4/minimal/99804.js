"use strict";
new Float64Array ( 1 ) ; 
