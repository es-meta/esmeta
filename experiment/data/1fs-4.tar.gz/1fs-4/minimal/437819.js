"use strict";
encodeURI ( false ) ; 
