"use strict";
Number ( null ) ; 
