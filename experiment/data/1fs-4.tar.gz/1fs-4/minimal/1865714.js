"use strict";
Math . fround ( { [ Symbol . toPrimitive ] : [ ] } ) ; 
