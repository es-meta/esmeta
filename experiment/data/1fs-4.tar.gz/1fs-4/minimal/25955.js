"use strict";
Math . hypot ( '' ) ; 
