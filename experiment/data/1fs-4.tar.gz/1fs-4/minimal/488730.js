"use strict";
[ , ] . findLast ( ) ; 
