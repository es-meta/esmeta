"use strict";
[ ] . toLocaleString . call ( 0 ) ; 
