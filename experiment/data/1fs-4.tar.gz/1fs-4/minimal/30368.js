"use strict";
Array . prototype . with . call ( true ) ; 
