"use strict";
Object . defineProperties ( [ ] ) ; 
