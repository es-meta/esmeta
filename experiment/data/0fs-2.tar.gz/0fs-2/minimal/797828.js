"use strict";
[ ] . splice ( x => x , 0n ) ; 
