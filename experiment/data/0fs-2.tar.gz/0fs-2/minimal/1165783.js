"use strict";
'' . matchAll . call ( ) ; 
