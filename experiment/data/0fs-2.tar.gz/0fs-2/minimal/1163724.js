"use strict";
'' . matchAll . call ( x => x , { [ Symbol . match ] : 1 } ) ; 
