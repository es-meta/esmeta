"use strict";
String . fromCodePoint ( ~ typeof x ) ; ; 
