"use strict";
Promise . prototype . catch . call ( import ( x => x ) ) ; 
