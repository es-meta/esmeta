"use strict";
String ( { [ Symbol . toPrimitive ] : x => x } ) ; 
