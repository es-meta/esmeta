"use strict";
Math . sqrt ( ~ typeof x ) ; 
