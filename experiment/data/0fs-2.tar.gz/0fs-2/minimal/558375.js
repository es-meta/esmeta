"use strict";
Reflect . deleteProperty ( { } ) ; 
