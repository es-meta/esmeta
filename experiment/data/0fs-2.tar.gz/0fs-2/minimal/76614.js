"use strict";
Number . prototype . toPrecision . call ( ) ; 
