"use strict";
Math . fround ( 1n ) ; 
