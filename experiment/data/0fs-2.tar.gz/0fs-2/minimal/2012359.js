"use strict";
'' . startsWith ( x => x , x => x ) ; 
