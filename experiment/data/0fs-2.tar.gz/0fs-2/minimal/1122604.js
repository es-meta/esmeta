"use strict";
Object . is ( 0 , 1 ) ; 
