"use strict";
Reflect . get ( 0 ) ; 
