"use strict";
[ ] . findLast . call ( null ) ; 
