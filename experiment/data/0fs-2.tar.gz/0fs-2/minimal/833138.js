"use strict";
Array . of . call ( function ( ... x ) { return x => x ; } ) ; 
