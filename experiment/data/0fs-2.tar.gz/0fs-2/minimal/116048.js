"use strict";
[ ] . lastIndexOf ( ) ; 
