"use strict";
[ x => x ] . unshift ( x => x ) ; 
