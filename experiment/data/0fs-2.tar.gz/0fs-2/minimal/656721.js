"use strict";
( Object . getPrototypeOf ( Int8Array ) ) . from ( 1 ) ; 
