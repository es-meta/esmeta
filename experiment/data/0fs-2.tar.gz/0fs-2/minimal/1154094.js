"use strict";
( Object ( Int8Array ) ) . prototype . forEach ( 0 , 0 ) ; 
