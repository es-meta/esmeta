"use strict";
[ ] . indexOf ( 0 ) ; 
