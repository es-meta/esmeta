"use strict";
Promise . race ( ) ; 
