"use strict";
String . prototype . slice ( 0 , 0n ) ; 
