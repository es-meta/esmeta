"use strict";
true . valueOf . call ( ) ; 
