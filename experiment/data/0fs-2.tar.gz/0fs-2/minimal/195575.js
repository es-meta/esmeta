"use strict";
Object . fromEntries ( `` ) ; 
