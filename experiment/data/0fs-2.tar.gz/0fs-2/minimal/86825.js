"use strict";
Array . prototype . forEach . call ( ) ; 
