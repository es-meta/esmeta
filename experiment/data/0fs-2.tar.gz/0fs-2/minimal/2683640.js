"use strict";
'' . matchAll . call ( x => x , function ( ... x ) { } ) ; 
