"use strict";
[ import ( x => x ) . x &&= x ] . lastIndexOf ( ) ; 
