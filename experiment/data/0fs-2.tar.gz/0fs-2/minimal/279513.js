"use strict";
[ ] . map ( ) ; 
