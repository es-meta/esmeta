"use strict";
Number . prototype . toFixed . call ( + { } ) ; x , x ; 
