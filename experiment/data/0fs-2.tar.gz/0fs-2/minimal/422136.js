"use strict";
Object . defineProperty . call ( '' , { } , { [ Symbol . toPrimitive ] : '' } ) ; 
