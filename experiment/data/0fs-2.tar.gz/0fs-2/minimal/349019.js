"use strict";
BigInt . asIntN ( 1n ) ; 
