"use strict";
[ x => x ] . reduce ( x => x ) ; 
