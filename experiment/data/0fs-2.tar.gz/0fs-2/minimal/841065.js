"use strict";
[ ] . flat ( 1n ) ; 
