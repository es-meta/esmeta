"use strict";
( Object ( Int8Array ) ) . prototype . toSorted ( ) ; 
