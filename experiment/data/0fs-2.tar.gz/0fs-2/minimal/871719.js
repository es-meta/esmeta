"use strict";
new Float64Array ( { [ Symbol . iterator ] : 1 } ) ; 
