"use strict";
Promise . all ( 0 ) ; 
