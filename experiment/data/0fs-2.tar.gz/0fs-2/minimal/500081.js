"use strict";
Array . from . call ( function ( ) { return x => x ; } , 1 ) ; 
