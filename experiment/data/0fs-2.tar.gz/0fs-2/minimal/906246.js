"use strict";
String . prototype . trimStart . call ( { [ Symbol . toPrimitive ] : '' } ) ; 
