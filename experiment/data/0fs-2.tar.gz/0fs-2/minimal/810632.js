"use strict";
Object . keys ( { [ Symbol . hasInstance ] : `` } ) ; 
