"use strict";
Error . isError ( 0 ) ; 
