"use strict";
Object . isFrozen ( [ ] ) ; 
