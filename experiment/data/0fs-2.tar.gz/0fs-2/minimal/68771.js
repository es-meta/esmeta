"use strict";
'' . lastIndexOf ( ) ; 
