"use strict";
Math . log10 ( 42 ) ; 
