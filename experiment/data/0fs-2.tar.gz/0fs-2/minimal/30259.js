"use strict";
new Boolean ( { } ) ; 
