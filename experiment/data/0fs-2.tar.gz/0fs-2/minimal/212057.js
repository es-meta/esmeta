"use strict";
Iterator . from ( [ ] ) ; 
