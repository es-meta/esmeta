"use strict";
`` . match ( 0 ) ; 
