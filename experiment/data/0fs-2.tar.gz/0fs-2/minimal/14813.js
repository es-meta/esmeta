"use strict";
Promise . try . call ( class { } ) ; 
