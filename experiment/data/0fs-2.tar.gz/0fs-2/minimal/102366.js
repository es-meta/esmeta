"use strict";
Reflect . get ( [ ] ) ; 
