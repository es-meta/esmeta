"use strict";
Object . freeze ( 0 ) ; 
