"use strict";
'' . lastIndexOf ( 0 , 0 ) ; 
