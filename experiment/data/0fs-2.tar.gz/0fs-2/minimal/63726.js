"use strict";
Reflect . setPrototypeOf . call ( 0 , x => x , { } ) ; 
