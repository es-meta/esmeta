"use strict";
[ ] . indexOf ( x => x , x => x ) ; 
