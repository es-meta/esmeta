"use strict";
`` . replaceAll ( 0 ) ; 
