"use strict";
Number . isFinite ( 0 ) ; 
