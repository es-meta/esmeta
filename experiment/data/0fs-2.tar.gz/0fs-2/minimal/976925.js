"use strict";
'' . endsWith . call ( { } ) ; 
