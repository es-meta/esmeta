"use strict";
1 . valueOf . call ( ) ; 
