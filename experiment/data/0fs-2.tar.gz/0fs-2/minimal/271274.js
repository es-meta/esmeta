"use strict";
Function . apply . call ( 0 ) ; 
