"use strict";
Reflect . setPrototypeOf ( [ ] ) ; 
