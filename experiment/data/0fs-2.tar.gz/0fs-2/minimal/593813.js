"use strict";
`` . replace ( '' , ( ) => x ) ; 
