"use strict";
'' . valueOf . call ( ) ; 
