"use strict";
Reflect . defineProperty ( [ ] ) ; 
