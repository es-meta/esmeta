"use strict";
Array . prototype . reduce ( x => x , 0 ) ; 
