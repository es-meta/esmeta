"use strict";
Math . log ( 0 ) ; 
