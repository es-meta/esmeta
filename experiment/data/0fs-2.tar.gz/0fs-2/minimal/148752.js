"use strict";
String . fromCodePoint ( 0n ) ; 
