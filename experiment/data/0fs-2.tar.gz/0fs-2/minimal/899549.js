"use strict";
'' . at ( ~ typeof x ) ; 
