"use strict";
Iterator . prototype . find ( x => x ) ; 
