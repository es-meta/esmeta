"use strict";
String . prototype . charAt . call ( { [ Symbol . toPrimitive ] : `` } ) ; 
