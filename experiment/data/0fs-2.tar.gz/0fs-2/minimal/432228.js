"use strict";
Math . hypot ( 1n ) ; 
