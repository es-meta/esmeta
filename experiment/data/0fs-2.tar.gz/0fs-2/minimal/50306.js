"use strict";
Object . entries ( typeof x ) ; 
