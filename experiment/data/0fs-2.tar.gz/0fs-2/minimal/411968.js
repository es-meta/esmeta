"use strict";
new Set ( [ , x => x ] ) ; 
