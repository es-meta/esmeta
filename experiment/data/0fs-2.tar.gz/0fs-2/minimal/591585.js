"use strict";
String . fromCharCode ( 0 , - delete typeof x ) ; 
