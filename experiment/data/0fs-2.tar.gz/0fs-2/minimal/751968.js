"use strict";
[ ] . unshift ( x => x ) ; 
