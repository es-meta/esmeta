"use strict";
[ , x => x ] . map ( x => x ) ; 
