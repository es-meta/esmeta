"use strict";
[ ] . flatMap ( 0 ) ; 
