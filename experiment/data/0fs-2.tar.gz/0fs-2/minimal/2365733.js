"use strict";
[ , x => x , ] . some ( x => x ) ; 
