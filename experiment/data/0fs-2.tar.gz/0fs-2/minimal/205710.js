"use strict";
'' . __lookupSetter__ . call ( ) ; 
