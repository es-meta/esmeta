"use strict";
`` . search ( x => x ) ; 
