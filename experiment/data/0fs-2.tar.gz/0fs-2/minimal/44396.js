"use strict";
String . prototype . search . call ( ) ; 
