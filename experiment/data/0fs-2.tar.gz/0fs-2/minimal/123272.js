"use strict";
( Object ( Int8Array ) ) . prototype . slice ( 0 ) ; 
