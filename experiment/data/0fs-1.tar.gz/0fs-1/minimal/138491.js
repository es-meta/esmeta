"use strict";
Promise . try ( x => x ) ; 
