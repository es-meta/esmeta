"use strict";
Number . prototype . valueOf . call ( '' ) ; 
