"use strict";
[ ] . reduceRight ( ) ; 
