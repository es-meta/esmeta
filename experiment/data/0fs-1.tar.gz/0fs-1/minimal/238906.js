"use strict";
Math . sqrt ( 0n ) ; 
