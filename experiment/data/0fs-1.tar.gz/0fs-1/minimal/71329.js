"use strict";
new Boolean ( typeof x ) ; 
