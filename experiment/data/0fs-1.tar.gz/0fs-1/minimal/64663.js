"use strict";
Array . prototype . entries . call ( ) ; 
