"use strict";
Object . defineProperty ( { } , `` , { get : x => x } ) ; 
