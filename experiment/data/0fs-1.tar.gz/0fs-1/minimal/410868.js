"use strict";
Math . floor ( 1 ) ; 
