"use strict";
function * x ( ) { } Array . fromAsync . call ( 0 , async function * ( ) { yield * x ( ) ; } `` ) ; 
