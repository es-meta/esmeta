"use strict";
0 . propertyIsEnumerable ( '' ) ; 
