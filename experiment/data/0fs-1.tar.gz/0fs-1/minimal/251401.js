"use strict";
[ ] . shift . call ( `` ) ; 
