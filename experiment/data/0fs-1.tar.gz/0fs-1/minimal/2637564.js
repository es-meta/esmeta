"use strict";
; Array . prototype . sort ( 0 ) ; 
