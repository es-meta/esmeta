"use strict";
Array . prototype . lastIndexOf . call ( x => x , 0 , 1n ) ; 
