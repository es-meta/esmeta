"use strict";
`` . endsWith . call ( { } ) ; 
