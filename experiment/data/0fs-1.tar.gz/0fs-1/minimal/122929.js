"use strict";
Object . freeze ( { } ) ; 
