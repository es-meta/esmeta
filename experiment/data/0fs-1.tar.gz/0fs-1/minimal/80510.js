"use strict";
0 . __lookupSetter__ ( ) ; 
