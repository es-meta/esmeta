"use strict";
`` . indexOf ( x => x ) ; 
