"use strict";
Math . ceil ( { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
