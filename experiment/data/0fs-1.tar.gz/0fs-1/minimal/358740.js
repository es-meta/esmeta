"use strict";
'' . repeat ( 0n ) ; 
