"use strict";
[ ] . toSorted ( [ , ] ) ; 
