"use strict";
ArrayBuffer . isView ( { } ) ; 
