"use strict";
Reflect . construct . call ( 0 , function x ( x , [ ] ) { } , x => x ) ; 
