"use strict";
[ ] . sort . call ( ) ; 
