"use strict";
Array . from . call ( function x ( ) { return x ; } , 0 ) ; 
