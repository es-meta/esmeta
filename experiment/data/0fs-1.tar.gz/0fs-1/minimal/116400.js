"use strict";
String . prototype . split . call ( ) ; 
