"use strict";
`${ x => x }` . at ( ) ; 
