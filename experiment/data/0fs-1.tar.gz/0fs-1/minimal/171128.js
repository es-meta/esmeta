"use strict";
[ ] . splice . call ( x => x , ~ typeof x ) ; 
