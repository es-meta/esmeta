"use strict";
Math . ceil ( { [ Symbol . toPrimitive ] : '' } ) ; 
