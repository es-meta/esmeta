"use strict";
'' . search ( ) ; { ; } 
