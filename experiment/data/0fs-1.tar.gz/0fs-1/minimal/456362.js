"use strict";
[ ] . sort ( ) ; 
