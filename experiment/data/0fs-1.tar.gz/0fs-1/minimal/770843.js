"use strict";
`` . substring ( 0 ) ; 
