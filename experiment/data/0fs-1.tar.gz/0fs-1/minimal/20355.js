"use strict";
Math . min ( 0n ) ; 
