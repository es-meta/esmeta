"use strict";
Object . defineProperty ( { } , { [ Symbol . toPrimitive ] : '' } ) ; 
