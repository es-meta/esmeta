"use strict";
( Object . getPrototypeOf ( Int8Array ) ) . of ( 0 ) ; 
