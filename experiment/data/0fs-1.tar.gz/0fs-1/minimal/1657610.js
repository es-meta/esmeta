"use strict";
Iterator . from ( { [ Symbol . iterator ] : ( ) => x } ) ; 
