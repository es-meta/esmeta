"use strict";
Proxy . revocable . call ( 0 , class { } , x => x ) ; 
