"use strict";
( x => x ) . call ( ) ; 
