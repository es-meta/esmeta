"use strict";
new Map ( { [ Symbol . iterator ] : x => x } ) ; 
