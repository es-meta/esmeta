"use strict";
Math . imul ( 0 , 1n ) ; 
