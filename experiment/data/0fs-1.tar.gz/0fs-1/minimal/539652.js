"use strict";
Object . defineProperty ( { } , '' , { enumerable : 0 } ) ; 
