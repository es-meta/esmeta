"use strict";
[ ] . fill ( x => x ) ; 
