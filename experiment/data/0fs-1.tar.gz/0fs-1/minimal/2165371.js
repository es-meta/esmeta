"use strict";
Function . apply . call ( ( ) => x , 0 , { } ) ; 
