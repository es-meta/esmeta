"use strict";
Error . toString ( ) ; 
