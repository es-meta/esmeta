"use strict";
( Object ( Int8Array ) ) . prototype . at ( 0 ) ; 
