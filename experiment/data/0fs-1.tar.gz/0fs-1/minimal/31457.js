"use strict";
Array . prototype . keys . call ( ) ; 
