"use strict";
`` . endsWith . call ( null ) ; 
