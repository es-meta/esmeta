"use strict";
1 . toFixed ( 1n ) ; 
