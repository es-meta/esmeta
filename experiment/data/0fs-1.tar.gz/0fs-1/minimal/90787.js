"use strict";
Error . prototype . toString ( ) ; 
