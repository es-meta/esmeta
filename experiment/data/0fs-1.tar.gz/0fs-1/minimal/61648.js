"use strict";
`` . endsWith ( 0 ) ; 
