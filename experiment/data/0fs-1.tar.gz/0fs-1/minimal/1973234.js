"use strict";
[ ] . every . call ( x => x , x => x ) ; 
