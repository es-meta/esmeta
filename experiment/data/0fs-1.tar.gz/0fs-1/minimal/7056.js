"use strict";
String . prototype . lastIndexOf . call ( ) ; 
