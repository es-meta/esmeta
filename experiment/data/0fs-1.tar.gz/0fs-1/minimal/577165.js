"use strict";
; `` . __proto__ = 0 ; 
