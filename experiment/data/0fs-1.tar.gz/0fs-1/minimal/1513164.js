"use strict";
Number . prototype . toExponential . call ( `` ) ; ; 
