"use strict";
Error ( 0 , [ ] ) ; 
