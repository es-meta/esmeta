"use strict";
'' . repeat ( 0 ) ; 
