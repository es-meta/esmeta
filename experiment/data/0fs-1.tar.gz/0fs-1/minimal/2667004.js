"use strict";
'' . toLowerCase ( ) ; x = x ; 
