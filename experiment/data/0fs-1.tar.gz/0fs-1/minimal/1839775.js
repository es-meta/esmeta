"use strict";
[ ] . keys ( ) ; 
