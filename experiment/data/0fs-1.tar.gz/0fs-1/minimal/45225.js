"use strict";
Proxy . revocable . call ( 0 , { } , x => x ) ; 
