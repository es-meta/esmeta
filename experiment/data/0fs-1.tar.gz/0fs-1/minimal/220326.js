"use strict";
isNaN ( true ) ; 
