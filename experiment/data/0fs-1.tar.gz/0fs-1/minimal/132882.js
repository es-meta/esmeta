"use strict";
String . prototype . at ( 1n ) ; 
