"use strict";
`` . valueOf ( 0 ) ; 
