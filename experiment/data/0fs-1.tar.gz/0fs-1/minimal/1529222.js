"use strict";
[ ] . push . call ( ) ; 
