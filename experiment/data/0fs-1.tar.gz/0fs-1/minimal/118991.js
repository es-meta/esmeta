"use strict";
`` . propertyIsEnumerable . call ( null ) ; 
