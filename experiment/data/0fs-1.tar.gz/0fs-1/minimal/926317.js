"use strict";
Object . setPrototypeOf ( [ ] , [ ] ) ; 
