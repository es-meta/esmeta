"use strict";
[ ] . toSpliced ( ) ; 
