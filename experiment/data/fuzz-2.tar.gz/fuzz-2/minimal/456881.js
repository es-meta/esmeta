"use strict";
'' . at ( ) ; 
