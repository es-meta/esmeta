"use strict";
[ ] . reverse . call ( ) ; 
