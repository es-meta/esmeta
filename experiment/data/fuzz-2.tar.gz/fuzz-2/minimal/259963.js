"use strict";
new Proxy ( [ ] , [ ] ) ; 
