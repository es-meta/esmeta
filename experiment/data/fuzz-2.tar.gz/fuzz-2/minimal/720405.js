"use strict";
Error ( false ) ; 
