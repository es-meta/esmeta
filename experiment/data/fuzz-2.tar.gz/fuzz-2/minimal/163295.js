"use strict";
Reflect . isExtensible ( [ ] ) ; 
