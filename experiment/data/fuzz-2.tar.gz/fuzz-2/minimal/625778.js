"use strict";
Error ( [ ] ) ; 
