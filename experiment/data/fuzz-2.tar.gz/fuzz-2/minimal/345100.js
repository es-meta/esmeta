"use strict";
`` . propertyIsEnumerable ( ) ; 
