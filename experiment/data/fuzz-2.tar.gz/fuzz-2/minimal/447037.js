"use strict";
[ , ] . sort ( ) ; 
