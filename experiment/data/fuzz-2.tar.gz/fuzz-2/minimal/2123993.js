"use strict";
`` . toLowerCase ( ) ; x : ; 
