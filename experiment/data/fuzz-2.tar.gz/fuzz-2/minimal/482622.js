"use strict";
[ , ] . fill ( ) ; 
