"use strict";
[ ] . toSorted . call ( ) ; 
