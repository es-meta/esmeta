"use strict";
Reflect . set ( [ ] ) ; 
