"use strict";
[ ] . indexOf . call ( ) ; 
