"use strict";
`` . charCodeAt . call ( ) ; 
