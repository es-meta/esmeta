"use strict";
[ ] . some ( ) ; 
