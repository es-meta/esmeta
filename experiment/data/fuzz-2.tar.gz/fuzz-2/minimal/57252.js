"use strict";
Promise . race ( `` ) ; 
