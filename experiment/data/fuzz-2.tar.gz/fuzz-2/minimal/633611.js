"use strict";
new Float64Array ( { [ Symbol . iterator ] : x => x } ) ; 
