"use strict";
Object . create ( { } ) ; 
