"use strict";
'' . matchAll ( ) ; 
