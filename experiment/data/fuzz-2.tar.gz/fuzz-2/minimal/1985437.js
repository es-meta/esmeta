"use strict";
[ ] . toLocaleString ( ) ; { ; } 
