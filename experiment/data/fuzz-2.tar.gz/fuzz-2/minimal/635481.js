"use strict";
Error ( [ , , ] ) ; 
