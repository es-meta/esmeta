"use strict";
Array . prototype . unshift . call ( typeof x , 0 ) ; 
