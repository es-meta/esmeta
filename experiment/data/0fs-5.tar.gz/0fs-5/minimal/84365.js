"use strict";
new BigUint64Array ( { [ Symbol . iterator ] : `` } ) ; 
