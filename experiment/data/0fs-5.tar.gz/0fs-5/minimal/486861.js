"use strict";
'' . concat . call ( null ) ; 
