"use strict";
Iterator . from ( 0 ) ; 
