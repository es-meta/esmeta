"use strict";
Math . sqrt ( 1 ) ; 
