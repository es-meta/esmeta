"use strict";
[ ] . fill . call ( typeof x ) ; 
