"use strict";
new Float16Array ( 0n ) ; 
