"use strict";
[ ] . toString . call ( ) ; 
