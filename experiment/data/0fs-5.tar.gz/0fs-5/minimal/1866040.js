"use strict";
[ ] . join . call ( ) ; 
