"use strict";
`` . normalize ( 0 ) ; 
