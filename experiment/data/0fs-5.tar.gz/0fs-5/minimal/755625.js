"use strict";
[ ] . reduceRight ( x => x , 0 ) ; 
