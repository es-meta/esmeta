"use strict";
[ ] . some . call ( typeof x , x => x ) ; 
