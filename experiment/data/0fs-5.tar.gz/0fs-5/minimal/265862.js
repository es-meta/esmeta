"use strict";
new Promise ( ( ) => x ) ; 
