"use strict";
Function . bind ( ) ; 
