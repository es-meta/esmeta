"use strict";
( Object ( Int8Array ) ) . of ( 0n ) ; 
