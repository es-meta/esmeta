"use strict";
new Proxy ( [ ] , { } ) ; 
