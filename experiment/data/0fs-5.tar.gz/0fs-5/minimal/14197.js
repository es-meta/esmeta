"use strict";
new Boolean ( [ ] ) ; 
