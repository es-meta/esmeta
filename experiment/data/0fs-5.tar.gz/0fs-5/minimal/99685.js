"use strict";
Promise . prototype . finally ( x => x ) ; 
