"use strict";
[ ] . lastIndexOf . call ( ) ; 
