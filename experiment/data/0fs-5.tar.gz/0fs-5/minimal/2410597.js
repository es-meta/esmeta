"use strict";
'' . substring . call ( ) ; 
