"use strict";
new BigUint64Array ( x => x ) ; 
