"use strict";
'' . lastIndexOf . call ( { } ) ; 
