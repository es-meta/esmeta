"use strict";
[ ] . toSorted ( 42 ) ; 
