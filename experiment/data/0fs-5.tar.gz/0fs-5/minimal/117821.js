"use strict";
( Object ( Int8Array ) ) . from ( ) ; 
