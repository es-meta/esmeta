"use strict";
`` . isPrototypeOf ( 0 ) ; 
