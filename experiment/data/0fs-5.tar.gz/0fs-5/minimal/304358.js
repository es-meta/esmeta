"use strict";
Reflect . getPrototypeOf ( { } ) ; 
