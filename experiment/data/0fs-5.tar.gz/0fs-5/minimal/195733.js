"use strict";
Error . toString . call ( ) ; 
