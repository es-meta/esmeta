"use strict";
Math . abs ( 0n ) ; 
