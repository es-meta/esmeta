"use strict";
Object . freeze ( { set x ( x ) { } } ) ; 
