"use strict";
[ ] . with ( ) ; 
