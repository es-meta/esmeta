"use strict";
new Map ( { [ Symbol . iterator ] : `` } ) ; 
