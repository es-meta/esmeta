"use strict";
[ x => x ] . lastIndexOf ( ) ; 
