"use strict";
'' . codePointAt ( x => x ) ; 
