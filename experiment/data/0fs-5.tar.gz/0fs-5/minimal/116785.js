"use strict";
isFinite ( 1n ) ; 
