"use strict";
String . fromCodePoint ( 0 ) ; 
