"use strict";
Map . prototype . set ( 0 ) ; 
