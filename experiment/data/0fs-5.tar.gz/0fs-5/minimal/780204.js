"use strict";
'' . startsWith ( `` ) ; 
