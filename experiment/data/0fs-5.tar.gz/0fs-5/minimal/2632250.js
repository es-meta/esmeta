"use strict";
String . fromCodePoint ( ~ typeof function x ( x ) { } ) ; 
