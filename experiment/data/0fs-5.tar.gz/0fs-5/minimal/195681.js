"use strict";
BigInt . asIntN ( 1 , 1n ) ; 
