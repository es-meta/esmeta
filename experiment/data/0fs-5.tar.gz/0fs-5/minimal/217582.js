"use strict";
Reflect . has ( 0 ) ; 
