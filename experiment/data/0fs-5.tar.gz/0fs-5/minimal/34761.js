"use strict";
String . prototype . codePointAt . call ( ) ; 
