"use strict";
Function . apply ( x => x , [ , x => x , , ] ) ; 
