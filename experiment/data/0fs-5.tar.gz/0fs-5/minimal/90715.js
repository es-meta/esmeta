"use strict";
Object . isSealed ( [ ] ) ; 
