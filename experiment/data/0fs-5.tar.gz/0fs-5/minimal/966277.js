"use strict";
Array . prototype . copyWithin ( 1n ) ; 
