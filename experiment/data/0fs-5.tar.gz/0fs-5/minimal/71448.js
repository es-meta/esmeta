"use strict";
Promise ( ) ; 
