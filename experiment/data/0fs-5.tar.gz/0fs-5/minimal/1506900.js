"use strict";
new Uint32Array ( { [ Symbol . iterator ] : x => [ ] } ) ; 
