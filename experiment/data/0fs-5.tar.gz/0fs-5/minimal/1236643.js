"use strict";
0 . __defineSetter__ . call ( typeof x , 0 , x => x ) ; 
