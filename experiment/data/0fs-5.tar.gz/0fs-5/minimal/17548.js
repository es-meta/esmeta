"use strict";
new Uint16Array ( 0n ) ; 
