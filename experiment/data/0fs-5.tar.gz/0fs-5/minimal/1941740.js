"use strict";
Error ( [ x => x ] ) ; 
