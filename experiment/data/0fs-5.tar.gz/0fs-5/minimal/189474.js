"use strict";
Iterator . prototype . map ( x => x ) ; 
