"use strict";
`` . at ( { [ Symbol . toPrimitive ] : x => x } ) ; 
