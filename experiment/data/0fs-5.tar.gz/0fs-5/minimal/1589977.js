"use strict";
[ ] . reduce ( x => x , 0 ) ; 
