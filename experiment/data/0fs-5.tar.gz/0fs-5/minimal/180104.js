"use strict";
Math . atan2 ( 1n ) ; 
