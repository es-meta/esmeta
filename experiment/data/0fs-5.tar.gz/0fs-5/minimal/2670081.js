"use strict";
Array . fromAsync ( { [ Symbol . asyncIterator ] : x => x } ) ; 
