"use strict";
[ ] . find ( ) ; 
