"use strict";
Proxy . revocable ( 0 ) ; 
