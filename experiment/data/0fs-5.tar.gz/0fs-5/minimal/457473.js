"use strict";
[ ] . toSpliced . call ( ) ; 
