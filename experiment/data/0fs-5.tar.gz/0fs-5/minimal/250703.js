"use strict";
new Proxy ( class { } , { } ) ; 
