"use strict";
Object . create . call ( 0 , { } , typeof x ) ; 
