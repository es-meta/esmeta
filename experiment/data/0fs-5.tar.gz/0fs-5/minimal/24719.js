"use strict";
Array . prototype . splice ( 1n ) ; 
