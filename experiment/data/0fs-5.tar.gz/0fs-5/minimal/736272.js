"use strict";
'' . codePointAt ( ) ; 
