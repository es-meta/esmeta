"use strict";
`` . __defineSetter__ ( ) ; 
