"use strict";
Object . getOwnPropertySymbols ( 0 ) ; 
