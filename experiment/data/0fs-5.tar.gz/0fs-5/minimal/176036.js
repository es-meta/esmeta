"use strict";
Promise . race ( [ , ] ) ; 
