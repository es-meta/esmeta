"use strict";
String . prototype . replace ( { [ Symbol . replace ] : class { } } ) ; 
