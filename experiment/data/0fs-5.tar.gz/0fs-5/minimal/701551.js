"use strict";
Object . keys ( { [ Symbol . iterator ] : 1 } ) ; 
