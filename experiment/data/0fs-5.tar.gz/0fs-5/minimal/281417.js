"use strict";
`` . isPrototypeOf ( { } ) ; 
