"use strict";
`` . __defineSetter__ . call ( ) ; 
