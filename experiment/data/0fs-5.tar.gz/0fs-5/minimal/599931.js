"use strict";
`` . replace ( 1 ) ; 
