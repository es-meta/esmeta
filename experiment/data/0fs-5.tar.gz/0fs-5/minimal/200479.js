"use strict";
Math . acos ( 1 ) ; 
