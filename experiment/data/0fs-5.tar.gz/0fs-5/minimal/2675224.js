"use strict";
`` . matchAll ( { [ Symbol . match ] : x => x ?? x == x } ) ; 
