"use strict";
String . prototype . at . call ( ) ; 
