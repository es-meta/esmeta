"use strict";
'' . lastIndexOf ( 0 ) ; 
