"use strict";
Error ( { } ) ; 
