"use strict";
[ , ] . slice ( ) ; 
