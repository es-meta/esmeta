"use strict";
Array . fromAsync ( x => x , ( ) => x ) ; 
