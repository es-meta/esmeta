"use strict";
String . prototype . includes ( 0 , 1n ) ; 
