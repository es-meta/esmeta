"use strict";
Math . log1p ( 0 ) ; 
