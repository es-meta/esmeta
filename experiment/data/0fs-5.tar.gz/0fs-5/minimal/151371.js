"use strict";
Reflect . getOwnPropertyDescriptor ( 0 ) ; 
