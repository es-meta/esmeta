"use strict";
( Object ( Int8Array ) ) . from ( 0 , 0 , 0 ) ; 
