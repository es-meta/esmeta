"use strict";
0n . valueOf ( 0 ) ; 
