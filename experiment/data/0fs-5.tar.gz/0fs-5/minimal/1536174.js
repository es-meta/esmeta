"use strict";
[ ] . toSpliced ( x => x , x => x ) ; 
