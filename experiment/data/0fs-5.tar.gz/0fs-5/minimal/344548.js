"use strict";
String . prototype . substring ( 0n ) ; 
