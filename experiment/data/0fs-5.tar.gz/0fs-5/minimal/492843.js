"use strict";
( Object ( Int8Array ) ) . prototype . fill ( ) ; 
