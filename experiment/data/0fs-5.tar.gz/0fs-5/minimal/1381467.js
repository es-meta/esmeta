"use strict";
[ x => x ] . reduceRight ( ( ) => x , 0 ) ; 
