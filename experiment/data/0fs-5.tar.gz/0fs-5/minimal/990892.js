"use strict";
Array . from ( [ , ] , ( ) => x ) ; 
