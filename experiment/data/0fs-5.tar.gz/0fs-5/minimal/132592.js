"use strict";
[ ] . every ( ) ; 
