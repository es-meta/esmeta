"use strict";
[ , ] . find ( ( ) => x ) ; 
