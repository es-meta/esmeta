"use strict";
parseInt ( x => x ?? x ) ; 
