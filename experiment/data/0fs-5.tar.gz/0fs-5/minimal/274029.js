"use strict";
1n . toString . call ( ) ; 
