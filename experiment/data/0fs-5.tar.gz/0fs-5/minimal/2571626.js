"use strict";
`` . normalize . call ( ) ; throw x ; 
