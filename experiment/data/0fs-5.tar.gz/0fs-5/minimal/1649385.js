"use strict";
String . prototype . at ( ) ; 
