"use strict";
Math . atan ( 0 ) ; 
