"use strict";
Array . prototype . slice ( 0 , 0n ) ; 
