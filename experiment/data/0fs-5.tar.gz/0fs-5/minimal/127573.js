"use strict";
Number . isFinite . call ( 0 , - typeof x ) ; 
