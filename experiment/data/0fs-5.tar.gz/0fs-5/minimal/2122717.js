"use strict";
Error ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
