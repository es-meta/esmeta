"use strict";
var x = [ ] ; Object . setPrototypeOf ( x , Iterator . prototype ) ; x | x ; 
