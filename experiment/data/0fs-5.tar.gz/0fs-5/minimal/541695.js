"use strict";
( x => x ) . bind ( ) ; 
