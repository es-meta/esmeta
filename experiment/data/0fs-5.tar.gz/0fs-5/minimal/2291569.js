"use strict";
Array . fromAsync ( async function * ( ) { yield ; } `` ) ; 
