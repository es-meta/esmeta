"use strict";
`` . at ( { [ Symbol . toPrimitive ] : '' } ) ; 
