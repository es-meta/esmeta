"use strict";
Array . prototype . at . call ( ) ; 
