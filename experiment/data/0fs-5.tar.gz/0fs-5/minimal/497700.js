"use strict";
'' . __defineGetter__ . call ( ) ; 
