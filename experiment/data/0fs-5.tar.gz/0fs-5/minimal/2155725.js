"use strict";
; 0 . toFixed ( ~ '' ) ; 
