"use strict";
( Object ( function * ( ) { } ) ) . prototype . reduce ( x => x ) ; 
