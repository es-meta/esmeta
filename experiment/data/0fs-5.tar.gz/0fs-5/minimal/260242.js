"use strict";
'' . propertyIsEnumerable . call ( ) ; 
