"use strict";
String . prototype . replace ( `` , { [ Symbol . toPrimitive ] : '' } ) ; 
