"use strict";
new Promise ( function ( ) { } ) ; 
