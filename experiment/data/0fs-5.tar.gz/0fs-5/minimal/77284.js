"use strict";
Array . from ( 0 ) ; 
