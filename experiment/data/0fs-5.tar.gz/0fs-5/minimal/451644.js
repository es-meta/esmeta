"use strict";
Object . isExtensible ( 0 ) ; 
