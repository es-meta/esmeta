"use strict";
new Boolean ( '' ) ; 
