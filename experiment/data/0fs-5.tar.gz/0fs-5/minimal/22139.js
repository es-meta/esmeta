"use strict";
Array . fromAsync ( '' ) ; 
