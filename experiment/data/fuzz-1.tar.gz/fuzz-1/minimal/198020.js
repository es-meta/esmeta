"use strict";
`` . replaceAll ( { } ) ; 
