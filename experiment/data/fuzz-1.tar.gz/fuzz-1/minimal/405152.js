"use strict";
'' . repeat ( ) ; 
