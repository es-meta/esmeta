"use strict";
'' . toWellFormed ( ) ; 
