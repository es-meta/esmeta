"use strict";
BigInt . prototype . toString . call ( 0n , 1n ) ; 
