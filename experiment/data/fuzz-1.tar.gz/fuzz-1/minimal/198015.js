"use strict";
`` . replaceAll ( '' ) ; 
