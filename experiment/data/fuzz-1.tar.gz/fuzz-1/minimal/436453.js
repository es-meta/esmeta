"use strict";
Reflect . getPrototypeOf ( [ ] ) ; 
