"use strict";
Promise . all ( ) ; 
