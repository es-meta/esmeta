"use strict";
[ , , ] . reverse ( ) ; 
