"use strict";
[ ] . at ( ) ; 
