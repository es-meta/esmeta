"use strict";
Reflect . setPrototypeOf ( { } ) ; 
