"use strict";
Object . getOwnPropertySymbols ( '' ) ; 
