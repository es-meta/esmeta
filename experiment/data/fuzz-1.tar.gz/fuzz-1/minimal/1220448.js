"use strict";
[ , ] . toSorted ( ) ; 
