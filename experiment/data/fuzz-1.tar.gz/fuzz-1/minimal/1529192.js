"use strict";
[ ] . push . call ( '' ) ; 
