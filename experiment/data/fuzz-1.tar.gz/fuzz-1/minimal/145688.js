"use strict";
Promise . try ( ) ; 
