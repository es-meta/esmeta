"use strict";
Object . defineProperties ( { } ) ; 
