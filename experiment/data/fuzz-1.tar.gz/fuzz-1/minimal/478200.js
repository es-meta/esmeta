"use strict";
[ , , ] . with ( ) ; 
