"use strict";
[ ] . toLocaleString . call ( ) ; 
