"use strict";
'' . isPrototypeOf ( [ ] ) ; 
