"use strict";
`` . lastIndexOf ( ) ; 
