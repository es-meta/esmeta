"use strict";
`` . normalize ( '' ) ; x ; 
