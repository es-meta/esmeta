"use strict";
[ ] . findLastIndex ( ) ; 
