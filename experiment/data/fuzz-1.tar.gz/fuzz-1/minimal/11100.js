"use strict";
new Map ( [ ] ) ; 
