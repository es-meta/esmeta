"use strict";
`${ ( ) => { } }` . lastIndexOf ( ) ; 
