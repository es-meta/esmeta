"use strict";
Math . hypot ( { } ) ; 
