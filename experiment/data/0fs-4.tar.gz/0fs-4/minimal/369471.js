"use strict";
String . prototype . replaceAll ( `` , ( ) => x ) ; 
