"use strict";
Math . sign ( 0 ) ; 
