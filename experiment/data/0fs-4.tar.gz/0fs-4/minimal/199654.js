"use strict";
1 . propertyIsEnumerable ( ) ; 
