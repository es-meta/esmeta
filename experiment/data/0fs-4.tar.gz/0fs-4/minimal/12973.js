"use strict";
Array . from . call ( function ( ) { x ; } , 0 ) ; 
