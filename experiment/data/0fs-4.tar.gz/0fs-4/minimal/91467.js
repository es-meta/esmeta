"use strict";
String . prototype . codePointAt . call ( 0 , 1n ) ; 
