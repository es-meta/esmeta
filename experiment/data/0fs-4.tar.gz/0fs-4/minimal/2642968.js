"use strict";
`` . replace ( `` , ( ) => x ) ; 
