"use strict";
Object . isSealed ( { } ) ; 
