"use strict";
[ ] . slice ( 0n ) ; 
