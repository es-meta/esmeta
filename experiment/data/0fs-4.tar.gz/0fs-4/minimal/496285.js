"use strict";
String . prototype . lastIndexOf ( 0 , 0n ) ; 
