"use strict";
[ , ] . unshift ( '' ) ; 
