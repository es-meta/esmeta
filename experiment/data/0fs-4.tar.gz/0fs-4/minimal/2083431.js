"use strict";
x : { } [ ] . toLocaleString ( ) ; 
