"use strict";
[ ] . pop ( ) ; 
