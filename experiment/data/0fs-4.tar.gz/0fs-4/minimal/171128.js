"use strict";
( Object ( Int8Array ) ) . prototype . forEach ( ) ; 
