"use strict";
Iterator . prototype . filter ( x => x ) ; 
