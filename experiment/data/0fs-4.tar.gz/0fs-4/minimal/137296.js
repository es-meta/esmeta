"use strict";
'' . hasOwnProperty ( 0 ) ; 
