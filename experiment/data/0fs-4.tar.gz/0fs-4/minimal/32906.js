"use strict";
BigInt ( 0n ) ; 
