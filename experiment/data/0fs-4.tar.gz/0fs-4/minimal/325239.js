"use strict";
Math . f16round ( 0n ) ; 
