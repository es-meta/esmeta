"use strict";
( Object ( Int8Array ) ) . prototype . copyWithin ( 0 , 0 ) ; 
