"use strict";
Iterator . prototype . reduce ( x => x , x => x ) ; 
