"use strict";
[ ] . toSpliced ( 0 ) ; 
