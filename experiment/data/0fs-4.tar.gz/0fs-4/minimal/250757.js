"use strict";
Iterator . prototype . forEach ( x => x ) ; 
