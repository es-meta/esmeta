"use strict";
`${ x => x }` . isWellFormed ( ) ; 
