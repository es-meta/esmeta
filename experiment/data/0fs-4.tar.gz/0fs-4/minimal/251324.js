"use strict";
Math . clz32 ( 0n ) ; 
