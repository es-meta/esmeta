"use strict";
[ ] . toSorted ( 0 ) ; 
