"use strict";
String . fromCodePoint ( { } ) ; 
