"use strict";
Reflect . preventExtensions ( { } ) ; 
