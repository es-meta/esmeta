"use strict";
Math . tanh ( 0 ) ; 
