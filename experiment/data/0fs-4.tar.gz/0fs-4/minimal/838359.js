"use strict";
[ ] . pop . call ( ) ; 
