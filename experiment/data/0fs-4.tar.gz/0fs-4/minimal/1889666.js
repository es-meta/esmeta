"use strict";
[ ] . flatMap ( x => x , x => x ) ; 
