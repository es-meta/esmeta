"use strict";
new ReferenceError;
