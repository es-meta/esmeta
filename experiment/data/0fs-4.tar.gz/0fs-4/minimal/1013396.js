"use strict";
[ ] . flatMap . call ( ) ; 
