"use strict";
Reflect . deleteProperty ( 0 ) ; 
