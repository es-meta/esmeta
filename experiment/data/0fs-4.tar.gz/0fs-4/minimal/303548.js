"use strict";
Array . prototype . toSpliced ( 0 , 0n ) ; 
