"use strict";
Object . keys ( 0 ) ; 
