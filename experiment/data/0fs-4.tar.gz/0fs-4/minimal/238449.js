"use strict";
Promise . resolve ( ) ; 
