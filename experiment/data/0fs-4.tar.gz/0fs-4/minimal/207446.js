"use strict";
'' . isPrototypeOf ( ) ; 
