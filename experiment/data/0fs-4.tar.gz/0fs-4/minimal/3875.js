"use strict";
ArrayBuffer.prototype.resize.call(0, 0);
