"use strict";
new Int16Array ( 1n ) ; 
