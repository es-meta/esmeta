"use strict";
'' . hasOwnProperty ( ) ; 
