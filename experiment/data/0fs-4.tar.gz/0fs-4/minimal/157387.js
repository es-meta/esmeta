"use strict";
Math . trunc ( 1 ) ; 
