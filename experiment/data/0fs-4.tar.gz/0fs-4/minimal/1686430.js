"use strict";
Array . fromAsync ( { [ Symbol . iterator ] : x => x } ) ; 
