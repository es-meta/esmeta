"use strict";
function * x ( ) { } new Int8Array ( { [ Symbol . iterator ] : async function * ( ) { yield * x ( ) ; } } ) ; 
