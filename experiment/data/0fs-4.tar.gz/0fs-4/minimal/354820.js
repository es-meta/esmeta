"use strict";
Promise . all ( [ , ] ) ; 
