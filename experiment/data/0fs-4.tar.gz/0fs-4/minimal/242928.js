"use strict";
[ ] . copyWithin ( 0n ) ; 
