"use strict";
String . fromCharCode ( ~ typeof x ) ; 
