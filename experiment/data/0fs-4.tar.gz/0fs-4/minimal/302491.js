"use strict";
var x = '' ; x . __proto__ ; 
