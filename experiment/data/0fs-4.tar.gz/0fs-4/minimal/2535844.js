"use strict";
Array . prototype . sort . call ( ) ; for ( x in x ) ; 
