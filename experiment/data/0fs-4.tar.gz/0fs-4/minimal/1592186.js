"use strict";
`` . matchAll ( { [ Symbol . matchAll ] : ( ) => x } ) ; 
