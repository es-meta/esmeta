"use strict";
[ ] . toSorted ( 1 ) ; 
