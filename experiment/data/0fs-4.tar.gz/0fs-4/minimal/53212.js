"use strict";
Math . atan2 ( 0 , 1n ) ; 
