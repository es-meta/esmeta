"use strict";
[ x => x ] . indexOf ( x => x ) ; 
