"use strict";
Math . acosh ( 0n ) ; 
