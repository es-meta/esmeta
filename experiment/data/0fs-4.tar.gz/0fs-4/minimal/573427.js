"use strict";
[ , x => x ] . shift ( ) ; 
