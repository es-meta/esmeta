"use strict";
Iterator . prototype . every ( ) ; 
