"use strict";
Array ( `` ) ; 
