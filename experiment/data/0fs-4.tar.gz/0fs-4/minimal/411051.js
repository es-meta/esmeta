"use strict";
Math . sin ( 0 ) ; 
