"use strict";
[ , ] . reduce ( x => x ) ; 
