"use strict";
String . prototype . replaceAll ( 0 , x => x ) ; 
