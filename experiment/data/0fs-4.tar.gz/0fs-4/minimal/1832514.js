"use strict";
'' . charAt . call ( 0 ) ; 
