"use strict";
( Object ( function * ( ) { } ) ) . prototype . map ( ) ; 
