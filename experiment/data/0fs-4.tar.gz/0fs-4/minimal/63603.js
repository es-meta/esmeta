"use strict";
Object . preventExtensions ( 0 ) ; 
