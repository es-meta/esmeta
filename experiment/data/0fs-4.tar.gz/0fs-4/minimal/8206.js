"use strict";
Object . hasOwn ( 0 ) ; 
