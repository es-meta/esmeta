"use strict";
[ ] . shift ( ) ; 
