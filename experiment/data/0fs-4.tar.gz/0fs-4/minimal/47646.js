"use strict";
[ ] . concat . call ( ) ; 
