"use strict";
[ x => x ] . copyWithin ( ) ; 
