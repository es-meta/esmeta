"use strict";
Object . isSealed ( 0 ) ; 
