"use strict";
Object . create ( 0 ) ; 
