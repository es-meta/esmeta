"use strict";
ArrayBuffer.prototype.slice.call(0, 0);
