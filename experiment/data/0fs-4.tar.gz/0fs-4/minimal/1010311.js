"use strict";
'' . at ( 0 ) ; 
