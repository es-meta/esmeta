"use strict";
'' . at . call ( 0 ) ; 
