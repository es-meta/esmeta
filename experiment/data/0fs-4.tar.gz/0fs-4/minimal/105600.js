"use strict";
Math . log2 ( 42 ) ; 
