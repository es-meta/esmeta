"use strict";
[ , ] . find ( x => x ) ; 
