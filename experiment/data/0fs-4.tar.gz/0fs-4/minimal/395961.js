"use strict";
Promise . race ( 0 ) ; 
