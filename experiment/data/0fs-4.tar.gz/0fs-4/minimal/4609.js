"use strict";
Iterator.prototype.reduce.call(0, 0);
