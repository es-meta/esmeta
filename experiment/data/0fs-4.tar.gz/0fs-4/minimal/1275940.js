"use strict";
[ x => x ] . __defineSetter__ ( 0 , x => x ) ; 
