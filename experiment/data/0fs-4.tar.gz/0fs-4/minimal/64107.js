"use strict";
BigInt ( - typeof x ) ; 
