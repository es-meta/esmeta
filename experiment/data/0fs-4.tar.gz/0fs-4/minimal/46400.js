"use strict";
Function ( { } ) ; 
