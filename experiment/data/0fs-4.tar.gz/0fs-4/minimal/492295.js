"use strict";
Math . atanh ( 42 ) ; 
