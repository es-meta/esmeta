"use strict";
`` . slice . call ( ) ; 
