"use strict";
'' . charCodeAt ( ) ; 
