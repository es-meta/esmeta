"use strict";
`${ x => x }` . split ( 0 ) ; 
