"use strict";
Math . log10 ( 1 ) ; 
