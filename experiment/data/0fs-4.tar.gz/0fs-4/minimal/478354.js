"use strict";
String . fromCharCode ( 1 ) ; 
