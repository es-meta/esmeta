"use strict";
String . prototype . split ( 0 , 1n ) ; 
