"use strict";
Math . acos ( 0 ) ; 
