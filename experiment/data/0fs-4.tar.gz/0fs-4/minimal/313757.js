"use strict";
[ ] . reverse ( ) ; 
