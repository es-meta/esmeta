"use strict";
( Object ( Int8Array ) ) . prototype . findIndex ( 0 , 0 ) ; 
