"use strict";
encodeURIComponent ( 0 ) ; 
