"use strict";
[ , ] . toSpliced ( ) ; 
