"use strict";
[ ] . toString . call ( true ) ; 
