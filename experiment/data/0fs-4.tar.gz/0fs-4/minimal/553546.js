"use strict";
Number . prototype . toString ( 0 ) ; 
