"use strict";
Set.prototype.union.call(0);
