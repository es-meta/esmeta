"use strict";
[ , ] . find ( x => 1 ) ; 
