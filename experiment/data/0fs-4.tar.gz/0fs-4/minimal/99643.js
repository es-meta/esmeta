"use strict";
Iterator . from ( '' ) ; 
