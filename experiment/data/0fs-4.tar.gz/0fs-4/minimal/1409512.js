"use strict";
[ ] . every ( 0 ) ; 
