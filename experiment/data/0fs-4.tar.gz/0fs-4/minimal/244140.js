"use strict";
ArrayBuffer . isView ( 0 ) ; 
