"use strict";
new Int8Array ( { [ Symbol . iterator ] : ( ) => x } ) ; 
