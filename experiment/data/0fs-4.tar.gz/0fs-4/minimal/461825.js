"use strict";
[ ] . reduceRight ( x => x , x => x ) ; 
