"use strict";
new Int8Array ( 0n ) ; 
