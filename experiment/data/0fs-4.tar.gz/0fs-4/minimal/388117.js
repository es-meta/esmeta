"use strict";
[ ] . indexOf ( ) ; 
