"use strict";
Math.acosh.call(0);
