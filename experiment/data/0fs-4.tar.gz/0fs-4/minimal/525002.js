"use strict";
String . prototype . substring ( 0 , 1n ) ; 
