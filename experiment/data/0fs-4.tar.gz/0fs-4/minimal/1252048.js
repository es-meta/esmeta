"use strict";
( Object ( Int8Array ) ) . of ( ~ typeof x ) ; 
