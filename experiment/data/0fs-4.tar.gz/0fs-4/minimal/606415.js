"use strict";
Error . isError ( { } ) ; 
