"use strict";
0 . toExponential . call ( ) ; 
