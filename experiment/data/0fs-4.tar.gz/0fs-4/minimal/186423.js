"use strict";
Math . min ( 1n ) ; 
