"use strict";
[ x => x ] . fill ( ) ; 
