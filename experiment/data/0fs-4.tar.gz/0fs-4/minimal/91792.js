"use strict";
new Int8Array ( ~ typeof x ) ; 
