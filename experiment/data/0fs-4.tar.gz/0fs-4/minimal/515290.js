"use strict";
String . prototype . indexOf ( 0 , 0n ) ; 
