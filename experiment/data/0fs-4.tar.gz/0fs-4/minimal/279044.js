"use strict";
isFinite ( 0 ) ; 
