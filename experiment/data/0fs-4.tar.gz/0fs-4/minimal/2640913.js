"use strict";
Array . prototype . sort . call ( ( ) => { } , 0 ) ; 
