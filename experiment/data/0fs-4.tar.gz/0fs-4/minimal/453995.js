"use strict";
Promise . reject ( 0 ) ; 
