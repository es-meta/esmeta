"use strict";
Object . defineProperty ( 0 ) ; 
