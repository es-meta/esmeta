"use strict";
1 . valueOf ( 0 ) ; 
