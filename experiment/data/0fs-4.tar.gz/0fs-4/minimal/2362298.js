"use strict";
( Object ( Int8Array ) ) . prototype . every ( 0 , 0 ) ; 
