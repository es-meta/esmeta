"use strict";
'' . charCodeAt . call ( 0 ) ; 
