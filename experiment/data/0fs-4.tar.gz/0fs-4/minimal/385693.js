"use strict";
'' . indexOf ( ) ; 
