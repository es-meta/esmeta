"use strict";
new Promise ( x => x instanceof x ) ; 
