"use strict";
[ ] . find ( [ ] ) ; 
