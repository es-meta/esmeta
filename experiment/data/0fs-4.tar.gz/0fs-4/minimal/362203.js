"use strict";
[ , ] . lastIndexOf ( ) ; 
