"use strict";
Math . imul ( 1n ) ; 
