"use strict";
[ , ] . copyWithin ( ) ; 
