"use strict";
Math.atan.call(0);
