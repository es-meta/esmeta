"use strict";
new BigUint64Array ( 0n ) ; 
