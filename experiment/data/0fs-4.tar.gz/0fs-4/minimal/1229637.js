"use strict";
`` . startsWith . call ( null ) ; 
