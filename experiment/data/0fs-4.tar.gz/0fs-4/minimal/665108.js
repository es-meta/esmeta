"use strict";
Number . prototype . toString ( 1n ) ; 
