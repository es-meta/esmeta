"use strict";
WeakMap.prototype.getOrInsert.call(0, 0, 0);
