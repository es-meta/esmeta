"use strict";
Iterator . concat ( 0 ) ; 
