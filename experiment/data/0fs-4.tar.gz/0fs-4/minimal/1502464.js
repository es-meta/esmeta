"use strict";
0 . toPrecision ( 1 ) ; 
