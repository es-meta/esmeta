"use strict";
Function . bind . call ( 0 ) ; 
