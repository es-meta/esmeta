"use strict";
import ( x => x ) ; 
