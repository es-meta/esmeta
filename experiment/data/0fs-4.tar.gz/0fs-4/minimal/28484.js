"use strict";
Function [ Symbol . hasInstance ] ( ) ; 
