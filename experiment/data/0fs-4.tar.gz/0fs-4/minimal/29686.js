"use strict";
Math . atan2 . call ( 0 , 1 , 1 ) ; 
