"use strict";
Math . atan2 ( { [ Symbol . toPrimitive ] : x => x } ) ; 
