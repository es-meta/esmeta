"use strict";
new Int32Array ( 0n ) ; 
