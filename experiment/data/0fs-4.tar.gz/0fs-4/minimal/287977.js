"use strict";
( Object ( Int8Array ) ) . prototype . fill ( 0 , 0 ) ; 
