"use strict";
[ ] . slice . call ( ) ; 
