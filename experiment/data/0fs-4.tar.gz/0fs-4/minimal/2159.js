"use strict";
String.prototype.trimEnd.call(0);
