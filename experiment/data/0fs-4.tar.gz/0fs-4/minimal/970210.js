"use strict";
[ ] . splice . call ( [ , ] , 0 , 0 , 0 ) ; 
