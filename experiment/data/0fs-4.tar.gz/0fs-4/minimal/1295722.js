"use strict";
1 ( ~ [ x => x ] ) ; 
