"use strict";
class x { } Array . of . call ( function ( ) { return x ; } ) ; 
