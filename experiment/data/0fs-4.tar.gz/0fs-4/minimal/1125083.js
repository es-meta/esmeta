"use strict";
`` . normalize . call ( null ) ; 
