"use strict";
Math . imul ( 0 , 0n ) ; 
