"use strict";
Math . asinh ( 1 ) ; 
