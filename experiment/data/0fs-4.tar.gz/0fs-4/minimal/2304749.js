"use strict";
[ ] . toLocaleString ( 0 , 42 ) ; 
