"use strict";
new Int32Array ( { [ Symbol . iterator ] : async function * ( ) { yield ; } } ) ; 
