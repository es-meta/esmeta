"use strict";
new ArrayBuffer ( 0 , { } ) ; 
