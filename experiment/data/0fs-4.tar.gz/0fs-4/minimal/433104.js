"use strict";
Math . cbrt ( 0 ) ; 
