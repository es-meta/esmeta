"use strict";
Object . isFrozen ( 0 ) ; 
