"use strict";
Promise . try ( async x => x ) ; 
