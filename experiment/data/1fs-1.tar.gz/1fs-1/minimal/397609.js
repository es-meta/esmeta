"use strict";
Promise . try ( 0 ) ; 
