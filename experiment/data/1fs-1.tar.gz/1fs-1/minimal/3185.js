"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.with.call(0);
