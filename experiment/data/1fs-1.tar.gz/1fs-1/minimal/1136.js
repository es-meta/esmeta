"use strict";
Math.hypot.call(0);
