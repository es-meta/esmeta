"use strict";
`` . lastIndexOf ( `` ) ; 
