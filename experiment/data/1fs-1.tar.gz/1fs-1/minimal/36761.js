"use strict";
new URIError ( '' ) ; 
