"use strict";
true . isPrototypeOf ( { } ) ; 
