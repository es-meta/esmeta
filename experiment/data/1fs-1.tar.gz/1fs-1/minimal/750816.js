"use strict";
'' . trim . call ( 0n ) ; 
