"use strict";
String . prototype . includes ( ) ; 
