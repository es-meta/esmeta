"use strict";
[ ] . fill . call ( '' ) ; 
