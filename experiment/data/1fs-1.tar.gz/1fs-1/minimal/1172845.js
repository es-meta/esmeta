"use strict";
Object . assign ( '' , { x : '' } ) ; 
