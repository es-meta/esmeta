"use strict";
Array . prototype . join . call ( null ) ; 
