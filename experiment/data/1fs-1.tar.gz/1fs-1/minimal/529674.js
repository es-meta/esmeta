"use strict";
[ ] . slice ( `` ) ; 
