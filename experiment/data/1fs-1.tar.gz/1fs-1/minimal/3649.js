"use strict";
Set.prototype.isDisjointFrom.call(0);
