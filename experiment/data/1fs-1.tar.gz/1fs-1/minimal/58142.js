"use strict";
Object . entries ( 0 ) ; 
