"use strict";
Math . cos ( 0 ) ; 
