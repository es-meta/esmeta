"use strict";
Object . entries ( { get x ( ) { x ; } } ) ; 
