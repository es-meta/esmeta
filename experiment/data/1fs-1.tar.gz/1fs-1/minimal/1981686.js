"use strict";
'' . search . call ( ) ; 
