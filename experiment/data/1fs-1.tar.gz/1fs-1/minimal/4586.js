"use strict";
Iterator.prototype.forEach.call(0);
