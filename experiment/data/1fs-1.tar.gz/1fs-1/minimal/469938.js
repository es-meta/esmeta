"use strict";
Number ( ) ; 
