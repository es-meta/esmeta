"use strict";
Object . getOwnPropertySymbols ( true ) ; 
