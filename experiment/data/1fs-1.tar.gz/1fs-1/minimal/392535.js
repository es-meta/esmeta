"use strict";
Object . isFrozen ( { } ) ; 
