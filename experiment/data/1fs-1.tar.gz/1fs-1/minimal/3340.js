"use strict";
Uint8Array.fromHex.call(0);
