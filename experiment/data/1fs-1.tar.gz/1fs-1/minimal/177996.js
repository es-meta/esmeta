"use strict";
encodeURI ( 0 ) ; 
