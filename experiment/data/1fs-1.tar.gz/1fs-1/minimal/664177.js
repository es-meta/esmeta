"use strict";
Math . tanh ( 1n ) ; 
