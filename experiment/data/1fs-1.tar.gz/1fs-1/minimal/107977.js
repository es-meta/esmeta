"use strict";
'' . indexOf . call ( { } ) ; 
