"use strict";
Object . defineProperty ( { } ) ; 
