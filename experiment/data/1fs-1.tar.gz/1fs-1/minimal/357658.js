"use strict";
new SyntaxError ( 0 , { } ) ; 
