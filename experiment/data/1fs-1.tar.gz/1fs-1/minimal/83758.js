"use strict";
Number . prototype . toFixed ( { } ) ; 
