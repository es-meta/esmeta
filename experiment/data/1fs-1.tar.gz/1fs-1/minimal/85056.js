"use strict";
Number ( { } ) ; 
