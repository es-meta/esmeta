"use strict";
Array.prototype.toSpliced.call(0, 0, 0, 0);
