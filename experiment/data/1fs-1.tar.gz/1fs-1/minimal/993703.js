"use strict";
`` . padStart . call ( false ) ; 
