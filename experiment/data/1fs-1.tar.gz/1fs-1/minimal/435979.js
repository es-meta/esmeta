"use strict";
String . prototype [ Symbol . iterator ] . call ( false ) ; 
