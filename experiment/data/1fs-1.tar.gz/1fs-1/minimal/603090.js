"use strict";
[ ] . lastIndexOf . call ( 0 ) ; 
