"use strict";
'' . endsWith ( false ) ; 
