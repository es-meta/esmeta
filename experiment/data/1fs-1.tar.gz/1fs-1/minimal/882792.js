"use strict";
'' . padEnd ( 1 , 1n ) ; 
