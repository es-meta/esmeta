"use strict";
Math . pow ( 1n ) ; 
