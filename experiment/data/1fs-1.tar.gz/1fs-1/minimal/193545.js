"use strict";
Math . asinh ( 0 ) ; 
