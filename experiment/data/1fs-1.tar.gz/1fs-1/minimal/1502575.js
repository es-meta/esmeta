"use strict";
[ x => x , , ] . forEach ( x => x ) ; 
