"use strict";
Object . entries ( true ) ; 
