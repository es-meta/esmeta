"use strict";
Object . getOwnPropertySymbols ( { [ ~ typeof x ] : 0 } ) ; 
