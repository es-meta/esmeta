"use strict";
Number . prototype . toFixed ( ~ function x ( ) { ; ; } ) ; 
