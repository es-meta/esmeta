"use strict";
Reflect.defineProperty.call(0, 0, 0);
