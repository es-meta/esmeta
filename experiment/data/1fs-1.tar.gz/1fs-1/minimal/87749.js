"use strict";
Math . log ( [ ] ) ; 
