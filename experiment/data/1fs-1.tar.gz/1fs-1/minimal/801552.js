"use strict";
( Object ( Int8Array ) ) . prototype . subarray ( 0 , 0 ) ; 
