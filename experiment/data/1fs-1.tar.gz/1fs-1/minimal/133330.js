"use strict";
[ , ] . splice ( ) ; 
