"use strict";
Array ( - ! delete delete + typeof typeof typeof x ) ; 
