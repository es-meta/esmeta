"use strict";
0 . __defineGetter__ ( `` . x , x => x ) ; 
