"use strict";
Reflect . deleteProperty ( [ ] ) ; 
