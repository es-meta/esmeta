"use strict";
Math . pow ( 1 , 1 ) ; 
