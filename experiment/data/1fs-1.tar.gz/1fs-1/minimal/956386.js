"use strict";
Object . getOwnPropertyDescriptor ( `` , 0 ) ; 
