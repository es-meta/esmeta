"use strict";
Math . hypot ( 0n ) ; 
