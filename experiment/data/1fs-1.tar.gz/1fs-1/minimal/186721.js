"use strict";
String . prototype . trim ( ) ; 
