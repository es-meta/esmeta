"use strict";
[ ] . toSorted . call ( 0 ) ; 
