"use strict";
Iterator . prototype . drop ( ~ typeof x ) ; 
