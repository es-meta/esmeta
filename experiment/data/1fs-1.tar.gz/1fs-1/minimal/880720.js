"use strict";
String . prototype . charCodeAt ( 0n ) ; 
