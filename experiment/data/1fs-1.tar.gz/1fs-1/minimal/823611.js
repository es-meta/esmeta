"use strict";
; [ x ] = [ ] ; 
