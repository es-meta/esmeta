"use strict";
[ ] . reduce ( 0 ) ; 
