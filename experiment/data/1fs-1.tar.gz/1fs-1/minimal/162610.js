"use strict";
Math . trunc ( true ) ; 
