"use strict";
Object ( 0n ) ; 
