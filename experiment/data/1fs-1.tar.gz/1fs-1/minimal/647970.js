"use strict";
new WeakMap ( [ x => x , ] ) ; 
