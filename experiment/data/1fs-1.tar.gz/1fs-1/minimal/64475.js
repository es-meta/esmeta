"use strict";
Reflect . defineProperty . call ( 0 , [ ] , [ ] ) ; 
