"use strict";
Math . pow ( 0 , ~ typeof x ) ; 
