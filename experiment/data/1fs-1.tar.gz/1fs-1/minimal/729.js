"use strict";
EvalError.call(0);
