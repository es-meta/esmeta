"use strict";
Promise . any ( '' ) ; 
