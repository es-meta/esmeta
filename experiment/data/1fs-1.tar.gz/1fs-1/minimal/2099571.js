"use strict";
( Object ( Int8Array ) ) . from ( { [ Symbol . iterator ] : x => x } ) ; 
