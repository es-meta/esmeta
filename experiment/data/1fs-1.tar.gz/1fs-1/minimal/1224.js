"use strict";
Math.pow.call(0);
