"use strict";
Math . min ( '' ) ; 
