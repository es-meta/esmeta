"use strict";
Uint8Array . fromBase64 ( 0 ) ; 
