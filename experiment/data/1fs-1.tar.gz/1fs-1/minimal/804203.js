"use strict";
new Float16Array ( [ x => x ] ) ; 
