"use strict";
String . prototype . endsWith . call ( null ) ; 
