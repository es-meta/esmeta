"use strict";
[ , ] . splice ( '' ) ; 
