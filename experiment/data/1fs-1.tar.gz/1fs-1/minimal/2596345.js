"use strict";
Object . defineProperty ( [ , ] , 0 , x => x ) ; 
