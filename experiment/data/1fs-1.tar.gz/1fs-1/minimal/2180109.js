"use strict";
[ x => x ] . every ( x => null ) ; 
