"use strict";
Math.cbrt.call(0);
