"use strict";
'' . endsWith ( 0 , null ) ; 
