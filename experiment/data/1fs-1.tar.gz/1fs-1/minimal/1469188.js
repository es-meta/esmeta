"use strict";
Math . pow ( { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
