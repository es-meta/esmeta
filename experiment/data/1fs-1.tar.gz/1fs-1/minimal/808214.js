"use strict";
Object . defineProperties ( [ ] , { length : [ ] } ) ; 
