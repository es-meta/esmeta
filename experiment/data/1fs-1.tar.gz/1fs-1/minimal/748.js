"use strict";
new TypeError(0, 0);
