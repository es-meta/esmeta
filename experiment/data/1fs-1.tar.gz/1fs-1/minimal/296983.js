"use strict";
Math . cosh ( true ) ; 
