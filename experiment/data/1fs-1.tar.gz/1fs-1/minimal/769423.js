"use strict";
Array . prototype . join . call ( true ) ; 
