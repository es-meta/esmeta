"use strict";
[ ] . lastIndexOf . call ( null ) ; 
