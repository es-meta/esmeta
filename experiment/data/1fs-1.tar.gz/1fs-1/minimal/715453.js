"use strict";
`` . split . call ( 0 , 0 ) ; 
