"use strict";
new RangeError ( { } ) ; 
