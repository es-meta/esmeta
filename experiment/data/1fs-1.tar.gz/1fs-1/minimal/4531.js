"use strict";
Iterator.prototype.drop.call(0);
