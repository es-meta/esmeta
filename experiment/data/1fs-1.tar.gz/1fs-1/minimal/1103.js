"use strict";
Math.floor.call(0);
