"use strict";
[ , ] . with ( ) ; 
