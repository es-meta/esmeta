"use strict";
Reflect.getOwnPropertyDescriptor.call(0, 0, 0);
