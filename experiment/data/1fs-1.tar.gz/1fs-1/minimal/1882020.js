"use strict";
[ ] . splice ( 0n ) ; 
