"use strict";
new Float32Array ( 1n ) ; 
