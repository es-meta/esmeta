"use strict";
`` . padStart . call ( 0 ) ; 
