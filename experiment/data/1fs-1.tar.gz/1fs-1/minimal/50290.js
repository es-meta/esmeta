"use strict";
0 . __lookupSetter__ ( true ) ; 
