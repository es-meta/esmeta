"use strict";
`` . split ( false ) ; 
