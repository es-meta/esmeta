"use strict";
Array . prototype . findLast . call ( x => x , x => 1n ) ; 
