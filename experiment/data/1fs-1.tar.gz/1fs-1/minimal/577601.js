"use strict";
Math . log2 ( ~ typeof x ) ; 
