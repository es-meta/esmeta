"use strict";
Set . prototype . add ( 0 ) ; 
