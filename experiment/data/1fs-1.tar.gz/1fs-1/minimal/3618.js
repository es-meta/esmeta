"use strict";
Set.prototype.forEach.call(0, 0, 0);
