"use strict";
new Uint8ClampedArray ( x => x ) ; 
