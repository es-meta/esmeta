"use strict";
String . prototype . match ( ) ; 
