"use strict";
[ ] . splice ( `` , 1 ) ; 
