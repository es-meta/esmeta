"use strict";
Promise . allSettled ( 1n ) ; 
