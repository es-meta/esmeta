"use strict";
Math . tanh ( '' ) ; 
