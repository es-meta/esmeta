"use strict";
Math . trunc ( 0 ) ; 
