"use strict";
Math . tan ( null ) ; 
