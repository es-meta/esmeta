"use strict";
Reflect . construct ( { } ) ; 
