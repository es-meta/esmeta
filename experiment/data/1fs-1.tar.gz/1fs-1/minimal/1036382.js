"use strict";
[ ] . splice ( { } ) ; 
