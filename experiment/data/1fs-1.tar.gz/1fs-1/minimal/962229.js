"use strict";
`` . replace ( 0 , 0 ) ; 
