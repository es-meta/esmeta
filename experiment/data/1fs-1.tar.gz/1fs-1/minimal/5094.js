"use strict";
Proxy.revocable.call(0);
