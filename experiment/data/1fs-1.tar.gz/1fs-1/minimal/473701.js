"use strict";
encodeURI ( [ ] ) ; 
