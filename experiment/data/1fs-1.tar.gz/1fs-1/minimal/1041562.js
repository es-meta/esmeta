"use strict";
new Int32Array ( [ x => x ] ) ; 
