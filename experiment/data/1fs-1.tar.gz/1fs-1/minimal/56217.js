"use strict";
true . propertyIsEnumerable ( ) ; 
