"use strict";
String . prototype . includes ( 0 , null ) ; 
