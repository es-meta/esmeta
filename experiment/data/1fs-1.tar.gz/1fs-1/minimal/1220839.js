"use strict";
[ ] . with ( null ) ; 
