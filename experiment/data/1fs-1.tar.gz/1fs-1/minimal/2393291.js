"use strict";
[ , ] . findLastIndex ( x => 1 ) ; 
