"use strict";
BigInt . asUintN ( { } ) ; 
