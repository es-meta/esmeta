"use strict";
this . hasOwnProperty ( ) ; 
