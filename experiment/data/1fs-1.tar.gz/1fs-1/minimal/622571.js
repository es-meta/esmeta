"use strict";
Number . prototype . valueOf ( 0 ) ; 
