"use strict";
[ ] . toSorted . call ( typeof x ) ; 
