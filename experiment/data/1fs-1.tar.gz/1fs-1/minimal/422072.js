"use strict";
[ x => x ] . indexOf ( ) ; 
