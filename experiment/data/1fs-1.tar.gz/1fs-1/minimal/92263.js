"use strict";
Object . hasOwn ( true ) ; 
