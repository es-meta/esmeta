"use strict";
Reflect.construct.call(0);
