"use strict";
true . toLocaleString ( ) ; 
