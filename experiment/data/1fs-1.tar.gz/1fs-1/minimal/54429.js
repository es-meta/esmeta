"use strict";
new EvalError ( '' ) ; 
