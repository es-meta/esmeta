"use strict";
Uint8Array . fromBase64 ( typeof x ) ; 
