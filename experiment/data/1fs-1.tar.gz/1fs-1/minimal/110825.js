"use strict";
Object . entries ( null ) ; 
