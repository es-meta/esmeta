"use strict";
`` . split ( 0 , - ! + + + - typeof x ) ; 
