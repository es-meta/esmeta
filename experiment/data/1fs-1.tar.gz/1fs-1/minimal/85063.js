"use strict";
Number ( true ) ; 
