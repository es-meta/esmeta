"use strict";
Promise . allSettled ( 0 ) ; 
