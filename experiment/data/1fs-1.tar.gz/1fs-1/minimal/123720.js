"use strict";
'' . toLocaleString ( ) ; 
