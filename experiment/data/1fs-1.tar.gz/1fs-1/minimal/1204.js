"use strict";
Math.max.call(0, 0, 0);
