"use strict";
Function . prototype . call ( 0 ) ; 
