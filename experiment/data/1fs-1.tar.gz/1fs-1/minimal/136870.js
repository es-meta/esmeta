"use strict";
Math . log10 ( 0 ) ; 
