"use strict";
'' . substring . call ( [ ] ) ; 
