"use strict";
[ ] . entries . call ( `` ) ; 
