"use strict";
Iterator.prototype.filter.call(0, 0);
