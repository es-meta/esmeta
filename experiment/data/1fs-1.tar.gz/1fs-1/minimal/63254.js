"use strict";
Promise . any . call ( function ( ) { x ; } ) ; 
