"use strict";
Number . prototype . toExponential ( null ) ; 
