"use strict";
`` . trimStart . call ( 0 ) ; 
