"use strict";
Iterator . prototype . drop ( ) ; 
