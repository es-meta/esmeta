"use strict";
[ x => x ] . every ( x => 1 ) ; 
