"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.findIndex.call(0, 0, 0);
