"use strict";
parseInt ( null ) ; 
