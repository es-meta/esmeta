"use strict";
'' . endsWith ( [ ] ) ; 
