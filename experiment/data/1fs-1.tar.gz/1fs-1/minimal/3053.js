"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.map.call(0);
