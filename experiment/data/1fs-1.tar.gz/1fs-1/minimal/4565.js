"use strict";
Iterator.prototype.find.call(0, 0);
