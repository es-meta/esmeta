"use strict";
Array . prototype . findLast . call ( null ) ; 
