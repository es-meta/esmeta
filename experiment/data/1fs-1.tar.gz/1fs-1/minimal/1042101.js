"use strict";
Math . atan2 . call ( 0 , ~ typeof x , 1 ) ; 
