"use strict";
[ , , ] . toSpliced ( ) ; 
