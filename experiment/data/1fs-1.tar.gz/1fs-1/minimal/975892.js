"use strict";
'' . startsWith ( 1n ) ; 
