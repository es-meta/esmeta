"use strict";
; [ ] = '' ; 
