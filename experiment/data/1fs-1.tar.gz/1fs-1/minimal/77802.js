"use strict";
Array . prototype . pop . call ( typeof x ) ; 
