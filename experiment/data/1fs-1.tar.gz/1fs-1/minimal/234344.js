"use strict";
[ ] . __defineGetter__ ( 0 , x => x ) ; 
