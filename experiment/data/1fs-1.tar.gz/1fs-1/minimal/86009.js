"use strict";
new Uint32Array ( null ) ; 
