"use strict";
Float16Array.call(0);
