"use strict";
true . __lookupSetter__ ( ) ; 
