"use strict";
( Object ( Int8Array ) ) . prototype . find ( 0 , 0 ) ; 
