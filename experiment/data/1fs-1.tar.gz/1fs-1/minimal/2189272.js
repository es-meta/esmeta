"use strict";
[ x => x ] . every ( x => 0n ) ; 
