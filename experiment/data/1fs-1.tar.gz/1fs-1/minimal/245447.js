"use strict";
String . prototype . charAt ( null ) ; 
