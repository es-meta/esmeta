"use strict";
[ ] . copyWithin ( true ) ; 
