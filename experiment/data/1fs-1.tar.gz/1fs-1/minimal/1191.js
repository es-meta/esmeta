"use strict";
Math.log2.call(0);
