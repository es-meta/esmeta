"use strict";
Reflect . get . call ( 0 , { } , false ) ; 
