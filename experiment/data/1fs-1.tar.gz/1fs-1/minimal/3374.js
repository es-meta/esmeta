"use strict";
Uint8Array.prototype.toBase64.call(0, 0);
