"use strict";
`` . repeat ( '' ) ; 
