"use strict";
Promise . try . call ( function ( ) { x ; } ) ; 
