"use strict";
[ , ] . findIndex ( ( ) => x ) ; 
