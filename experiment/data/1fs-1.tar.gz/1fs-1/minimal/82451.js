"use strict";
Object . getOwnPropertyDescriptor ( [ ] ) ; 
