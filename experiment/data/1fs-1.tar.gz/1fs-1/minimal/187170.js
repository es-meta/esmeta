"use strict";
Object . assign ( '' , typeof x ) ; 
