"use strict";
Math . sign ( true ) ; 
