"use strict";
Iterator.prototype.flatMap.call(0);
