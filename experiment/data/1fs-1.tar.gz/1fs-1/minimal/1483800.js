"use strict";
'' . substring . call ( 0 ) ; 
