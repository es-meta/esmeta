"use strict";
[ ] . toSorted . call ( `` ) ; 
