"use strict";
Iterator . prototype . flatMap ( { } ) ; 
