"use strict";
Math . max ( '' ) ; 
