"use strict";
; Number . prototype . toFixed ( 1n ) ; 
