"use strict";
Reflect . isExtensible ( 0 ) ; 
