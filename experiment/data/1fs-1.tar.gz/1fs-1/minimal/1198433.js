"use strict";
`` . repeat ( [ ] ) ; 
