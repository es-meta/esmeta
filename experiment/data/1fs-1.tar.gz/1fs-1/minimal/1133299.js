"use strict";
[ ] . with . call ( true ) ; 
