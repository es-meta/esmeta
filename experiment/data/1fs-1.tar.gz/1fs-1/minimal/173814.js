"use strict";
Reflect . construct ( class { } ) ; 
