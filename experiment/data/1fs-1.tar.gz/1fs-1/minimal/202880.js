"use strict";
Math . cbrt ( { } ) ; 
