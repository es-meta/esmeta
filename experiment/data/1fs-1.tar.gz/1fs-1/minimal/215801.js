"use strict";
new ReferenceError ( 0 , { } ) ; 
