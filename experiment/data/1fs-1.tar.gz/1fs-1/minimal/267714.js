"use strict";
Set . prototype . delete ( 0 ) ; 
