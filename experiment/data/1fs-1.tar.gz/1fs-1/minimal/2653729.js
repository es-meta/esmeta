"use strict";
Number . prototype . toExponential ( ( ) => x ) ; ; 
