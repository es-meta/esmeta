"use strict";
new URIError ( true ) ; 
