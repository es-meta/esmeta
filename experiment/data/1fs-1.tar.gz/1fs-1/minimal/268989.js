"use strict";
Math . max ( 1n ) ; 
