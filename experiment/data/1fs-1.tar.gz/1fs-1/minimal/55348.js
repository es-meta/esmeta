"use strict";
new Int16Array ( 0n ) ; 
