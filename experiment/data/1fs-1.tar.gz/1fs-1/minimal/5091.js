"use strict";
new Proxy(0, 0);
