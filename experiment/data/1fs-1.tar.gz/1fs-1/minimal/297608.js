"use strict";
[ ] . indexOf . call ( 0n ) ; 
