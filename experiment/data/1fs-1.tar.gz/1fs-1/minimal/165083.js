"use strict";
Array . prototype . join . call ( 1n ) ; 
