"use strict";
Object . create ( [ ] , [ ] ) ; 
