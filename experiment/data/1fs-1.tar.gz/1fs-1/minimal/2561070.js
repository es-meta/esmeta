"use strict";
let x ; [ [ x ] ] . flat ( ) ; 
