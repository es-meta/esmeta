"use strict";
`${ x => x }` . toWellFormed ( ) ; 
