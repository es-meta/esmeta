"use strict";
[ ] . splice ( '' , { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
