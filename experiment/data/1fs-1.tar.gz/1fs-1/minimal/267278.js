"use strict";
Error ( 0 , x => x ) ; 
