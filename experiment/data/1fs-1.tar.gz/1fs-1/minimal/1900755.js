"use strict";
WeakMap . prototype . getOrInsert ( ) ; 
