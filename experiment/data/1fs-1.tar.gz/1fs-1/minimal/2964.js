"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.findLast.call(0);
