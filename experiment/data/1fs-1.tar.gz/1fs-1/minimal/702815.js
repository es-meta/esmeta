"use strict";
'' . replaceAll ( { } ) ; 
