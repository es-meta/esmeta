"use strict";
Object . getOwnPropertyNames ( { [ Symbol . replace ] : '' } ) ; 
