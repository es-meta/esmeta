"use strict";
'' . toLocaleString . call ( null ) ; 
