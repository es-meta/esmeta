"use strict";
Math . hypot ( true ) ; 
