"use strict";
Reflect . getOwnPropertyDescriptor . call ( 0 , [ ] , null ) ; 
