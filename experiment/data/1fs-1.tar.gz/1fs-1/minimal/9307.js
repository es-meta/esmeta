"use strict";
new ReferenceError ( [ ] ) ; 
