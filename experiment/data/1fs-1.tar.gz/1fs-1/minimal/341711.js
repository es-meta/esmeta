"use strict";
String . prototype . repeat ( ) ; 
