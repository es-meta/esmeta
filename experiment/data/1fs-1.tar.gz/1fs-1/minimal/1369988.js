"use strict";
`` . toLowerCase . call ( 0 ) ; 
