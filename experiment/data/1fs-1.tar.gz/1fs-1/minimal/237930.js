"use strict";
new BigUint64Array ( ~ typeof x ) ; 
