"use strict";
Array . of . call ( class { } ) ; 
