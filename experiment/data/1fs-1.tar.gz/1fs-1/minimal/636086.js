"use strict";
[ ] . copyWithin . call ( 1n ) ; 
