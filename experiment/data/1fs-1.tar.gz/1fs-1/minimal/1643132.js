"use strict";
'' . endsWith ( 0 , true ) ; 
