"use strict";
Array . prototype . flat ( true ) ; 
