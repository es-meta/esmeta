"use strict";
Iterator . prototype . reduce ( [ ] ) ; 
