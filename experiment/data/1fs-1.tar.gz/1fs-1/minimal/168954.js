"use strict";
Promise . any ( 0n ) ; 
