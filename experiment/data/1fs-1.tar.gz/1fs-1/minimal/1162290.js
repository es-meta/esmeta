"use strict";
[ ] . with ( [ ] ) ; 
