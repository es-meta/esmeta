"use strict";
Promise . any ( function * ( ) { x ; } `` ) ; 
