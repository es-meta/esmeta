"use strict";
[ ] . reduceRight . call ( true ) ; 
