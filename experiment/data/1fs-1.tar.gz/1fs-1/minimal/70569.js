"use strict";
`` . __lookupGetter__ ( `` ) ; 
