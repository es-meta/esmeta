"use strict";
Array . prototype . findLast ( ) ; 
