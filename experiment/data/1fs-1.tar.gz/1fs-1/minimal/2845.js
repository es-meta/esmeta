"use strict";
new (Object.getPrototypeOf(Int8Array));
