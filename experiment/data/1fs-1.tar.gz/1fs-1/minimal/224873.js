"use strict";
Math . sinh ( 0 ) ; 
