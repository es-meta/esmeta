"use strict";
String . prototype . search ( ) ; 
