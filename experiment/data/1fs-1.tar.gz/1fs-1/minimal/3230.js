"use strict";
BigUint64Array.call(0);
