"use strict";
Object . getPrototypeOf ( { } ) ; 
