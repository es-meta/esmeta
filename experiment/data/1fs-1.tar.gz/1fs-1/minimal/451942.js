"use strict";
Iterator . concat ( { } ) ; 
