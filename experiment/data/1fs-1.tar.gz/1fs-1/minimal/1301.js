"use strict";
Math.tan.call(0);
