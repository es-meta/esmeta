"use strict";
new EvalError ( false ) ; 
