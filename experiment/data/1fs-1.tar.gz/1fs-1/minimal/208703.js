"use strict";
Math . cosh ( `` ) ; 
