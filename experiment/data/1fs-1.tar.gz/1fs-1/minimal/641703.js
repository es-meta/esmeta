"use strict";
[ , ] . reverse ( ) ; 
