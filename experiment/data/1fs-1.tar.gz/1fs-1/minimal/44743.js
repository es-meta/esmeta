"use strict";
Array . prototype . pop . call ( 1n ) ; 
