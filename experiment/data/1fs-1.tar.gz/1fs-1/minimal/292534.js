"use strict";
1n . isPrototypeOf ( { } ) ; 
