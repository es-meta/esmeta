"use strict";
String . prototype . replaceAll ( 0 , [ ] ) ; 
