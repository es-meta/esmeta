"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.toReversed.call(0);
