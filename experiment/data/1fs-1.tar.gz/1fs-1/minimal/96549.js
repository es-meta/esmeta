"use strict";
Object . defineProperties ( 0 ) ; 
