"use strict";
Object . fromEntries ( 0 ) ; 
