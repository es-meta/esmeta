"use strict";
Array.prototype.copyWithin.call(0, 0, 0, 0);
