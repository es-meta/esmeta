"use strict";
new Uint32Array(0);
