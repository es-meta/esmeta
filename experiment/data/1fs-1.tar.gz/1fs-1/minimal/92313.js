"use strict";
Promise . try ( function ( ) { } ) ; 
