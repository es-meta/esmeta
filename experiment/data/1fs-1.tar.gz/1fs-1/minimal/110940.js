"use strict";
String . prototype [ Symbol . iterator ] . call ( 1n ) ; 
