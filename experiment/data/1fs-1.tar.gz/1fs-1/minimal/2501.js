"use strict";
Array.prototype.findLast.call(0, 0, 0);
