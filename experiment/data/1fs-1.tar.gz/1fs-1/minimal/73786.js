"use strict";
Object . assign ( 0 , this ) ; 
