"use strict";
Promise . try ( x => import ( x ) ) ; 
