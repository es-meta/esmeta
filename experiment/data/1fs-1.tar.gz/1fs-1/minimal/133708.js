"use strict";
[ ] . splice ( ) ; 
