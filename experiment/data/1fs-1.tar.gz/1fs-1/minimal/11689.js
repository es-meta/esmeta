"use strict";
Array . prototype . findLastIndex . call ( 1n ) ; 
