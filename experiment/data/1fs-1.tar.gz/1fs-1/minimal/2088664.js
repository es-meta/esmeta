"use strict";
[ ] . reduceRight . call ( ) ; 
