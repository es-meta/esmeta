"use strict";
Uint8Array.prototype.setFromBase64.call(0);
