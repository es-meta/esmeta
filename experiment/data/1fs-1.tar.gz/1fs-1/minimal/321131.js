"use strict";
Reflect . deleteProperty ( this ) ; 
