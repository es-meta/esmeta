"use strict";
Math . min ( { } ) ; 
