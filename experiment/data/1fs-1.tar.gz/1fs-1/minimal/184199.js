"use strict";
'' . hasOwnProperty ( 0n ) ; 
