"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.includes.call(0);
