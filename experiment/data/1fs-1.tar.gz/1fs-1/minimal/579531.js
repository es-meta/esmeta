"use strict";
new RangeError ( false ) ; 
