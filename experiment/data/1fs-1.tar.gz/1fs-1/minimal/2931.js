"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.filter.call(0);
