"use strict";
Math . cbrt ( null ) ; 
