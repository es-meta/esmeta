"use strict";
[ ] . toLocaleString ( 0 , 0 ) ; 
