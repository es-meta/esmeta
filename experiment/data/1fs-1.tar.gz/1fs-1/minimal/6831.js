"use strict";
Array . prototype . unshift . call ( '' ) ; 
