"use strict";
`` . replace . call ( ) ; 
