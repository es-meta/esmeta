"use strict";
this . toString . call ( ) ; 
