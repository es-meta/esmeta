"use strict";
encodeURI ( '' ) ; 
