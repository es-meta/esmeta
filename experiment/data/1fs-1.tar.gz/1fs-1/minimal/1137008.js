"use strict";
`` . replace . call ( { } ) ; 
