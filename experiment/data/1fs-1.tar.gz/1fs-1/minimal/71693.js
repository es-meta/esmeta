"use strict";
`` . replace ( `` ) ; 
