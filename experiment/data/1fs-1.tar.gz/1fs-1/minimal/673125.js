"use strict";
[ , ] . find ( x => [ ] ) ; 
