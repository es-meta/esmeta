"use strict";
Math . sqrt ( { [ Symbol . toPrimitive ] : x => x } ) ; 
