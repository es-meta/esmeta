"use strict";
Uint8ClampedArray.call(0);
