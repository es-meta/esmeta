"use strict";
[ ] . flat ( x => x ) ; 
