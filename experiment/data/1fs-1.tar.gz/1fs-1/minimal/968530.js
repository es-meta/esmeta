"use strict";
`${ x => x }` . __defineGetter__ ( 0 , x => x ) ; 
