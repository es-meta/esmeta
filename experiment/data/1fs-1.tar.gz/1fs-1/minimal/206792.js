"use strict";
Math . log ( true ) ; 
