"use strict";
isFinite ( null ) ; 
