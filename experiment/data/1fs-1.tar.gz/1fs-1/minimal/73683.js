"use strict";
Promise . all . call ( class { } ) ; 
