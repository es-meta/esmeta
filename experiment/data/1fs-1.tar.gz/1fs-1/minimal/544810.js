"use strict";
BigInt . asIntN ( 0 , 1n ) ; 
