"use strict";
`` . lastIndexOf ( { } ) ; 
