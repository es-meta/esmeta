"use strict";
new Int32Array ( true ) ; 
