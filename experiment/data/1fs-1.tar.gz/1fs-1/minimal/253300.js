"use strict";
Math . tan ( 1 ) ; 
