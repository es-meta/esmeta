"use strict";
[ x => x ] . pop ( ) ; 
