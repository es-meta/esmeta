"use strict";
[ ] . splice . call ( typeof x , 0 , 1 , 0 ) ; 
