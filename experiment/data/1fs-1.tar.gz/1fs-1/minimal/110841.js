"use strict";
Object . entries ( [ ] ) ; 
