"use strict";
( Object ( Int8Array ) ) . prototype . includes ( 0 , 0 ) ; 
