"use strict";
Array . prototype . flatMap . call ( null ) ; 
