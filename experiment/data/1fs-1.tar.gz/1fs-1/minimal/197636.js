"use strict";
[ ] . slice . call ( null ) ; 
