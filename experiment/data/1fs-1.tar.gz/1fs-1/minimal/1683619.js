"use strict";
Math . imul ( ~ typeof x ) ; 
