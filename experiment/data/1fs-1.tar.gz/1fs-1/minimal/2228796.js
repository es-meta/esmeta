"use strict";
Object . defineProperty . call ( '' , { } , `` , { get : '' } ) ; 
