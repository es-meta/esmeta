"use strict";
this . __lookupGetter__ ( ) ; 
