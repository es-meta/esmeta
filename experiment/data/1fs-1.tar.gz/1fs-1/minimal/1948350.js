"use strict";
[ ] . toLocaleString ( ) ; var x ; 
