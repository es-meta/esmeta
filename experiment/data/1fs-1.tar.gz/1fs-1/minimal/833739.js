"use strict";
Math . f16round ( true ) ; 
