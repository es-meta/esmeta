"use strict";
[ x => x ] . flat ( ) ; 
