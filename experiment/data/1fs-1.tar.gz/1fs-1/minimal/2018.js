"use strict";
String.prototype.padStart.call(0, 0, 0);
