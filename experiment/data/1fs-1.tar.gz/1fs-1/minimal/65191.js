"use strict";
Map . prototype . delete ( 0 ) ; 
