"use strict";
[ ] . toLocaleString ( ) ; 
