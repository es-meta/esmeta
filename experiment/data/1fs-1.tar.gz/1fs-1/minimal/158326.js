"use strict";
( Object ( Int8Array ) ) . prototype . indexOf ( 0 ) ; 
