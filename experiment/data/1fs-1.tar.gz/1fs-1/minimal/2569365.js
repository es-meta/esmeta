"use strict";
Math . log10 ( + ~ ! ! ~ typeof x ) ; 
