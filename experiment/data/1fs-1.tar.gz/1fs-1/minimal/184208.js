"use strict";
'' . hasOwnProperty ( '' ) ; 
