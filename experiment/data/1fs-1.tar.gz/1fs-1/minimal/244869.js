"use strict";
Iterator . prototype . forEach ( ) ; 
