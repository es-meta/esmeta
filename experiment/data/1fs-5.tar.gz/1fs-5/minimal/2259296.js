"use strict";
Object . defineProperty . call ( '' , { } , `` , { configurable : [ ] } ) ; 
