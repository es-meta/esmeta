"use strict";
Promise . reject . call ( function ( ) { } ) ; 
