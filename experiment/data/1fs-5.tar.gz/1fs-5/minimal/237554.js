"use strict";
Function . prototype . apply ( `` ) ; 
