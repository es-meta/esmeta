"use strict";
[ ] . fill . call ( 1n ) ; 
