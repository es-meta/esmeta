"use strict";
[ ] . filter ( '' ) ; 
