"use strict";
Math . sqrt ( { } ) ; 
