"use strict";
String . prototype . split ( 0 , 0n ) ; 
