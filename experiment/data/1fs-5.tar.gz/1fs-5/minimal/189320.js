"use strict";
Number . prototype . toFixed ( null ) ; 
