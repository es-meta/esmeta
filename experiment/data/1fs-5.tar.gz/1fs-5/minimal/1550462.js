"use strict";
`` . replace ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
