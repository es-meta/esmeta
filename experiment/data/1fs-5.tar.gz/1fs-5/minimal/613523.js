"use strict";
`` . replace ( 0 , { } ) ; 
