"use strict";
'' . concat ( ) ; 
