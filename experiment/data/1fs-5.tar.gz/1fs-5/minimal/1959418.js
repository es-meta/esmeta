"use strict";
String . fromCodePoint ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
