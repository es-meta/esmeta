"use strict";
`` . replaceAll ( `` , x => true ) ; 
