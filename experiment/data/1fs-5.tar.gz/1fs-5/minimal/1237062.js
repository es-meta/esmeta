"use strict";
[ ] . forEach . call ( 1n ) ; 
