"use strict";
[ x => x ] . unshift ( '' ) ; 
