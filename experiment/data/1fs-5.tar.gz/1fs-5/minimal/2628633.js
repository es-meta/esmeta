"use strict";
42 . toExponential ( ~ 0 ) ; 
