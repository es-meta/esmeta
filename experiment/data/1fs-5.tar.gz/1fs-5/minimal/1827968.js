"use strict";
[ ] . forEach ( x => x , x => x ) ; 
