"use strict";
Math . imul ( { } ) ; 
