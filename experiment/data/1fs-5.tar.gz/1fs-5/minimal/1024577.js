"use strict";
Array . prototype . at ( null ) ; 
