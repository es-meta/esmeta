"use strict";
isFinite ( `` ) ; 
