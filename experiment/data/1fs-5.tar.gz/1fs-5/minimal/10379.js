"use strict";
Array . fromAsync ( [ ] ) ; 
