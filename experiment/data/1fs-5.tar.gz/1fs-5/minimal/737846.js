"use strict";
BigInt . asIntN ( 0 , true ) ; 
