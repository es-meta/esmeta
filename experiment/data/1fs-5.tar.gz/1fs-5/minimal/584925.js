"use strict";
Object . create ( { } , null ) ; 
