"use strict";
Object . keys ( null ) ; 
