"use strict";
Math . floor ( true ) ; 
