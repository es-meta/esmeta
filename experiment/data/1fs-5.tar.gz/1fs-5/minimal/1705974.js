"use strict";
Object . getOwnPropertyNames ( { [ Symbol . match ] : '' } ) ; 
