"use strict";
[ , ] . findIndex ( x => `${ x }` ) ; 
