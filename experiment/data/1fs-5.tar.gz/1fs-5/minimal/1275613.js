"use strict";
Map . prototype . clear ( ) ; 
