"use strict";
Array . prototype . map . call ( true ) ; 
