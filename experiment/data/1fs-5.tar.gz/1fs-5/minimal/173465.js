"use strict";
Object . hasOwn ( `` ) ; 
