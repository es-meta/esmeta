"use strict";
[ ] . toReversed . call ( 1n ) ; 
