"use strict";
Math . sin ( 1n ) ; 
