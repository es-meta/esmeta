"use strict";
new RangeError ( 0 , [ ] ) ; 
