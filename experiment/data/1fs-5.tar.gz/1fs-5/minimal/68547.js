"use strict";
String . prototype . match . call ( null ) ; 
