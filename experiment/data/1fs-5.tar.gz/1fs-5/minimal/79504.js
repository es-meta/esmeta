"use strict";
BigInt . asUintN ( 1 ) ; 
