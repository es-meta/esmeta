"use strict";
new AggregateError ( `` , { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
