"use strict";
'' . padStart ( 1 , [ ] ) ; 
