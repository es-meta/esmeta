"use strict";
Math . log1p ( null ) ; 
