"use strict";
new Uint32Array ( ~ typeof x ) ; 
