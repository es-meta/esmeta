"use strict";
Promise . all ( { [ Symbol . iterator ] : `` } ) ; 
