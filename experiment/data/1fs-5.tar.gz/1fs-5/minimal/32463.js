"use strict";
Promise . reject . call ( class { } ) ; 
