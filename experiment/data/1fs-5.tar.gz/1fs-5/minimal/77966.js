"use strict";
Object . values ( typeof x ) ; 
