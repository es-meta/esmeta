"use strict";
Object . getOwnPropertyDescriptors ( [ x => x ] ) ; 
