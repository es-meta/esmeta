"use strict";
[ ] . findIndex . call ( 1 ) ; 
