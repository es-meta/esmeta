"use strict";
[ ] . with ( '' ) ; 
