"use strict";
Array . prototype . some . call ( 0n ) ; 
