"use strict";
Math . sumPrecise ( [ , ] ) ; 
