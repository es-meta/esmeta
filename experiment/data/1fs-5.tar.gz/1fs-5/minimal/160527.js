"use strict";
Number . prototype . valueOf ( '' ) ; 
