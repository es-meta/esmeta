"use strict";
new BigInt64Array ( [ x => x ] ) ; 
