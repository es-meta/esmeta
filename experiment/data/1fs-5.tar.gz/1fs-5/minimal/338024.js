"use strict";
[ ] . unshift . call ( true ) ; 
