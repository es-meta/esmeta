"use strict";
Object . setPrototypeOf ( 0 , { } ) ; 
