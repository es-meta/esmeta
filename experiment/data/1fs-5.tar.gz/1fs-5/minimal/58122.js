"use strict";
Math . pow ( 0 , 1n ) ; 
