"use strict";
[ ] . push ( 0 ) ; 
