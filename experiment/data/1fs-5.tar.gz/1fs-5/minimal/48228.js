"use strict";
Array . prototype . sort . call ( null ) ; 
