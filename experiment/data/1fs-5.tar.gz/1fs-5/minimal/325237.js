"use strict";
`` . toLowerCase . call ( [ ] ) ; 
