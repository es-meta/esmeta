"use strict";
`` . hasOwnProperty ( '' ) ; 
