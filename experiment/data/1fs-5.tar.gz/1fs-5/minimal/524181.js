"use strict";
Array . prototype . fill ( 0 , { } ) ; 
