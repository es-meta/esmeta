"use strict";
Math . max ( true ) ; 
