"use strict";
Object . getOwnPropertyDescriptor ( '' ) ; 
