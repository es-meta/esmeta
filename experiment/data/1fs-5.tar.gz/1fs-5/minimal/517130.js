"use strict";
1 . __defineGetter__ ( 0n , x => x ) ; 
