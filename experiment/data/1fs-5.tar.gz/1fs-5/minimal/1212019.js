"use strict";
[ ] . toReversed . call ( typeof x ) ; 
