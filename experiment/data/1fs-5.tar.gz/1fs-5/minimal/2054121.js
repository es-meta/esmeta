"use strict";
Map . prototype . get ( ) ; 
