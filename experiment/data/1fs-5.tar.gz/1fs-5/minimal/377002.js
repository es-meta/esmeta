"use strict";
Iterator . prototype . take ( null ) ; 
