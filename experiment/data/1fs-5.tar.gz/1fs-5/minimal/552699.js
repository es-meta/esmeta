"use strict";
[ ] . pop . call ( null ) ; 
