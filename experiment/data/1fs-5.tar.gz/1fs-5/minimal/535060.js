"use strict";
Math . acosh ( { } ) ; 
