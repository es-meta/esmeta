"use strict";
Object . defineProperties . call ( 0 , { } , this ) ; 
