"use strict";
Array . prototype . every . call ( '' ) ; 
