"use strict";
new EvalError ( { } ) ; 
