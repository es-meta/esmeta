"use strict";
Math . tan ( [ ] ) ; 
