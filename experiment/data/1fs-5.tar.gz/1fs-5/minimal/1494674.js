"use strict";
[ ] . with . call ( null ) ; 
