"use strict";
[ ] . sort . call ( delete typeof x ) ; 
