"use strict";
`` . search ( { } ) ; 
