"use strict";
[ , ] . forEach ( ) ; 
