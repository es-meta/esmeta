"use strict";
Object . defineProperties . call ( 0 , { } , typeof x ) ; 
