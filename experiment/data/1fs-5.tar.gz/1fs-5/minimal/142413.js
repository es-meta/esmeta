"use strict";
String . prototype . startsWith ( true ) ; 
