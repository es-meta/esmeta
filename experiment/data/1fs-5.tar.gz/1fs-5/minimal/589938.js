"use strict";
[ ] . copyWithin ( ~ typeof x ) ; 
