"use strict";
Array . fromAsync ( x => x , function ( ) { } ) ; 
