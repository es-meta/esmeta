"use strict";
'' . __lookupSetter__ ( null ) ; 
