"use strict";
Promise . any ( true ) ; 
