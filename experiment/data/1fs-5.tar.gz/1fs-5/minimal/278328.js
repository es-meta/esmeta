"use strict";
parseInt ( [ ] ) ; 
