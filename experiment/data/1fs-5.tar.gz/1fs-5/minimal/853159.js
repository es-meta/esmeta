"use strict";
Math . tanh ( true ) ; 
