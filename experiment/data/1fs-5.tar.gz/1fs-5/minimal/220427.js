"use strict";
Number . prototype . toPrecision ( [ ] ) ; 
