"use strict";
Map . prototype . has ( 0 ) ; 
