"use strict";
`` . substring ( x => x , ) ; 
