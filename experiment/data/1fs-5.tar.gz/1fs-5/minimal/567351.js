"use strict";
'' . padStart ( 1 , 0 ) ; 
