"use strict";
[ ] . fill . call ( true ) ; 
