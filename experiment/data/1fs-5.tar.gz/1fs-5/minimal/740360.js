"use strict";
[ ] . toSpliced . call ( 1n ) ; 
