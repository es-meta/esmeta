"use strict";
Array . fromAsync ( 0 ) ; 
