"use strict";
Math . atanh ( null ) ; 
