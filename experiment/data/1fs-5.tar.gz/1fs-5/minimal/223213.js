"use strict";
Object . assign ( 0 , typeof x ) ; 
