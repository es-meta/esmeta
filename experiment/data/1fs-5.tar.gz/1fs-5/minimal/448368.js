"use strict";
new URIError ( false ) ; 
