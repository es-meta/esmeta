"use strict";
Math . asinh ( `` ) ; 
