"use strict";
Set . prototype . forEach ( ) ; 
