"use strict";
String . prototype . match . call ( 1n ) ; 
