"use strict";
Object . hasOwn ( typeof x , 0 ) ; 
