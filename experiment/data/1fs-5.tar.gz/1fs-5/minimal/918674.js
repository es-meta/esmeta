"use strict";
[ ] . push . call ( `` , 0 ) ; 
