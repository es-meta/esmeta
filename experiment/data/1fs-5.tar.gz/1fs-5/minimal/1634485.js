"use strict";
Array . prototype . splice . call ( [ x => x ] , 0 , 0 , 0 ) ; 
