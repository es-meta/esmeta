"use strict";
new Set ( function * ( ) { } `` ) ; 
