"use strict";
1 . __lookupGetter__ ( ) ; 
