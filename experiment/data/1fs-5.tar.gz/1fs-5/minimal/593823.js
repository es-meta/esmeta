"use strict";
String . prototype . lastIndexOf ( 0 , 1 ) ; 
