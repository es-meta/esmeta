"use strict";
String . call ( `` , { [ Symbol . toPrimitive ] : class { } } ) ; 
