"use strict";
`` . slice ( x => x , x => x ) ; 
