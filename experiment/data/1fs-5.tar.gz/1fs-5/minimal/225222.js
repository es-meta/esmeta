"use strict";
Math . cos ( `` ) ; 
