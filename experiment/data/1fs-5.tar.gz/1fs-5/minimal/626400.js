"use strict";
1 . __defineSetter__ ( [ ] , x => x ) ; 
