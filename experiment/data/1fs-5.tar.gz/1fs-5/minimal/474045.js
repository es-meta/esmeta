"use strict";
Map . prototype . getOrInsert ( ) ; 
