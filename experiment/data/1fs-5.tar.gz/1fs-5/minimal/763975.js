"use strict";
'' . startsWith ( x => x ) ; 
