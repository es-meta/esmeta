"use strict";
Object . seal ( 0 ) ; 
