"use strict";
`` . matchAll . call ( true ) ; 
