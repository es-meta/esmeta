"use strict";
Object ( [ ] ) ; 
