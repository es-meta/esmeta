"use strict";
Math . imul ( 1 , { [ Symbol . toPrimitive ] : function ( ) { } } ) ; 
