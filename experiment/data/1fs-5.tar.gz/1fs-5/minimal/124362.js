"use strict";
Reflect . get . call ( 0 , { } , '' ) ; 
