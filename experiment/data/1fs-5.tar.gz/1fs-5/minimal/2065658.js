"use strict";
1 ( ~ [ , ] ) ; 
