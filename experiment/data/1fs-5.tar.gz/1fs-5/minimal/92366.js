"use strict";
Object . values ( true ) ; 
