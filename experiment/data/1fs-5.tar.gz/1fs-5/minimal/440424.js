"use strict";
`` . hasOwnProperty ( 1n ) ; 
