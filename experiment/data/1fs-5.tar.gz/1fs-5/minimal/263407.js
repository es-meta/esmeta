"use strict";
Math . sin ( '' ) ; 
