"use strict";
isNaN ( '' ) ; 
