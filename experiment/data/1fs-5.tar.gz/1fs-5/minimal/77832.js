"use strict";
Object . assign ( '' ) ; 
