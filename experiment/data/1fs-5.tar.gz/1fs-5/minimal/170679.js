"use strict";
Reflect . getPrototypeOf ( 0 ) ; 
