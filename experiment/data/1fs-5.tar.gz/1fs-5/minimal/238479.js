"use strict";
`` . hasOwnProperty ( { } ) ; 
