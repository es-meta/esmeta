"use strict";
'' . search . call ( { } ) ; 
