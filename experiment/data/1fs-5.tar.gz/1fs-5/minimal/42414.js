"use strict";
[ , ] . toLocaleString ( ) ; 
