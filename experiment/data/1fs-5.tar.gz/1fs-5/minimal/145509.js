"use strict";
String . prototype . startsWith ( `` ) ; 
