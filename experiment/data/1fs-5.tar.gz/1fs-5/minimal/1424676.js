"use strict";
[ ] . forEach ( 0 ) ; 
