"use strict";
this . toString . call ( 0n ) ; 
