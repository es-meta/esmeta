"use strict";
'' . trimStart ( ) ; 
