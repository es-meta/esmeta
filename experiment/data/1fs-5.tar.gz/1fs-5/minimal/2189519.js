"use strict";
Object . defineProperty . call ( '' , this , typeof x , { configurable : 0 } ) ; 
