"use strict";
Math . hypot ( void typeof x ) ; 
