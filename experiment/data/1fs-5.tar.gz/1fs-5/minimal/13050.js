"use strict";
Array . fromAsync ( true ) ; 
