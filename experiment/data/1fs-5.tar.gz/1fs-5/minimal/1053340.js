"use strict";
String . prototype . codePointAt . call ( null ) ; 
