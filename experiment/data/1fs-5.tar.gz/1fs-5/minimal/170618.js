"use strict";
Math . sumPrecise ( '' ) ; 
