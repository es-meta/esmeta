"use strict";
[ ] . __defineSetter__ ( '' , x => x ) ; 
