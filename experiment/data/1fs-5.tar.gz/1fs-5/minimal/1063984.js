"use strict";
Array . from . call ( `` , { length : true } ) ; 
