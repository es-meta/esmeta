"use strict";
Math . trunc ( null ) ; 
