"use strict";
new Function ( 0n ) ; 
