"use strict";
`` . replaceAll ( `` , ( ) => x ) ; 
