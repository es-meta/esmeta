"use strict";
encodeURIComponent ( { [ Symbol . toPrimitive ] : class { } } ) ; 
