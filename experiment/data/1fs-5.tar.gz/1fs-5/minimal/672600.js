"use strict";
Math . imul ( '' ) ; 
