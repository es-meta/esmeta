"use strict";
Reflect . set . call ( `` , { } , { [ Symbol . toPrimitive ] : `` } ) ; 
