"use strict";
Array . prototype . fill ( 0 , 0n ) ; 
