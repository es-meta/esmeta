"use strict";
ArrayBuffer . prototype . slice ( ) ; 
