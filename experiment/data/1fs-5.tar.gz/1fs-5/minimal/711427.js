"use strict";
Math . acosh ( true ) ; 
