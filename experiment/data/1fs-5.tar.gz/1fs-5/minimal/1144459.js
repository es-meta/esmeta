"use strict";
String . prototype . endsWith ( `` , { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
