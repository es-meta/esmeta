"use strict";
String . prototype . replaceAll ( `` , class { } ) ; 
