"use strict";
0 . toString . call ( ) ; 
