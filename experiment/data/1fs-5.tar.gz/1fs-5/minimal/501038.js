"use strict";
`` . propertyIsEnumerable ( false ) ; 
