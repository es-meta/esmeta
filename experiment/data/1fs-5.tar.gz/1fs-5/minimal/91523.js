"use strict";
Object . getOwnPropertyNames ( [ ] ) ; 
