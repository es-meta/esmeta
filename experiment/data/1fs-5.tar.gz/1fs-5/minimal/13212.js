"use strict";
new BigInt64Array ( 1 ) ; 
