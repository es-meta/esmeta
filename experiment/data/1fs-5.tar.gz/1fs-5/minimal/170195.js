"use strict";
Math . round ( { } ) ; 
