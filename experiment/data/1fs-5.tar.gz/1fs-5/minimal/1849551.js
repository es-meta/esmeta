"use strict";
Object . seal ( { [ Symbol . species ] : '' } ) ; 
