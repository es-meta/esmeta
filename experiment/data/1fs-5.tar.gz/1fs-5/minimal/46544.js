"use strict";
[ ] . concat . call ( 0 ) ; 
