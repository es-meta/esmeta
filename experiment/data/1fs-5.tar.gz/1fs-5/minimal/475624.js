"use strict";
Promise . try . call ( function ( ) { ; return { } ; } ) ; 
