"use strict";
; [ ] = [ ] ; 
