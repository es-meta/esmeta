"use strict";
`` . slice ( `` ) ; 
