"use strict";
`` . matchAll . call ( 0 ) ; 
