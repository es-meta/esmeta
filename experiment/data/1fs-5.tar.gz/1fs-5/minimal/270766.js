"use strict";
( Object ( Int8Array ) ) . of ( 1n ) ; 
