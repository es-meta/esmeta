"use strict";
Array . fromAsync . call ( function ( ) { x ; } , 0 ) ; 
