"use strict";
new WeakSet ( { [ Symbol . iterator ] : '' } ) ; 
