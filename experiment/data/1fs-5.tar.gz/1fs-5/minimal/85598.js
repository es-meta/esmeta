"use strict";
Uint8Array . fromBase64 . call ( 0 , '' , { } ) ; 
