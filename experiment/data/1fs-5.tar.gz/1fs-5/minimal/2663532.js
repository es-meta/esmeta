"use strict";
[ , ] . reduce ( x => x , x => x ) ; 
