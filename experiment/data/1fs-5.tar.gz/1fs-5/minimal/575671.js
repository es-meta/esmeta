"use strict";
Object . values ( { [ Symbol . asyncIterator ] : `` } ) ; 
