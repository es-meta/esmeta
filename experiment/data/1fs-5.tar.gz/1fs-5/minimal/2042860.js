"use strict";
'' . padEnd ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
