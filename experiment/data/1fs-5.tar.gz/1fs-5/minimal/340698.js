"use strict";
Array . prototype . flatMap ( [ ] ) ; 
