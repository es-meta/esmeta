"use strict";
1 . __defineGetter__ ( 0 , x => x ) ; 
