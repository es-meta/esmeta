"use strict";
`` . toLowerCase . call ( 1n ) ; 
