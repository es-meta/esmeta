"use strict";
1 . isPrototypeOf ( ) ; 
