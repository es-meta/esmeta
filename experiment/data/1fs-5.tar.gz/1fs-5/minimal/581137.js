"use strict";
Object . create ( { } , typeof x ) ; 
