"use strict";
Math . imul ( 0 , { [ Symbol . toPrimitive ] : x => x } ) ; 
