"use strict";
Math . ceil ( 1 ) ; 
