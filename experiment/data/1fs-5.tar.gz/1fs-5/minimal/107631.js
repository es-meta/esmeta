"use strict";
Array . prototype . reduce . call ( typeof x , class { } ) ; 
