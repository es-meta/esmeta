"use strict";
Reflect . has . call ( 0 , { } , true ) ; 
