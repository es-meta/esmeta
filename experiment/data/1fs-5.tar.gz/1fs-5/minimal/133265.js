"use strict";
new SyntaxError ( '' ) ; 
