"use strict";
Object . setPrototypeOf ( null ) ; 
