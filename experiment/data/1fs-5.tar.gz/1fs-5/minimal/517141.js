"use strict";
1 . __defineGetter__ ( [ ] , x => x ) ; 
