"use strict";
Array ( 1 ) ; 
