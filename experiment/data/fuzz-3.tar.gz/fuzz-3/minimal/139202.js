"use strict";
'' . search ( ) ; 
