"use strict";
[ ] . forEach . call ( ) ; 
