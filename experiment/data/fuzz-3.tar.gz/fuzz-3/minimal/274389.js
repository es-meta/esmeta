"use strict";
isNaN ( ) ; 
