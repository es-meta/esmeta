"use strict";
Promise . reject ( ) ; 
