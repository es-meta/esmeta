"use strict";
Array . from ( '' ) ; 
