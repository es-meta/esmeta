"use strict";
[ ] . fill . call ( ) ; 
