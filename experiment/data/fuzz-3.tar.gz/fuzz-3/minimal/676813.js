"use strict";
'' . replace ( `` , ( ) => x ) ; 
