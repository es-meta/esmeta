"use strict";
Error ( null ) ; 
