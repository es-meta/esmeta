"use strict";
Promise . allSettled ( [ , ] ) ; 
