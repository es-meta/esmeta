"use strict";
( ( ... x ) => x ) ( `` ) ; 
