"use strict";
Object . getOwnPropertyNames ( `` ) ; 
