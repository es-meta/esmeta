"use strict";
`` . indexOf ( ) ; 
