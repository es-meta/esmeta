"use strict";
[ ] . unshift . call ( '' ) ; 
