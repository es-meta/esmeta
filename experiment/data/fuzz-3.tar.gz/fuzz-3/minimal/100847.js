"use strict";
Reflect . defineProperty ( { } ) ; 
