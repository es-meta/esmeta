"use strict";
'' . startsWith . call ( ) ; 
