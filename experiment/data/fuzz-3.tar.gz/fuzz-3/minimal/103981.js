"use strict";
Promise . any ( `` ) ; 
