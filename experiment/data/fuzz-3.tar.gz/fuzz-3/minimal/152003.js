"use strict";
'' . endsWith ( ) ; 
