"use strict";
[ ] . at . call ( ) ; 
