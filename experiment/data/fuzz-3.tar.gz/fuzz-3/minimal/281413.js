"use strict";
isNaN ( [ ] ) ; 
