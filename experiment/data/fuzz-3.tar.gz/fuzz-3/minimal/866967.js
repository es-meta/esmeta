"use strict";
'' . startsWith . call ( { } ) ; 
