"use strict";
[ ] . fill ( ) ; 
