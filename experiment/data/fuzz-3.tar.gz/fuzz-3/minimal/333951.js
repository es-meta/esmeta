"use strict";
[ ] . toSorted ( ) ; 
