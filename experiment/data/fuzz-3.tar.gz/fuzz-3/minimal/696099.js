"use strict";
`` . trimEnd ( ) ; 
