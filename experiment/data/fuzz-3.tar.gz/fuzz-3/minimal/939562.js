"use strict";
; [ , ] = [ ] ; 
