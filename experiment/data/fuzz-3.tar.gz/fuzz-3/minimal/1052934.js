"use strict";
[ ] . shift . call ( ) ; 
