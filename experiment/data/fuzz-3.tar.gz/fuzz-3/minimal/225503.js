"use strict";
'' . normalize . call ( ) ; 
