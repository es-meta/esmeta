"use strict";
'' . padEnd . call ( ) ; 
