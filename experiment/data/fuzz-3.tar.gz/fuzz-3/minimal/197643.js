"use strict";
'' . split ( ) ; 
