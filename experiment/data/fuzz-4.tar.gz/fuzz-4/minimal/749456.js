"use strict";
[ ] . findIndex ( ) ; 
