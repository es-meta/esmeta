"use strict";
[ ] . slice ( ) ; 
