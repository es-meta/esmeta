"use strict";
[ , , ] . shift ( ) ; 
