"use strict";
`` . toString . call ( ) ; 
