"use strict";
Array . from ( x => x , x => x ) ; 
