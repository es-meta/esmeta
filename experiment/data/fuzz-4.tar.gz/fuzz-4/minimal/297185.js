"use strict";
[ ] . splice . call ( ) ; 
