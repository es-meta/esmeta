"use strict";
new Object;
