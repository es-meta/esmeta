"use strict";
( Object ( Int8Array ) ) . prototype . lastIndexOf ( 0 , 0 ) ; 
