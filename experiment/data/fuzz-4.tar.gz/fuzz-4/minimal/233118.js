"use strict";
[ ] . copyWithin . call ( ) ; 
