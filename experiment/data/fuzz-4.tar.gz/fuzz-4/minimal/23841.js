"use strict";
new WeakMap ( '' ) ; 
