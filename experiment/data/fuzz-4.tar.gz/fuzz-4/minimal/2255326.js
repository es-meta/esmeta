"use strict";
'' . toLowerCase ( ( ) => { } ) ; 
