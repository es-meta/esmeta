"use strict";
'' . charCodeAt . call ( ) ; 
