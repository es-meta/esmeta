"use strict";
[ ] . push ( ) ; 
