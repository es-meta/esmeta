"use strict";
[ ] . map . call ( ) ; 
