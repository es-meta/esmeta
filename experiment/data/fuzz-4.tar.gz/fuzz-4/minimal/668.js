"use strict";
new Error;
