"use strict";
[ , ] . toReversed ( ) ; 
