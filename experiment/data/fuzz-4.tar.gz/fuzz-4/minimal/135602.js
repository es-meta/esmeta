"use strict";
this . propertyIsEnumerable ( ) ; 
