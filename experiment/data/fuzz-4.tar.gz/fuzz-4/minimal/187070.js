"use strict";
eval . call ( 0 , typeof class { } ) ; 
