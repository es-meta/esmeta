"use strict";
String . fromCodePoint ( ~ '' ) ; 
