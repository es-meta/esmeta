"use strict";
[ ] . every . call ( ) ; 
