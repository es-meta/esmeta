"use strict";
[ ] . unshift ( ) ; 
