"use strict";
[ ] . flat ( '' ) ; 
