"use strict";
Array ( ) ; 
