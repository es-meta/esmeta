"use strict";
new Number;
