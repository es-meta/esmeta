"use strict";
Object ( true ) ; 
