"use strict";
new Array;
