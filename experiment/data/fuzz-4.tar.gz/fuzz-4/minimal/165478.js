"use strict";
Object . freeze ( [ ] ) ; 
