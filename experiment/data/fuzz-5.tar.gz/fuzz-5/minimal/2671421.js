"use strict";
[ ] . pop . call ( '' ) ; 
