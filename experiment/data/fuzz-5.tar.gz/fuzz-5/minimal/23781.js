"use strict";
Error ( [ , ] ) ; 
