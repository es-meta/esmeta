"use strict";
; '' . search . call ( ) ; 
