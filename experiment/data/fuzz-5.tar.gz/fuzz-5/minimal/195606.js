"use strict";
[ ] . with . call ( ) ; 
