"use strict";
Object ( '' ) ; 
