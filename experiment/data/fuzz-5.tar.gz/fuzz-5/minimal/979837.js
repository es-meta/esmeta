"use strict";
Reflect . setPrototypeOf ( { } , { } ) ; 
