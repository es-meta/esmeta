"use strict";
`` . endsWith ( '' ) ; 
