"use strict";
Iterator . from ( { } ) ; 
