"use strict";
'' . propertyIsEnumerable ( ) ; 
