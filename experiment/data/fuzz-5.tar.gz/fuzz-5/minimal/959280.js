"use strict";
`` . normalize . call ( ) ; 
