"use strict";
'' . charAt ( ) ; 
