"use strict";
[ , ] . flat ( ) ; 
