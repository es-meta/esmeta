"use strict";
Reflect . get ( { } ) ; 
