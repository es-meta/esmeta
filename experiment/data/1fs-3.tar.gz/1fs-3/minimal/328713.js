"use strict";
parseFloat ( null ) ; 
