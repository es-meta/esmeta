"use strict";
new BigInt64Array ( ~ typeof x ) ; 
