"use strict";
new Uint8Array ( null ) ; 
