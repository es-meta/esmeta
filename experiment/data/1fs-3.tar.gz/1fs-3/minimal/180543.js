"use strict";
`` . lastIndexOf ( true ) ; 
