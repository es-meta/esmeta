"use strict";
Array . prototype . unshift . call ( true ) ; 
