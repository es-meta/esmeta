"use strict";
`` . match . call ( 0n ) ; 
