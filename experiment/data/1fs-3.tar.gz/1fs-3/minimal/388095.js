"use strict";
0n . __lookupSetter__ ( ) ; 
