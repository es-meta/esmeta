"use strict";
new Uint8Array ( 1n ) ; 
