"use strict";
'' . lastIndexOf ( '' ) ; 
