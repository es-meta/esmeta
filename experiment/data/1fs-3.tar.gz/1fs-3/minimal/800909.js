"use strict";
[ , ] . every ( ) ; 
