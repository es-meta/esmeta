"use strict";
`` . match . call ( [ ] ) ; 
