"use strict";
Iterator . prototype . drop ( 1 ) ; 
