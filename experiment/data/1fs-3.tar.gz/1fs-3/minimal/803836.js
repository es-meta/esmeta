"use strict";
[ ] . sort . call ( 1 ) ; 
