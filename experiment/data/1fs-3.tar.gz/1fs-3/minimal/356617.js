"use strict";
Math . ceil ( true ) ; 
