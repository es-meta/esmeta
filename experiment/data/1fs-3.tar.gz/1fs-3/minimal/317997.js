"use strict";
Number . prototype . toExponential ( `` ) ; 
