"use strict";
new ArrayBuffer ( null ) ; 
