"use strict";
Number . prototype . toString ( ~ typeof x ) ; 
