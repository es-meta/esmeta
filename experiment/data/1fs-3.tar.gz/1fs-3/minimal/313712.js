"use strict";
Math . atan2 ( true ) ; 
