"use strict";
Array . prototype . filter . call ( { length : true } ) ; 
