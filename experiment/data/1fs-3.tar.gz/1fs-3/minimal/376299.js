"use strict";
0n . __defineSetter__ ( ) ; 
