"use strict";
[ ] . at . call ( '' ) ; 
