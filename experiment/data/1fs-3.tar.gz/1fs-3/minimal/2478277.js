"use strict";
Object . entries ( { set x ( x ) { } } ) ; 
