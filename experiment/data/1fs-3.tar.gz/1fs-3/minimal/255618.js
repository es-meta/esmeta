"use strict";
WeakMap . prototype . getOrInsert ( 0 ) ; 
