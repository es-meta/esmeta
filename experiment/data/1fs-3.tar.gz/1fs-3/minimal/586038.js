"use strict";
Function ( true ) ; 
