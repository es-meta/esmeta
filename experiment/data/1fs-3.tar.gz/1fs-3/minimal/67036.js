"use strict";
[ ] . hasOwnProperty ( ) ; 
