"use strict";
String ( [ ] ) ; 
