"use strict";
[ , , ] . toReversed ( ) ; 
