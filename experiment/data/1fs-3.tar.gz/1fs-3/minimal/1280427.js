"use strict";
`` . __lookupGetter__ . call ( typeof x , 1 ) ; 
