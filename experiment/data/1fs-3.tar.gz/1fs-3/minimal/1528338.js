"use strict";
'' . charAt ( [ ] ) ; 
