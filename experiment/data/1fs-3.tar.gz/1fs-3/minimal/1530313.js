"use strict";
[ ] . at ( { [ Symbol . toPrimitive ] : class { } } ) ; 
