"use strict";
new WeakSet ( [ , ] ) ; 
