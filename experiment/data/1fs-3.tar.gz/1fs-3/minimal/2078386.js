"use strict";
[ x => x , x => x , , ] . reduceRight ( ( ) => x ) ; 
