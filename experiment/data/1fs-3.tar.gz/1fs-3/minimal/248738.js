"use strict";
Math . atan ( { } ) ; 
