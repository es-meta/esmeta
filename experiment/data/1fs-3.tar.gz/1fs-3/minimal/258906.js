"use strict";
Math . atan ( null ) ; 
