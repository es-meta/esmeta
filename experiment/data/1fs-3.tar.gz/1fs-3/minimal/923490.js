"use strict";
`` . endsWith ( 1n ) ; 
