"use strict";
[ ] . forEach . call ( null ) ; 
