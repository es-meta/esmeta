"use strict";
[ , ] . findIndex ( x => 1n ) ; 
