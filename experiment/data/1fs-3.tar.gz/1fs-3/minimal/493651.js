"use strict";
Array . prototype . indexOf . call ( true ) ; 
