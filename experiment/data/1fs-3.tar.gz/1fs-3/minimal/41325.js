"use strict";
new Uint8Array ( x => x ) ; 
