"use strict";
( Object ( Int8Array ) ) . prototype . map ( 0 , 0 ) ; 
