"use strict";
String . prototype . codePointAt ( 0n ) ; 
