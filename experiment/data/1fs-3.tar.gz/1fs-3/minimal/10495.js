"use strict";
String . prototype . charAt . call ( true ) ; 
