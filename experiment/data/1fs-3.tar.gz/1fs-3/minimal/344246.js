"use strict";
[ ] . includes . call ( true ) ; 
