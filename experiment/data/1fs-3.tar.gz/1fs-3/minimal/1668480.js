"use strict";
[ ] . slice ( null ) ; 
