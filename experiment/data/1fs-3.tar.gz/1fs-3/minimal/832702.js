"use strict";
Object . create . call ( 0 , [ ] , [ x => x , ] ) ; 
