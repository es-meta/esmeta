"use strict";
new Uint16Array ( ~ typeof x ) ; 
