"use strict";
new Uint16Array ( { [ Symbol . iterator ] : { } } ) ; 
