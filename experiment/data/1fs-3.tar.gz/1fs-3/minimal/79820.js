"use strict";
Array . from ( { } ) ; 
