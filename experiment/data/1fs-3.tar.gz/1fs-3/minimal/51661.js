"use strict";
String . prototype . trimEnd . call ( true ) ; 
