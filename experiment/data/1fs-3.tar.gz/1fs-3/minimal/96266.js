"use strict";
'' . at ( `` ) ; 
