"use strict";
new Uint8ClampedArray ( { [ Symbol . iterator ] : 0 } ) ; 
