"use strict";
[ , ] . findLastIndex ( x => x ) ; 
