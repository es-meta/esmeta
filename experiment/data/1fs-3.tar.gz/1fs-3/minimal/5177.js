"use strict";
Array . prototype . findIndex . call ( 1n ) ; 
