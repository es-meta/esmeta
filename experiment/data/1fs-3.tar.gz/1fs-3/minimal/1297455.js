"use strict";
Reflect . defineProperty ( { } , false ) ; 
