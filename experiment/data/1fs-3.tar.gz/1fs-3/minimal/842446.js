"use strict";
[ ] . findLastIndex ( x => x , x => x ) ; 
