"use strict";
Object . prototype . __lookupSetter__ . call ( ) ; 
