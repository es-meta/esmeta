"use strict";
[ ] . propertyIsEnumerable ( ) ; 
