"use strict";
[ ] . keys . call ( null ) ; 
