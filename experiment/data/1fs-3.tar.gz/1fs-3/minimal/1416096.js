"use strict";
Math . atan ( { [ Symbol . toPrimitive ] : '' } ) ; 
