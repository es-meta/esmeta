"use strict";
Promise . race ( 1 ) ; 
