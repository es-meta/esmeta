"use strict";
[ ] . toReversed . call ( `` ) ; 
