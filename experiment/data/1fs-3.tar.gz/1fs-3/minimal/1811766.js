"use strict";
[ ] . join . call ( true ) ; 
