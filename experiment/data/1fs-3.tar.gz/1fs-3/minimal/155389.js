"use strict";
BigInt . asUintN ( 0 , `` ) ; 
