"use strict";
'' . charCodeAt . call ( true ) ; 
