"use strict";
Object . is . call ( '' , [ ] , { } ) ; 
