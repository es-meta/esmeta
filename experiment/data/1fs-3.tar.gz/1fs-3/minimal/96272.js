"use strict";
'' . at ( true ) ; 
