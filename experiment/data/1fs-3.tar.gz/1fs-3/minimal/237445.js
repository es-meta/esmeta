"use strict";
String . prototype . padStart ( ) ; 
