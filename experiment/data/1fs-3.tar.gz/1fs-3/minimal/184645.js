"use strict";
new TypeError ( null ) ; 
