"use strict";
Array . prototype . copyWithin ( 0 , 1n ) ; 
