"use strict";
`` . __lookupSetter__ ( false ) ; 
