"use strict";
'' . includes ( { [ Symbol . match ] : 1 } ) ; 
