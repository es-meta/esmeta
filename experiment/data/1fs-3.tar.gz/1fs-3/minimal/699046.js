"use strict";
BigInt ( { [ Symbol . toPrimitive ] : x => x } ) ; 
