"use strict";
new WeakSet ( [ x => x ] ) ; 
