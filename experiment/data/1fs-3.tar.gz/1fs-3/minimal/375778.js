"use strict";
Promise . any ( [ , ] ) ; 
