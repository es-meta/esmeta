"use strict";
Iterator . from ( `` ) ; 
