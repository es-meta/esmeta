"use strict";
; `` . replace . call ( null ) ; 
