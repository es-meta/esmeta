"use strict";
( Object ( function * ( ) { } ) ) . prototype . forEach ( ) ; 
