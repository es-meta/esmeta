"use strict";
`` . lastIndexOf ( 1n ) ; 
