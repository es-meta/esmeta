"use strict";
`` . indexOf . call ( ) ; 
