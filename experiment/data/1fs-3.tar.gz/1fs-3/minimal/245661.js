"use strict";
Object . defineProperties ( { } , { get x ( ) { } } ) ; 
