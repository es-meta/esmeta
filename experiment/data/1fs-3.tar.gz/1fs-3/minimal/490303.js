"use strict";
Object . freeze ( [ , x => x ] ) ; 
