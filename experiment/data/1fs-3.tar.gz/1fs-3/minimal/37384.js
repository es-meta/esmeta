"use strict";
new WeakSet ( 1n ) ; 
