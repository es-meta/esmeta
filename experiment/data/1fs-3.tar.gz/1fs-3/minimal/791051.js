"use strict";
[ ] . every ( [ ] ) ; 
