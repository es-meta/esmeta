"use strict";
[ ] . sort ( x => x ) ; 
