"use strict";
Array . fromAsync ( { [ Symbol . asyncIterator ] : class { } } ) ; 
