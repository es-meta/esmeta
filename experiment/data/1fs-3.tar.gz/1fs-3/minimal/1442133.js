"use strict";
Math . atan ( { [ Symbol . toPrimitive ] : class { } } ) ; 
