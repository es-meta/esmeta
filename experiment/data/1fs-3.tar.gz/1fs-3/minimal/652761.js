"use strict";
[ ] . splice . call ( 1 ) ; 
