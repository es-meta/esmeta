"use strict";
[ ] . toString . call ( `` ) ; 
