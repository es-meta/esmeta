"use strict";
Promise . race ( { [ Symbol . iterator ] : async function * ( ) { } } ) ; 
