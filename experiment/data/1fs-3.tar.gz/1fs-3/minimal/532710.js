"use strict";
Reflect . preventExtensions ( [ ] ) ; 
