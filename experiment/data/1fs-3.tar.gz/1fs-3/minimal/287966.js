"use strict";
`` . __defineSetter__ ( 0 , 0 ) ; 
