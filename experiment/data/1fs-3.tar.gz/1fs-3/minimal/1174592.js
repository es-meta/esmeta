"use strict";
String . prototype . indexOf ( 0 , 1n ) ; 
