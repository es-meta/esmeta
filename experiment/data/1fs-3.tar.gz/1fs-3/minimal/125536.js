"use strict";
Promise . try ( class { } ) ; 
