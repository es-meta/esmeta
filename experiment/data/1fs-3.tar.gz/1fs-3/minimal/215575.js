"use strict";
new Uint8ClampedArray ( ~ typeof x ) ; 
