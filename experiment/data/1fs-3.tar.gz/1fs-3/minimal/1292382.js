"use strict";
Promise . race ( { [ Symbol . iterator ] : '' } ) ; 
