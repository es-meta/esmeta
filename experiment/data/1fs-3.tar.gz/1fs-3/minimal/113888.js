"use strict";
new Function ( 0 , void typeof x ) ; 
