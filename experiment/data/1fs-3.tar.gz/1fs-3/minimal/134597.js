"use strict";
decodeURI ( `` ) ; 
