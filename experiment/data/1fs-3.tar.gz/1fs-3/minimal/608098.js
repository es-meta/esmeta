"use strict";
Math . pow ( null ) ; 
