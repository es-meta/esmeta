"use strict";
new Uint8Array ( ~ typeof x ) ; 
