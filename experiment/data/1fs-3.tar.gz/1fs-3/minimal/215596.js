"use strict";
String . prototype . toLowerCase ( ) ; 
