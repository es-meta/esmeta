"use strict";
Math . fround ( true ) ; 
