"use strict";
[ , ] . findIndex ( x => 0n ) ; 
