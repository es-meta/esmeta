"use strict";
String . prototype . codePointAt ( null ) ; 
