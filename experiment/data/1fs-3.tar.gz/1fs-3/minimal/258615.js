"use strict";
new Uint32Array ( [ x => x ] ) ; 
