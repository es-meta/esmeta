"use strict";
Array . prototype . fill . call ( true ) ; 
