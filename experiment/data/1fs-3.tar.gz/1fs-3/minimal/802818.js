"use strict";
String . prototype . startsWith ( 0 , true ) ; 
