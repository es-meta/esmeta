"use strict";
[ ] . lastIndexOf . call ( `` ) ; 
