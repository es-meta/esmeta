"use strict";
'' . toLocaleString . call ( ) ; 
