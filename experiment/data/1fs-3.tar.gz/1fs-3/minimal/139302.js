"use strict";
Promise . any . call ( class { } ) ; 
