"use strict";
new String ( { [ Symbol . toPrimitive ] : '' } ) ; 
