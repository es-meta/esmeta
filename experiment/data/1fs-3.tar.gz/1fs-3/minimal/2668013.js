"use strict";
[ ] . toLocaleString . call ( [ ] ?. x ) ; 
