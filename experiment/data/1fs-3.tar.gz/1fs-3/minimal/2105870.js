"use strict";
Object . values ( { [ Symbol . split ] : x => x } ) ; 
