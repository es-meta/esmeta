"use strict";
[ ] . concat ( { } ) ; 
