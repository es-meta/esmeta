"use strict";
Array . prototype . reduce . call ( [ , ] , x => x , 0 ) ; 
