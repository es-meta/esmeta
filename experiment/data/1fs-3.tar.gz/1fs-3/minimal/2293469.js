"use strict";
Number . prototype . toPrecision ( true , '' ) ; 
