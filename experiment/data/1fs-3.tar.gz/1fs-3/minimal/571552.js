"use strict";
`` . replaceAll ( 1n ) ; 
