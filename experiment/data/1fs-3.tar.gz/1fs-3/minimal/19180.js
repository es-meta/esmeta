"use strict";
new Uint16Array ( true ) ; 
