"use strict";
new ArrayBuffer ( 1 ) ; 
