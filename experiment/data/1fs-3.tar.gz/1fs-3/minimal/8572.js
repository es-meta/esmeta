"use strict";
new Float64Array ( x => x ) ; 
