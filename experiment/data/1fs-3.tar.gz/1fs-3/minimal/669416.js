"use strict";
[ , ] . some ( ) ; 
