"use strict";
[ ] . sort . call ( null ) ; 
