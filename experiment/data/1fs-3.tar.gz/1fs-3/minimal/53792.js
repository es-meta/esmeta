"use strict";
new Uint8ClampedArray ( true ) ; 
