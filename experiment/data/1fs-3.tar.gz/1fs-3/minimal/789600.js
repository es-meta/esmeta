"use strict";
[ ] . pop . call ( 0n ) ; 
