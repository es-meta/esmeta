"use strict";
Number . prototype . toExponential ( 1 ) ; 
