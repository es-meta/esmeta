"use strict";
'' . at ( { [ Symbol . toPrimitive ] : function ( ) { } } ) ; 
