"use strict";
Number . prototype . toString ( { } ) ; 
