"use strict";
Math . cbrt ( 1 ) ; 
