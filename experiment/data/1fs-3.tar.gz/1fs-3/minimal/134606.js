"use strict";
decodeURI ( 0n ) ; 
