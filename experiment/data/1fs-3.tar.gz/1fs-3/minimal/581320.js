"use strict";
BigInt . asUintN ( 0 , null ) ; 
