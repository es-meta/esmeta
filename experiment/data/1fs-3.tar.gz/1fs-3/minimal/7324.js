"use strict";
Array . prototype . toSpliced . call ( null ) ; 
