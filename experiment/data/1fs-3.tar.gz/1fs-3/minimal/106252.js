"use strict";
Set . prototype . isSupersetOf ( 0 ) ; 
