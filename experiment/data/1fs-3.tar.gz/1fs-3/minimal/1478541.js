"use strict";
`` . slice . call ( 0 ) ; 
