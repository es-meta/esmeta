"use strict";
'' . charCodeAt ( 0 ) ; 
