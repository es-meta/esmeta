"use strict";
String . fromCharCode ( { } ) ; 
