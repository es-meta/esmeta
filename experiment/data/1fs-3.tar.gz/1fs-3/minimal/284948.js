"use strict";
encodeURIComponent ( [ ] ) ; 
