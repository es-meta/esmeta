"use strict";
1 . __defineSetter__ ( 0 ) ; 
