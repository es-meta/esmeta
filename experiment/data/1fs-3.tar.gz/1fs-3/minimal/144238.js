"use strict";
Math . imul ( [ ] ) ; 
