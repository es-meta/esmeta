"use strict";
; [ x ] = [ , ] ; 
