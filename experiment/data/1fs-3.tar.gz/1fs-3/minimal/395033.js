"use strict";
Math . sin ( null ) ; 
