"use strict";
[ ] . copyWithin . call ( true ) ; 
