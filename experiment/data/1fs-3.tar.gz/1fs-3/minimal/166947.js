"use strict";
Promise . withResolvers . call ( function ( ) { x ; } ) ; 
