"use strict";
[ , , ] . pop ( ) ; 
