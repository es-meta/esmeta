"use strict";
Object . defineProperties ( [ , ] , [ x => x ] ) ; 
