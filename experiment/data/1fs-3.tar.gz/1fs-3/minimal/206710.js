"use strict";
Iterator . prototype . map ( ) ; 
