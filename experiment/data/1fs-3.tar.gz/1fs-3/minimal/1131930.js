"use strict";
[ , ] . findIndex ( x => `` ) ; 
