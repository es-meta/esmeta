"use strict";
( Object ( Int8Array ) ) . from . call ( function ( ) { } , 0 ) ; 
