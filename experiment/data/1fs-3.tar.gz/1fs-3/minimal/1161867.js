"use strict";
this . __defineGetter__ ( void typeof x , x => x ) ; 
