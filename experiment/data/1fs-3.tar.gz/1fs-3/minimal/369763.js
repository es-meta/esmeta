"use strict";
Object . defineProperties . call ( '' , { } , { [ Symbol . match ] : x => x } ) ; 
