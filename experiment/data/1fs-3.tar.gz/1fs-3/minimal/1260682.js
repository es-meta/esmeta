"use strict";
var x = { } ; Object . setPrototypeOf ( x , x => x ) ; - [ x ] ; 
