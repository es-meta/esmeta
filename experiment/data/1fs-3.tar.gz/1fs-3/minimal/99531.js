"use strict";
Object . getOwnPropertyDescriptors ( '' ) ; 
