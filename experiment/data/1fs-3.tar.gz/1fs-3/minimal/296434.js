"use strict";
[ ] . valueOf . call ( ) ; 
