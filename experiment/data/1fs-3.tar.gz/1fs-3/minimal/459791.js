"use strict";
Math . atanh ( true ) ; 
