"use strict";
Array . from . call ( class { } , 0 ) ; 
