"use strict";
String . prototype . matchAll . call ( true ) ; 
