"use strict";
Object . defineProperties ( [ ] , { x ( ) { } } ) ; 
