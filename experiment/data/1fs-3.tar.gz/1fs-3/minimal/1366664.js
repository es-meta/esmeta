"use strict";
[ , ] . findIndex ( x => null ) ; 
