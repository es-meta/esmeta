"use strict";
Object . defineProperties ( { } , this ) ; 
