"use strict";
`` . startsWith ( `` ) ; 
