"use strict";
Array . prototype . shift . call ( true ) ; 
