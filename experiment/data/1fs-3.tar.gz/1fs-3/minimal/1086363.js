"use strict";
'' . charCodeAt . call ( { } ) ; 
