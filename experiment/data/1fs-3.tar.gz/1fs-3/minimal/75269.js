"use strict";
Object . entries ( 1n ) ; 
