"use strict";
Array . fromAsync ( async function * ( ) { yield * x ( ) ; } `` ) ; function * x ( ) { } 
