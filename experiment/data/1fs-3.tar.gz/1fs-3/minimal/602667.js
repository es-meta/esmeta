"use strict";
Object . isExtensible ( { } ) ; 
