"use strict";
[ ] . reduceRight . call ( 0 ) ; 
