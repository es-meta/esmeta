"use strict";
`` . slice ( null ) ; 
