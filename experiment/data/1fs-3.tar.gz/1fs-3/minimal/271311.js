"use strict";
Promise . all ( 1n ) ; 
