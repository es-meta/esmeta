"use strict";
String . prototype . trimEnd ( ) ; 
