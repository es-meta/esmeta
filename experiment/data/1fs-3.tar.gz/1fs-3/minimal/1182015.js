"use strict";
[ ] . toReversed . call ( true ) ; 
