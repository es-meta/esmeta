"use strict";
[ ] . toString . call ( 1n ) ; 
