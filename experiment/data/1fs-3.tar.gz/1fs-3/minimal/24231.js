"use strict";
new ReferenceError ( { } ) ; 
