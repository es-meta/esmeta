"use strict";
'' . charCodeAt ( { } ) ; 
