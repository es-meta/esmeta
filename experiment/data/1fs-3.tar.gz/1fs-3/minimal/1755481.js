"use strict";
Number ( `` . x ) ; 
