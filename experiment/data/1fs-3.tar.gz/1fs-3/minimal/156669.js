"use strict";
new Promise ( { } ) ; 
