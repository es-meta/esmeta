"use strict";
Math . fround ( '' ) ; 
