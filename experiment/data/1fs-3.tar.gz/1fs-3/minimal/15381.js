"use strict";
Object . prototype . propertyIsEnumerable . call ( ) ; 
