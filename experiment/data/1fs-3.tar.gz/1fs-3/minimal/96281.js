"use strict";
'' . at ( 0n ) ; 
