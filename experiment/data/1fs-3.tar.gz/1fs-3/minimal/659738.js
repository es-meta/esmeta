"use strict";
var x = this ; for ( x in x ) ; 
