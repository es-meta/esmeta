"use strict";
Object . getOwnPropertySymbols ( { [ Symbol . matchAll ] : '' } ) ; 
