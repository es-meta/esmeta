"use strict";
`` . __defineGetter__ ( '' , [ ] ) ; 
