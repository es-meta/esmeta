"use strict";
[ ] . entries . call ( true ) ; 
