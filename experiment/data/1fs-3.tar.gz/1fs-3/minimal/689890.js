"use strict";
Symbol . for ( [ ] ) ; 
