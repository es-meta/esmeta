"use strict";
parseInt ( 0 ) ; 
