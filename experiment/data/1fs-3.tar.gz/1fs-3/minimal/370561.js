"use strict";
new ArrayBuffer ( true ) ; 
