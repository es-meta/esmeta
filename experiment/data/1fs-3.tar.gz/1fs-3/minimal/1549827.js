"use strict";
`` . slice . call ( { } ) ; 
