"use strict";
`${ x => x }` . hasOwnProperty ( 0 ) ; 
