"use strict";
new ReferenceError ( true ) ; 
