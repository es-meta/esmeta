"use strict";
Reflect . defineProperty ( { } , { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
