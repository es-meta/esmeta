"use strict";
Function . apply . call ( ) ; 
