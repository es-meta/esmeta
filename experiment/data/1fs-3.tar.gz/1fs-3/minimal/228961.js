"use strict";
String . prototype . indexOf ( false ) ; 
