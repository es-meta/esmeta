"use strict";
Math . expm1 ( { } ) ; 
