"use strict";
`` . normalize ( null ) ; 
