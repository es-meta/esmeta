"use strict";
Object . keys ( typeof x ) ; 
