"use strict";
new Float32Array ( { [ Symbol . iterator ] : async function * ( ) { } } ) ; 
