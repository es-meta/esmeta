"use strict";
[ ] . indexOf . call ( null ) ; 
