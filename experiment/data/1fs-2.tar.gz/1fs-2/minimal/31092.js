"use strict";
Array . prototype . findLastIndex . call ( [ , ] ) ; 
