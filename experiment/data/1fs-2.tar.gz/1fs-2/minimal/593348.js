"use strict";
; true . __proto__ ; 
