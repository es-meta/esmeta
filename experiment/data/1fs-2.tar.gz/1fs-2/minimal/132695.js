"use strict";
Object . getOwnPropertyDescriptors ( this ) ; 
