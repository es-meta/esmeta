"use strict";
encodeURI . call ( 0 , { [ Symbol . toPrimitive ] : x => x } ) ; 
