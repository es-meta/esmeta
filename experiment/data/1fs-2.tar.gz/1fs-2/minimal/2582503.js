"use strict";
Object . hasOwn ( 0 , 1n ) ; 
