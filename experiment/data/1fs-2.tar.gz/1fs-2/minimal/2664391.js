"use strict";
String . prototype . repeat ( - delete typeof x ) ; { } 
