"use strict";
Function . apply . call ( x => x ) ; 
