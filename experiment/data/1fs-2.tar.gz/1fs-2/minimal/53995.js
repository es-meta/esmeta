"use strict";
[ ] . concat . call ( true ) ; 
