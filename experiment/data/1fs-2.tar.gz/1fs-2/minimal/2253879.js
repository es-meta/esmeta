"use strict";
Proxy . revocable . call ( '' , class { } , [ ] ) ; 
