"use strict";
Array . fromAsync . call ( 0 , '' ) ; 
