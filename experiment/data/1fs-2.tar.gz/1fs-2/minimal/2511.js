"use strict";
Array.prototype.findLastIndex.call(0, 0);
