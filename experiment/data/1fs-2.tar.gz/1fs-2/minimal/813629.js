"use strict";
[ ] . slice ( ~ typeof x ) ; 
