"use strict";
[ ] . valueOf . call ( 0n ) ; 
