"use strict";
[ , , ] . fill ( ) ; 
