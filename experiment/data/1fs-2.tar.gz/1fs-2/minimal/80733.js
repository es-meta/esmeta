"use strict";
Array . prototype . findIndex . call ( x => x , x => x ) ; 
