"use strict";
`` . substring . call ( { } ) ; 
