"use strict";
Math . sinh ( '' ) ; 
