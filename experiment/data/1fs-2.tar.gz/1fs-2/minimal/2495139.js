"use strict";
new Int8Array ( { [ Symbol . iterator ] : class { } } ) ; 
