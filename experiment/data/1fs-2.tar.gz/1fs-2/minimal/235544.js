"use strict";
String . prototype . charCodeAt . call ( false ) ; 
