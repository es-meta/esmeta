"use strict";
[ , ] . shift ( ) ; 
