"use strict";
[ ] . join . call ( 0 ) ; 
