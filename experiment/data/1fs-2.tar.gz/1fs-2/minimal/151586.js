"use strict";
Math . sqrt ( '' ) ; 
