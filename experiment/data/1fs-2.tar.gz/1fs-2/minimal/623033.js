"use strict";
true . valueOf ( ) ; 
