"use strict";
new EvalError ( 0 , [ ] ) ; 
