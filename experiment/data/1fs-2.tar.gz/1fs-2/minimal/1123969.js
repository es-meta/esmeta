"use strict";
[ , ] . find ( x => '' ) ; 
