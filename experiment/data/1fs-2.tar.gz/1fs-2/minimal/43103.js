"use strict";
Array . prototype . lastIndexOf . call ( null ) ; 
