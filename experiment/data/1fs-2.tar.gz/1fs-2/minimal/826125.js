"use strict";
'' . replaceAll ( `` , function ( ) { } ) ; 
