"use strict";
1 . __defineSetter__ ( null , x => x ) ; 
