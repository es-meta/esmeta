"use strict";
encodeURIComponent ( null ) ; 
