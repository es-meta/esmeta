"use strict";
encodeURI . call ( 0 , { [ Symbol . toPrimitive ] : async x => x = x } ) ; 
