"use strict";
Math . floor ( null ) ; 
