"use strict";
new EvalError ( null ) ; 
