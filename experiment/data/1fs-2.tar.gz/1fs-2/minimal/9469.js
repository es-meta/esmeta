"use strict";
String . prototype . split . call ( 0 , 1 ) ; 
