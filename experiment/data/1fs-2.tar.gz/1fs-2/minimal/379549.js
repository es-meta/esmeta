"use strict";
0 . valueOf . call ( ) ; 
