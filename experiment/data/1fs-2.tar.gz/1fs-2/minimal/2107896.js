"use strict";
String . prototype . codePointAt . call ( 1n , 0n ) ; 
