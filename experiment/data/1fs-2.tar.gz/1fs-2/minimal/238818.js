"use strict";
Object . getOwnPropertyDescriptor ( null ) ; 
