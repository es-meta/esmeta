"use strict";
Math . cos ( '' ) ; 
