"use strict";
[ ] . indexOf . call ( '' ) ; 
