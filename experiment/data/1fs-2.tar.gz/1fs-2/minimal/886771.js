"use strict";
[ ] . toSpliced ( true ) ; 
