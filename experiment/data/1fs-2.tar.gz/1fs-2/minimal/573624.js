"use strict";
Reflect . isExtensible ( { } ) ; 
