"use strict";
Math . fround ( { } ) ; 
