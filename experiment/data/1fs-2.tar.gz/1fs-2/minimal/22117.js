"use strict";
Array . prototype . findIndex . call ( '' ) ; 
