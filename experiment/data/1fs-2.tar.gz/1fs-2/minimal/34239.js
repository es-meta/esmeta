"use strict";
new Uint32Array ( 1 ) ; 
