"use strict";
Math . cos ( [ ] ) ; 
