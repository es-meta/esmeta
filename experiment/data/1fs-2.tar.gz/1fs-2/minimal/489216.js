"use strict";
'' . matchAll ( { } ) ; 
