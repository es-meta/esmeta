"use strict";
[ x => x , ] . toLocaleString ( ) ; 
