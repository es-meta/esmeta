"use strict";
[ ] . with . call ( 0n ) ; 
