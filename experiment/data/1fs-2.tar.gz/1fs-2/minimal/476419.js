"use strict";
String . prototype . repeat . call ( false ) ; 
