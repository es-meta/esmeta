"use strict";
`` . substring ( '' ) ; 
