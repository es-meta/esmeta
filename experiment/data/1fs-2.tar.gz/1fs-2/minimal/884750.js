"use strict";
`` . indexOf ( `` ) ; 
