"use strict";
new Uint16Array ( 1 ) ; 
