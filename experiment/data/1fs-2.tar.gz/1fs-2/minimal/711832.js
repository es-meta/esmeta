"use strict";
Math . f16round ( 1 ) ; 
