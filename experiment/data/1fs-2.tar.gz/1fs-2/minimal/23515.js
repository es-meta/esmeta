"use strict";
String . prototype . repeat . call ( true ) ; 
