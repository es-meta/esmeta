"use strict";
[ ] . toSorted . call ( 1 ) ; 
