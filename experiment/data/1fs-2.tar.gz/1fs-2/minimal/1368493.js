"use strict";
[ ] . slice . call ( typeof x ) ; 
