"use strict";
'' . replaceAll . call ( 0 , 0 ) ; 
