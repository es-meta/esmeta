"use strict";
Math . sign ( null ) ; 
