"use strict";
Object . seal ( [ x => x ] ) ; 
