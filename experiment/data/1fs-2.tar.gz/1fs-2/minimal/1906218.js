"use strict";
Reflect . construct . call ( 0 , class { ; x = x ; } , { } ) ; 
