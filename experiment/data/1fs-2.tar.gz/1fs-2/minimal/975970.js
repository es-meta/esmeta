"use strict";
[ ] . at . call ( `${ x => x }` ) ; 
