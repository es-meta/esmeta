"use strict";
0n . __defineGetter__ ( ) ; 
