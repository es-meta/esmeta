"use strict";
Object . getOwnPropertyDescriptors ( { [ Symbol . search ] : '' } ) ; 
