"use strict";
String . raw ( { } ) ; 
