"use strict";
new function x ( [ ] = x ) { } ( function * ( ) { } `` ) ; 
