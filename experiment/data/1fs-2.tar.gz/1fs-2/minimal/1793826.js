"use strict";
; Number . prototype . toExponential ( true ) ; 
