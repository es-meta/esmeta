"use strict";
Uint8Array . prototype . toHex ( 0 ) ; 
