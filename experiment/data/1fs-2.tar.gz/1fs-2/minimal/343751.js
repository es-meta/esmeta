"use strict";
Math . exp ( true ) ; 
