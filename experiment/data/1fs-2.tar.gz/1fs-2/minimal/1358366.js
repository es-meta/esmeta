"use strict";
Error ( import ( x => x ) ) ; 
