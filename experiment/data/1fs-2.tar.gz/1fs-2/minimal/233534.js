"use strict";
[ ] . sort . call ( true ) ; 
