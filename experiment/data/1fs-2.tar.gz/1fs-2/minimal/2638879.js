"use strict";
var x ; `${ x }` . padEnd ( true ) ; 
