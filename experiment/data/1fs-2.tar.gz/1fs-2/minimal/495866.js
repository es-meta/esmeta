"use strict";
String . prototype . endsWith ( 0 , [ ] ) ; 
