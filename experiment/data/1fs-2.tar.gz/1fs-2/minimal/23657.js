"use strict";
new Map ( true ) ; 
