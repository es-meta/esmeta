"use strict";
Math . expm1 ( 0 ) ; 
