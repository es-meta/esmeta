"use strict";
Math . acosh ( null ) ; 
