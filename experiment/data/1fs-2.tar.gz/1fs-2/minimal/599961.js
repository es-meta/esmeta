"use strict";
Boolean ( true ) ; 
