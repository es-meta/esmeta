"use strict";
new TypeError ( '' ) ; 
