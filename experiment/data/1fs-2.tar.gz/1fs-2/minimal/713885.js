"use strict";
'' . replaceAll ( 0 , 0 ) ; 
