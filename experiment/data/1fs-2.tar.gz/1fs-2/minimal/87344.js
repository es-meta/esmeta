"use strict";
String . prototype . toWellFormed ( ) ; 
