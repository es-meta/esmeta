"use strict";
Reflect . defineProperty ( [ ] , `` , [ ] ) ; 
