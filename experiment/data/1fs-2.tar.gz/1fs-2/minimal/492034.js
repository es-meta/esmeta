"use strict";
'' . hasOwnProperty ( false ) ; 
