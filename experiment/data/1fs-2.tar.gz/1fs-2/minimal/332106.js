"use strict";
Set . prototype . forEach ( 0 ) ; 
