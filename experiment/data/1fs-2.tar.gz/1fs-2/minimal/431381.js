"use strict";
[ ] . with ( 0 ) ; 
