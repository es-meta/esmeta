"use strict";
Object . seal ( { [ Symbol . split ] : '' } ) ; 
