"use strict";
Reflect . getOwnPropertyDescriptor ( x => x , 0 ) ; 
