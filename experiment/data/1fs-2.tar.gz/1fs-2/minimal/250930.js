"use strict";
Number . prototype . toString ( true ) ; 
