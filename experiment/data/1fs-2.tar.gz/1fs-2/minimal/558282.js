"use strict";
Number . prototype . toString ( null ) ; 
