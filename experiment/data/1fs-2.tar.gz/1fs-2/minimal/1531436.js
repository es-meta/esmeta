"use strict";
Object . assign ( `` , this ) ; 
