"use strict";
Math . floor ( { } ) ; 
