"use strict";
Math . asinh ( [ ] ) ; 
