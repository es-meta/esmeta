"use strict";
Math . max ( [ ] ) ; 
