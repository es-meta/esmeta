"use strict";
Array . prototype . reduce . call ( 1n ) ; 
