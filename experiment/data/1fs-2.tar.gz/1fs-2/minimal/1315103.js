"use strict";
`` . propertyIsEnumerable ( ~ typeof x ) ; 
