"use strict";
Number . prototype . toPrecision ( ~ typeof x ) ; 
