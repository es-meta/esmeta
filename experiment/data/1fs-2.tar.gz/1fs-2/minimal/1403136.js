"use strict";
Object . assign ( [ x => x ] , typeof x ) ; 
