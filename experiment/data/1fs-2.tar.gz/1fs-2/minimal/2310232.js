"use strict";
BigInt . asIntN ( 0 , 0n ) ; 
