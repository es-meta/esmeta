"use strict";
new Float16Array ( ~ typeof x ) ; 
