"use strict";
WeakSet . prototype . add ( 0 ) ; 
