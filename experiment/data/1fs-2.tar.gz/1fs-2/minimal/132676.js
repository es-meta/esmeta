"use strict";
Object . getOwnPropertyDescriptors ( `` ) ; 
