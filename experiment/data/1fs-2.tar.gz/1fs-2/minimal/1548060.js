"use strict";
Object . create ( [ ] , true ) ; 
