"use strict";
[ ] . join ( false ) ; 
