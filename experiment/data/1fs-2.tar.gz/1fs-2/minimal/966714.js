"use strict";
[ ] . slice . call ( true ) ; 
