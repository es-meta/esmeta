"use strict";
Math . cos ( null ) ; 
