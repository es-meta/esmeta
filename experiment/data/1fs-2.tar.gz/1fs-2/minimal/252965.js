"use strict";
[ ] . with . call ( typeof x ) ; 
