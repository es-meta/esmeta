"use strict";
`` . propertyIsEnumerable ( 0n ) ; 
