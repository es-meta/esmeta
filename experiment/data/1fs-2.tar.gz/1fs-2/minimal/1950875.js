"use strict";
encodeURI . call ( 1 , { [ Symbol . toPrimitive ] : async function ( ) { } } ) ; 
