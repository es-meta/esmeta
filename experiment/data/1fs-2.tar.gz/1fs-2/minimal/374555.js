"use strict";
String . prototype . indexOf ( ) ; 
