"use strict";
Array . from ( [ , ] , class { } ) ; 
