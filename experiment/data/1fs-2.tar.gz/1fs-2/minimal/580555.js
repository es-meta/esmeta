"use strict";
Reflect . ownKeys ( [ , x => x ] ) ; 
