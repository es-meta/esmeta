"use strict";
Math . clz32 ( null ) ; 
