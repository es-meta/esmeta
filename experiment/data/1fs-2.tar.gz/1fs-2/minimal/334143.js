"use strict";
String . prototype . repeat ( true ) ; 
