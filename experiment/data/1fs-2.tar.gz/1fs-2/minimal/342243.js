"use strict";
[ ] . lastIndexOf ( x => x ) ; 
