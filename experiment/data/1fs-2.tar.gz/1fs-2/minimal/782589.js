"use strict";
Object . getOwnPropertyDescriptor ( 0 , true ) ; 
