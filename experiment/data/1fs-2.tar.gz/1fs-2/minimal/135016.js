"use strict";
`` . slice ( '' ) ; 
