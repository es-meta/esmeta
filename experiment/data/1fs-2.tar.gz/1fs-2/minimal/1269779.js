"use strict";
Reflect . defineProperty ( { } , `` , { writable : true } ) ; 
