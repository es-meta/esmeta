"use strict";
true . toString ( ) ; 
