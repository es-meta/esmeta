"use strict";
String . prototype . charCodeAt ( ) ; 
