"use strict";
Function ( null ) ; 
