"use strict";
Number . isFinite ( - typeof x ) ; 
