"use strict";
new Promise ( x => x ( ) . x ) ; 
