"use strict";
Array . prototype . map . call ( typeof x , x => x ) ; 
