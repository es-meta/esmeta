"use strict";
1 . __defineSetter__ ( ) ; 
