"use strict";
Object . defineProperty . call ( '' , [ , ] , 0 , x => x ) ; 
