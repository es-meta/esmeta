"use strict";
[ ] . toString . call ( '' ) ; 
