"use strict";
String . prototype . toWellFormed . call ( false ) ; 
