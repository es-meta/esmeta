"use strict";
Array . isArray ( { } ) ; 
