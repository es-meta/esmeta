"use strict";
Iterator . prototype . take ( ) ; 
