"use strict";
[ ] . splice ( true ) ; 
