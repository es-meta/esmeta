"use strict";
function * x ( ) { } Array . fromAsync ( async function * ( ) { yield * x ( ) ; } `` ) ; 
