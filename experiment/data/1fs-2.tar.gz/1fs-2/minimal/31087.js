"use strict";
Array . prototype . findLastIndex . call ( 0n ) ; 
