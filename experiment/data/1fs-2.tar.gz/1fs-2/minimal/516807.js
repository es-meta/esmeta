"use strict";
[ ] . shift . call ( true ) ; 
