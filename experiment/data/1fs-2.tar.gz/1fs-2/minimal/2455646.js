"use strict";
Math . pow ( - ! typeof x , + ~ void typeof x ) ; 
