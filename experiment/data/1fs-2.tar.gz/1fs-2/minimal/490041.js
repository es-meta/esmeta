"use strict";
Math . atan2 ( [ ] ) ; 
