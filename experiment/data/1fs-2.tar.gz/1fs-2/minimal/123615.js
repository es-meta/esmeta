"use strict";
Promise . try . call ( { } ) ; 
