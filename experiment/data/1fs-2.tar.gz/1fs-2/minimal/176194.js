"use strict";
Number . prototype . toPrecision ( 1 ) ; 
