"use strict";
Object . getOwnPropertySymbols ( this ) ; 
