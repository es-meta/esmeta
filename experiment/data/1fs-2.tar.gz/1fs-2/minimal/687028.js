"use strict";
String . prototype . repeat ( 1 ) ; 
