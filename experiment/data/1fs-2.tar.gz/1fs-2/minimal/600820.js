"use strict";
String ( { [ Symbol . toPrimitive ] : function ( ) { } } ) ; 
