"use strict";
[ , ] . concat ( ) ; 
