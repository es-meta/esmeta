"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.find.call(0, 0, 0);
