"use strict";
[ ] . slice ( { } ) ; 
