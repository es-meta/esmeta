"use strict";
Math . fround ( null ) ; 
