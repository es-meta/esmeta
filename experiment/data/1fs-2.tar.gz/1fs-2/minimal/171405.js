"use strict";
Object . getOwnPropertyNames ( '' ) ; 
