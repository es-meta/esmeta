"use strict";
`` . __lookupGetter__ ( 0 ) ; 
