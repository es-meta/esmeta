"use strict";
Array . prototype . findLast . call ( true ) ; 
