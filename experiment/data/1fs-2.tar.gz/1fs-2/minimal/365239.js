"use strict";
parseFloat ( [ ] ) ; 
