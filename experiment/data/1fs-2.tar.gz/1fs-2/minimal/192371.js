"use strict";
Math . imul ( 0 ) ; 
