"use strict";
'' . __defineGetter__ ( `` . x , x => x ) ; 
