"use strict";
encodeURI . call ( 0 , { [ Symbol . toPrimitive ] : class { } } ) ; 
