"use strict";
[ ] . sort ( 1 ) ; 
