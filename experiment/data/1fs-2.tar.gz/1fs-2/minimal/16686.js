"use strict";
Promise . prototype . catch . call ( '' ) ; 
