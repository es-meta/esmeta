"use strict";
Object . groupBy ( 1n , x => x ) ; 
