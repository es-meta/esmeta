"use strict";
'' . endsWith ( null ) ; 
