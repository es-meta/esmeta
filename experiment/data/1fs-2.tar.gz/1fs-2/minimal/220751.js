"use strict";
Math . trunc ( '' ) ; 
