"use strict";
Set . prototype . entries ( 0 ) ; 
