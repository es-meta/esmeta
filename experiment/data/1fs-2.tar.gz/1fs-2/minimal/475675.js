"use strict";
BigInt . asUintN ( null ) ; 
