"use strict";
; `` . trim . call ( 1n ) ; 
