"use strict";
Array . prototype . findIndex ( { } ) ; 
