"use strict";
Math . log ( null ) ; 
