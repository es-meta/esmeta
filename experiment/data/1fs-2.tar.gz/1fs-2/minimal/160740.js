"use strict";
Math . sqrt ( [ ] ) ; 
