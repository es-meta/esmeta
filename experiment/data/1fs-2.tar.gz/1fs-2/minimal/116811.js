"use strict";
[ ] . unshift ( `` ) ; 
