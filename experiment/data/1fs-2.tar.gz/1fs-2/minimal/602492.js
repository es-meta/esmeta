"use strict";
[ ] . sort . call ( 0n ) ; 
