"use strict";
Object . create ( [ ] , { [ Symbol . toPrimitive ] : `` } ) ; 
