"use strict";
Function . bind . call ( { } ) ; 
