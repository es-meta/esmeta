"use strict";
new ArrayBuffer ( ~ typeof x ) ; 
