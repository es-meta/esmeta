"use strict";
decodeURI ( 1n ) ; 
