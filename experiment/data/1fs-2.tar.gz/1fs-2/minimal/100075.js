"use strict";
[ , ] . unshift ( ) ; 
