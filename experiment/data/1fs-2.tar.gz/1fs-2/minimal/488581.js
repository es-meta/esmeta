"use strict";
[ ] . splice . call ( 0n ) ; 
