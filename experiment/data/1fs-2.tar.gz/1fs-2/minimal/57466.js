"use strict";
String ( void typeof x ) ; 
