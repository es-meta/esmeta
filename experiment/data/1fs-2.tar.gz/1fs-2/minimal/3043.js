"use strict";
(Object.getPrototypeOf(Int8Array)).prototype.lastIndexOf.call(0, 0, 0);
