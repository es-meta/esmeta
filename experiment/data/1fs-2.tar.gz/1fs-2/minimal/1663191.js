"use strict";
Object . getOwnPropertyDescriptor ( typeof x , 0 ) ; 
