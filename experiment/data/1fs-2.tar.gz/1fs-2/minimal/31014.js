"use strict";
Promise . prototype . finally ( [ ] ) ; 
