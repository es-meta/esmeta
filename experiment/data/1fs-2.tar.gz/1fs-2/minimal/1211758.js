"use strict";
[ , ] . find ( x => 0n ) ; 
