"use strict";
Set . prototype . union ( 0 ) ; 
