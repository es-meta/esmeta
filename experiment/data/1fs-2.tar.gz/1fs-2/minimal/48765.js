"use strict";
String . prototype . codePointAt ( ) ; 
