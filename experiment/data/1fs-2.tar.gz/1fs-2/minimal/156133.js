"use strict";
new ArrayBuffer ( { } ) ; 
