"use strict";
Math . exp ( [ ] ) ; 
