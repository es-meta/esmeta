"use strict";
[ , ] . findLast ( ( ) => x ) ; 
