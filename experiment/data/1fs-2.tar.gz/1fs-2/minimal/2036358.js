"use strict";
Object . assign ( `` , { get x ( ) { x ; } } ) ; 
