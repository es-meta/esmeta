"use strict";
Array . fromAsync ( { length : [ ] } ) ; 
