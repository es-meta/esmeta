"use strict";
Array . prototype . findLastIndex ( ) ; 
