"use strict";
Promise . race ( [ ] ) ; 
