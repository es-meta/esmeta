"use strict";
'' . endsWith ( { } ) ; 
