"use strict";
[ ] . toSpliced ( 1 ) ; 
