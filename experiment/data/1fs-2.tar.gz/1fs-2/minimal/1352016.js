"use strict";
Math . cbrt ( true ) ; 
