"use strict";
Object . is ( [ ] , { } ) ; 
