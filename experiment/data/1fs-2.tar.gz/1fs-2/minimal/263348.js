"use strict";
'' . hasOwnProperty ( `` ) ; 
