"use strict";
Math . log1p ( true ) ; 
