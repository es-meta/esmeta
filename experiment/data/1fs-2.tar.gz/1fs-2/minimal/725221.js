"use strict";
[ ] . toReversed . call ( null ) ; 
