"use strict";
new TypeError ( false ) ; 
