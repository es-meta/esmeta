"use strict";
`` . indexOf ( false ) ; 
