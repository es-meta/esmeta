"use strict";
[ x => x , , ] . some ( x => null , ) ; 
