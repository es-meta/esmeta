"use strict";
Iterator . prototype . some ( ) ; 
