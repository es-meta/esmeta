"use strict";
Uint8Array.call(0);
