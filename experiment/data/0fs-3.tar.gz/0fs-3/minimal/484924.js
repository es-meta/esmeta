"use strict";
Iterator . prototype . take ( ~ typeof x ) ; 
