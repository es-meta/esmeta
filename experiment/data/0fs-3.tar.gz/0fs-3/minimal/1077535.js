"use strict";
[ x => x ] . reduceRight ( x => x , x => x ) ; 
