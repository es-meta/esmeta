"use strict";
1n . valueOf ( '' ) ; 
