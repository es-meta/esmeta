"use strict";
String . prototype . includes ( 0 , 0n ) ; 
