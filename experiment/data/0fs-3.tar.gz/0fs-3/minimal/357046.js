"use strict";
Reflect . getOwnPropertyDescriptor ( { } ) ; 
