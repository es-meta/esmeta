"use strict";
Uint8Array . fromHex ( 0 ) ; 
