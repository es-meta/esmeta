"use strict";
Math . cosh ( 1n ) ; 
