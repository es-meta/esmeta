"use strict";
Object . create . call ( 0 , [ ] , { set x ( x ) { } } ) ; 
