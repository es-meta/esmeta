"use strict";
Map . prototype . get ( 0 ) ; 
