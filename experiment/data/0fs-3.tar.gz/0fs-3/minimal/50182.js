"use strict";
'' . search ( 0 ) ; 
