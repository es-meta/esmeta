"use strict";
( Object ( Int8Array ) ) . prototype . sort ( 0 ) ; 
