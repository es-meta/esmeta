"use strict";
Math . exp ( 1 ) ; 
