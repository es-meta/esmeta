"use strict";
Math . cos ( 1 ) ; 
