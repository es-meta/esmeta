"use strict";
Array . fromAsync ( [ , ] , ( ) => x ) ; 
