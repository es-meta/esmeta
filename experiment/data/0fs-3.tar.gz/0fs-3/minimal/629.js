"use strict";
var x = {}; Object.setPrototypeOf(x, Symbol.prototype); x.description;
