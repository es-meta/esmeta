"use strict";
[ ] . toReversed . call ( ) ; 
