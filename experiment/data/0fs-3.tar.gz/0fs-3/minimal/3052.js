"use strict";
var x = {}; Object.setPrototypeOf(x, (Object.getPrototypeOf(Int8Array)).prototype); x.length;
