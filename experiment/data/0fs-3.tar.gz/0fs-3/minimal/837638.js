"use strict";
[ ] . splice . call ( typeof x , 1 ) ; 
