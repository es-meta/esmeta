"use strict";
Math . log1p ( 1n ) ; 
