"use strict";
ReferenceError.call(0);
