"use strict";
String . prototype . charAt ( ) ; 
