"use strict";
( Object ( Int8Array ) ) . prototype . findLast ( 0 , 0 ) ; 
