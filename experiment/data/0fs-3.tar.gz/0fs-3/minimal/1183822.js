"use strict";
[ ] . findIndex ( 0 ) ; 
