"use strict";
Math . cosh ( 0 ) ; 
