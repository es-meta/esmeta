"use strict";
Math.ceil.call(0);
