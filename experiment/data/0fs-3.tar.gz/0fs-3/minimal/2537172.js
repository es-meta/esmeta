"use strict";
new Proxy ( x => x , x => x ) ; 
