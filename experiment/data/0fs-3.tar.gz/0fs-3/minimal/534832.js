"use strict";
Function . apply ( x => x , [ , ] ) ; 
