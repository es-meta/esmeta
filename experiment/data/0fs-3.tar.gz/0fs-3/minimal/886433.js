"use strict";
'' . startsWith ( 0 ) ; 
