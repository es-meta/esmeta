"use strict";
'' . matchAll ( x => x ) ; 
