"use strict";
Math . log ( 42 ) ; 
