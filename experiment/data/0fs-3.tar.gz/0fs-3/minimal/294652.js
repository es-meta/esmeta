"use strict";
Number . prototype . toPrecision . call ( + typeof x , 1 ) ; 
