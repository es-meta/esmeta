"use strict";
( Object ( Int8Array ) ) . prototype . reduceRight ( 0 , 0 ) ; 
