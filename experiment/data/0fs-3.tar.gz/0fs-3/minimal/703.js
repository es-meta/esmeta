"use strict";
new URIError(0);
