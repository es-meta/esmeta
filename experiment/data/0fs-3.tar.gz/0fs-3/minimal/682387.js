"use strict";
Promise . race . call ( function ( x , { } , ) { } ) ; 
