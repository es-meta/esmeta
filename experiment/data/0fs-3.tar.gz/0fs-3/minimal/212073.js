"use strict";
[ , ] . indexOf ( ) ; 
