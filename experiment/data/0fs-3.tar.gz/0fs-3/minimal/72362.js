"use strict";
`` . hasOwnProperty ( ) ; 
