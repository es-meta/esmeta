"use strict";
Math.round.call(0);
