"use strict";
Array ( + typeof x ) ; 
