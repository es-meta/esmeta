"use strict";
Math . atanh ( 0 ) ; 
