"use strict";
new Map ( function * ( ) { } `` ) ; 
