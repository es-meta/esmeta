"use strict";
Promise . race ( '' ) ; 
