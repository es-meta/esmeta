"use strict";
[ ] . fill ( 0 ) ; 
