"use strict";
Math . max ( { } ) ; 
