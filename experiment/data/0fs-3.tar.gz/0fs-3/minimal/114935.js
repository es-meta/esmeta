"use strict";
parseFloat ( 0 ) ; 
