"use strict";
Number ( 0n ) ; 
