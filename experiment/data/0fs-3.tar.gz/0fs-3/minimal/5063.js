"use strict";
Reflect.set.call(0, 0, 0);
