"use strict";
Iterator.from.call(0);
