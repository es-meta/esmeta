"use strict";
new Proxy(0);
