"use strict";
Iterator.prototype.map.call(0);
