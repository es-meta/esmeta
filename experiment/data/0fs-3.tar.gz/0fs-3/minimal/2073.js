"use strict";
String.prototype.slice.call(0, 0, 0);
