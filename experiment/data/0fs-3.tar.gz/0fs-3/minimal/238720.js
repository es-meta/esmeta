"use strict";
Reflect . setPrototypeOf . call ( 0 , [ ] , { } ) ; 
