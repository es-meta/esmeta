"use strict";
new Set ( { [ Symbol . iterator ] : async function * ( ) { yield ; } } ) ; 
