"use strict";
Array . prototype . map . call ( ) ; 
