"use strict";
Function . bind ( 0 ) ; 
