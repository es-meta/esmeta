"use strict";
Array.prototype.push.call(0, 0);
