"use strict";
[ ] . flat . call ( ) ; 
