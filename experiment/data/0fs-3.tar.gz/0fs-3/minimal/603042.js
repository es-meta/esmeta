"use strict";
`${ x => x }` . codePointAt ( ) ; 
