"use strict";
Math.imul.call(0);
