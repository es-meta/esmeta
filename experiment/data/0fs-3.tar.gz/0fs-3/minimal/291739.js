"use strict";
Reflect . setPrototypeOf ( 0 ) ; 
