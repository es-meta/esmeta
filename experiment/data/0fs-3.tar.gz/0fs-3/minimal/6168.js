"use strict";
Iterator . prototype . drop ( 0 ) ; 
