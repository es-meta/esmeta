"use strict";
Promise . prototype . finally . call ( { } ) ; 
