"use strict";
[ , ] . forEach ( x => x ) ; 
