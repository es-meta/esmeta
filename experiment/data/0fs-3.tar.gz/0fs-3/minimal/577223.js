"use strict";
[ ] . reduceRight ( x => x ) ; 
