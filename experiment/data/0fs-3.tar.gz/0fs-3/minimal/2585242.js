"use strict";
Number . prototype . toExponential ( 0 ) ; x , x ; 
