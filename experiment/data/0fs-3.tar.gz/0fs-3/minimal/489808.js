"use strict";
'' . __lookupSetter__ ( 1 ) ; 
