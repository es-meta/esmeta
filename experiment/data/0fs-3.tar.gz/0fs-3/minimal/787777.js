"use strict";
Number . prototype . toExponential . call ( ~ typeof x ) ; 
