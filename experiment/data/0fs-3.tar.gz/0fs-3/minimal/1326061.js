"use strict";
Map . groupBy ( [ , x => x , ] , x => ! x ) ; 
