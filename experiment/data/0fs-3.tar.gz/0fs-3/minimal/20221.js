"use strict";
new Boolean ( null ) ; 
