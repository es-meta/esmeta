"use strict";
Function . apply ( 0 ) ; 
