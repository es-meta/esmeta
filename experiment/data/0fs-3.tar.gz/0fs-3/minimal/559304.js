"use strict";
parseInt ( 0 , 0 ) ; 
