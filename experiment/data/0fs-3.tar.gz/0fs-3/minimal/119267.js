"use strict";
( Object ( Int8Array ) ) . prototype . join ( 0 ) ; 
