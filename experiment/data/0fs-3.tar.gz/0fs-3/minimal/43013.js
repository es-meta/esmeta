"use strict";
( Object ( Int8Array ) ) . from . call ( 0 ) ; 
