"use strict";
ArrayBuffer . isView ( [ ] ) ; 
