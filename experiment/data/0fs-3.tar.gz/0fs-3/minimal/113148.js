"use strict";
Math . tan ( 0 ) ; 
