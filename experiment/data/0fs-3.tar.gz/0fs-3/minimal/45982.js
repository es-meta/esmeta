"use strict";
new Boolean ( 1n ) ; 
