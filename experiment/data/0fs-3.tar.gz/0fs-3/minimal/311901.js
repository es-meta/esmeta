"use strict";
String . prototype . padEnd ( ) ; 
