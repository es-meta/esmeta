"use strict";
[ ] . forEach ( ) ; 
