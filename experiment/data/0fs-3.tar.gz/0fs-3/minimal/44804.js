"use strict";
String . prototype . charAt ( 0n ) ; 
