"use strict";
Symbol ( 1n ) ; 
