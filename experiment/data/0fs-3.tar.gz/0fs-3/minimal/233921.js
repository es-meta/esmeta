"use strict";
'' . toString ( ) ; 
