"use strict";
Math . ceil ( 0 ) ; 
