"use strict";
Object.assign.call(0);
