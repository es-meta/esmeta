"use strict";
Math . log ( 1 ) ; 
