"use strict";
Array . prototype . reduce . call ( ) ; 
