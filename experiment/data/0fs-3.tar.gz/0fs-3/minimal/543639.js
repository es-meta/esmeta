"use strict";
[ ] . unshift . call ( typeof x , 0 ) ; 
