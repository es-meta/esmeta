"use strict";
Array . prototype . copyWithin . call ( 0 , ~ typeof x ) ; 
