"use strict";
'' . isWellFormed ( ) ; 
