"use strict";
( Object ( Int8Array ) ) . prototype . reduce ( 0 , 0 ) ; 
