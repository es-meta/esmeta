"use strict";
new Float32Array(0);
