"use strict";
[ x => x ] . flat ( x => x ) ; 
