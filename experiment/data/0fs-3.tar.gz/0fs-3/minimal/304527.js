"use strict";
String . fromCharCode ( 0n ) ; 
