"use strict";
Math . atan ( 1n ) ; 
