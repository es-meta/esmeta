"use strict";
Reflect . preventExtensions ( 0 ) ; 
