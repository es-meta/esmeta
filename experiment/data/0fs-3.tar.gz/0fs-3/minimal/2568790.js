"use strict";
[ x => x , ] . toSorted ( ) ; 
