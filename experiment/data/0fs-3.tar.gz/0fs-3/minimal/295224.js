"use strict";
Array . from ( 0 , x => x ) ; 
