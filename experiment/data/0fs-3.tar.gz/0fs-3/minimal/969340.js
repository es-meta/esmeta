"use strict";
Object . assign ( 0 , null ) ; 
