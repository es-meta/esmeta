"use strict";
Iterator . prototype . take ( 1n ) ; 
