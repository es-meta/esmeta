"use strict";
Reflect . construct ( 0 ) ; 
