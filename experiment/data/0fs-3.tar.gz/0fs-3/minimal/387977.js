"use strict";
[ ] . filter ( ) ; 
