"use strict";
String . fromCodePoint ( 1n ) ; 
