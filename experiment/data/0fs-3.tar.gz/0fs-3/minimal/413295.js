"use strict";
Number . isSafeInteger ( 0 ) ; 
