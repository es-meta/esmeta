"use strict";
`` . toLocaleString . call ( ) ; 
