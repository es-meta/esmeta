"use strict";
[ , x => x ] . splice ( x => x ) ; 
