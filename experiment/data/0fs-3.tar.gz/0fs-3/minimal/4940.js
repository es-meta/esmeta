"use strict";
Reflect.apply.call(0);
