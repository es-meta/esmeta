"use strict";
Object . seal ( [ ] ) ; 
