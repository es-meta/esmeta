"use strict";
String . prototype . endsWith ( 0 , 0n ) ; 
