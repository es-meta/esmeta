"use strict";
new Set ( { [ Symbol . iterator ] : x => [ ] } ) ; 
