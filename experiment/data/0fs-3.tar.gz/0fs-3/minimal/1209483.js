"use strict";
[ ] . lastIndexOf ( '' ) ; 
