"use strict";
'' . propertyIsEnumerable ( 0 ) ; 
