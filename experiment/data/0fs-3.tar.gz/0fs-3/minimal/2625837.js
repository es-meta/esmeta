"use strict";
String . prototype . replace ( '' , `` ) ; ; 
