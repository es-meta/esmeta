"use strict";
Array . from . call ( function x ( [ ] , ) { } , '' ) ; 
