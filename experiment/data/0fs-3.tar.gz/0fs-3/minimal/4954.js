"use strict";
Reflect.construct.call(0, 0, 0, 0);
