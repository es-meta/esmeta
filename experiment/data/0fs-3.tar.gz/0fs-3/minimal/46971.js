"use strict";
Number . prototype . toFixed . call ( ) ; 
