"use strict";
Math . atan ( 1 ) ; 
