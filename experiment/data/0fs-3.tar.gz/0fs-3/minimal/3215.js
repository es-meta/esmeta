"use strict";
new Float64Array(0);
