"use strict";
[ ] . toReversed ( ) ; 
