"use strict";
new SyntaxError(0, 0);
