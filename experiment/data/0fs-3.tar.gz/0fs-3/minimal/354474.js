"use strict";
Number . isNaN ( 0 ) ; 
