"use strict";
true . toString . call ( ) ; 
