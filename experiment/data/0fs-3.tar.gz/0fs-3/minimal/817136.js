"use strict";
true . valueOf . call ( 0 ) ; 
