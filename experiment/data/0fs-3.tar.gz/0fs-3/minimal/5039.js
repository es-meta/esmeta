"use strict";
Reflect.ownKeys.call(0);
