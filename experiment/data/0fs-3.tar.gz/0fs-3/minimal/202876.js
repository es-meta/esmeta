"use strict";
String . fromCharCode ( 0 ) ; 
