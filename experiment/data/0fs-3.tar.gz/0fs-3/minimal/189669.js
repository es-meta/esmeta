"use strict";
Reflect . construct . call ( 0 , class { } , 0 , 0 ) ; 
