"use strict";
Math.exp.call(0);
