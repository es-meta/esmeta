"use strict";
Math . exp ( 0n ) ; 
