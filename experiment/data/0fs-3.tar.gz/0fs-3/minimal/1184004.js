"use strict";
String . prototype . startsWith ( 0 , 1n ) ; 
