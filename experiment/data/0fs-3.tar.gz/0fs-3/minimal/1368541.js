"use strict";
[ , ] . pop ( ) ; 
