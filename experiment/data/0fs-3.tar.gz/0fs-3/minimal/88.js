"use strict";
decodeURIComponent.call(0);
