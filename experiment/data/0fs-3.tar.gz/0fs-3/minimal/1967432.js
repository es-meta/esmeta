"use strict";
new Error ( { [ Symbol . toPrimitive ] : '' } ) ; 
