"use strict";
[ ] . shift . call ( x => x ) ; 
