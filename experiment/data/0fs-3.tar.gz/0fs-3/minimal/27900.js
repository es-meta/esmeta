"use strict";
new Int8Array ( 1n ) ; 
