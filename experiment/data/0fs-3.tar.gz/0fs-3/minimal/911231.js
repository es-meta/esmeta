"use strict";
Array . prototype . copyWithin ( 0 , 0 , 0n ) ; 
