"use strict";
Set.prototype.intersection.call(0, 0);
