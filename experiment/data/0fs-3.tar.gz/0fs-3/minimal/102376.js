"use strict";
( Object ( Int8Array ) ) . prototype . filter ( 0 ) ; 
