"use strict";
WeakMap.prototype.getOrInsertComputed.call(0, 0);
