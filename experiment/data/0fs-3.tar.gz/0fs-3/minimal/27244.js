"use strict";
new Uint8Array ( 0n ) ; 
