"use strict";
new Int32Array ( { [ Symbol . iterator ] : x => [ ] } ) ; 
