"use strict";
Promise . all ( '' ) ; 
