"use strict";
Object . defineProperty ( x => x , `` , { set : x => x } ) ; 
