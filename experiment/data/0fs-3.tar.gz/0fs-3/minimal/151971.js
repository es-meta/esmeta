"use strict";
'' . endsWith ( '' ) ; 
