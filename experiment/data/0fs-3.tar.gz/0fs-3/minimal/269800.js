"use strict";
false . toString ( ) ; 
