"use strict";
this . __lookupSetter__ ( ) ; 
