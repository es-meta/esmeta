"use strict";
Array . fromAsync ( 0 , x => x ) ; 
