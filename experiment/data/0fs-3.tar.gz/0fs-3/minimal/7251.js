"use strict";
new Map ( '' ) ; 
