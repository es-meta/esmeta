"use strict";
Number . prototype . toExponential . call ( 1 ) ; 
