"use strict";
Array . of . call ( function ( [ ] ) { } ) ; 
