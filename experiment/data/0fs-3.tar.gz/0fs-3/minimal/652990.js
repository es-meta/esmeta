"use strict";
( Object ( Int8Array ) ) . prototype . set ( 0 , 0 ) ; 
