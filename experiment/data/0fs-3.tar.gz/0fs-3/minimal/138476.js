"use strict";
Iterator . prototype . take ( 0 ) ; 
