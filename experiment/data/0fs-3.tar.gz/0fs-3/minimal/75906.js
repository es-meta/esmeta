"use strict";
'' . slice ( ) ; 
