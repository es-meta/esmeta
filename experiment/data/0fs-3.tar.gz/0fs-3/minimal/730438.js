"use strict";
( Object ( Int8Array ) ) . prototype . keys ( ) ; 
