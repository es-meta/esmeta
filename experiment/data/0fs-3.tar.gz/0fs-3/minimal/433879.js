"use strict";
Object . seal ( { get x ( ) { } } ) ; 
