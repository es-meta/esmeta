"use strict";
( Object ( Int8Array ) ) . of . call ( 0 ) ; 
