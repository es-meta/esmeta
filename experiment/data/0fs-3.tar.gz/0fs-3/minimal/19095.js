"use strict";
new Map ( [ x => x ] ) ; 
