"use strict";
Array.prototype.toSorted.call(0, 0);
