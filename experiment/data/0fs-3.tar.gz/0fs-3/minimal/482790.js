"use strict";
[ ] . some ( x => x ) ; 
