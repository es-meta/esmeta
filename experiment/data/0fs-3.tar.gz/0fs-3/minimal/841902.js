"use strict";
[ ] . splice ( x => x ) ; 
