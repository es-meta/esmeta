"use strict";
var x = '' ; for ( x in x ) ; 
