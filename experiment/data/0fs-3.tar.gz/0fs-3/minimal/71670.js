"use strict";
Reflect . defineProperty ( 0 ) ; 
