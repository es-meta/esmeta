"use strict";
BigInt . asIntN ( 0 , '' ) ; 
