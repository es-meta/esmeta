"use strict";
Number . isInteger ( 0 ) ; 
