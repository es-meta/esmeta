"use strict";
Symbol . for ( 0 ) ; 
