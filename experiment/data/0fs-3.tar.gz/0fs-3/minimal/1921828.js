"use strict";
[ ] . findLast ( ) ; 
