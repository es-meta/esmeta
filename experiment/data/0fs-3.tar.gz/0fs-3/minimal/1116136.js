"use strict";
Math . clz32 ( 1n ) ; 
