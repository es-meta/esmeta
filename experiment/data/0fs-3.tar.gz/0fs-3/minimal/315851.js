"use strict";
[ ] . map ( `` ) ; 
