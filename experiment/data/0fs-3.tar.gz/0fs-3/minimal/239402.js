"use strict";
parseFloat ( ) ; 
