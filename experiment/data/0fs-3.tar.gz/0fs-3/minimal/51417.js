"use strict";
Object . getOwnPropertyNames ( 0 ) ; 
