"use strict";
Array . fromAsync ( async function * ( ) { x ; } `` ) ; 
