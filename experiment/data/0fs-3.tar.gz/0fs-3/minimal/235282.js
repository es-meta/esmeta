"use strict";
[ ] . toString . call ( 0 ) ; 
