"use strict";
[ ] . unshift . call ( ) ; 
