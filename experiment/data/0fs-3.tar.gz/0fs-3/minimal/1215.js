"use strict";
Math.min.call(0, 0, 0);
