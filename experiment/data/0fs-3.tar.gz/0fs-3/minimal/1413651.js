"use strict";
`` . replaceAll ( `` , x => x ) ; 
