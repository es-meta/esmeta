"use strict";
Math . asin ( 0n ) ; 
