"use strict";
Math . log ( ~ typeof x ) ; 
