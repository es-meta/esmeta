"use strict";
Math . acosh ( 42 ) ; 
