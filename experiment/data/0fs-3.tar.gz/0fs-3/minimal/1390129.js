"use strict";
[ ] . reduce ( ) ; 
