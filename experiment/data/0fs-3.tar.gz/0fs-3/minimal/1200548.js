"use strict";
String . fromCharCode ( 0 , ~ typeof x ) ; 
