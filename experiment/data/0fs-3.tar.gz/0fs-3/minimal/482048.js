"use strict";
[ ] . copyWithin ( x => x ) ; 
