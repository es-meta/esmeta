"use strict";
'' . __lookupSetter__ ( { [ Symbol . toPrimitive ] : ( ) => x } ) ; 
