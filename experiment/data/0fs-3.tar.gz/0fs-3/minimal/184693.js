"use strict";
Math . floor ( 0 ) ; 
