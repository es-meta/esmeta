"use strict";
isNaN ( null ) ; 
