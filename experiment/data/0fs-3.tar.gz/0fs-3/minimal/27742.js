"use strict";
Math . abs ( ~ typeof x ) ; 
