"use strict";
( Object ( Int8Array ) ) . prototype . findLastIndex ( 0 , 0 ) ; 
