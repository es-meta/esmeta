"use strict";
Math . sign ( 1n ) ; 
