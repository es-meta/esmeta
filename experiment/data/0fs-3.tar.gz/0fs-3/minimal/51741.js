"use strict";
Number . prototype . toFixed . call ( ~ typeof x ) ; 
