"use strict";
'' . __defineGetter__ ( 0 , 0 ) ; 
