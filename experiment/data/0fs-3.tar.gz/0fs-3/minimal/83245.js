"use strict";
Function ( ) ; 
