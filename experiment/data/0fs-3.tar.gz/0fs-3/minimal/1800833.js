"use strict";
new Map ( function * ( ) { yield ; } `` ) ; 
