"use strict";
String . prototype . toWellFormed . call ( ) ; 
