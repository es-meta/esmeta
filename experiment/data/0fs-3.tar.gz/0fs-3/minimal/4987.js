"use strict";
Reflect.get.call(0, 0, 0, 0);
