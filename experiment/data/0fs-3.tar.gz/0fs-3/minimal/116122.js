"use strict";
Promise . resolve . call ( { } ) ; 
