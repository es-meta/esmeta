"use strict";
encodeURI.call(0);
