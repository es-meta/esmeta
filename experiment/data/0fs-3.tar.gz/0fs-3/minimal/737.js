"use strict";
new EvalError(0, 0);
