"use strict";
[ ] . indexOf ( `` ) ; 
