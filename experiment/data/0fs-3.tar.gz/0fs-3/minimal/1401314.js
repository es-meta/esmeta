"use strict";
; Number . prototype . toFixed ( ~ 0 ) ; 
