"use strict";
Array . prototype . splice . call ( typeof x , 0 , 0 , 0 ) ; 
