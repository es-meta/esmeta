"use strict";
[ ] . toString . call ( x => x ) ; 
