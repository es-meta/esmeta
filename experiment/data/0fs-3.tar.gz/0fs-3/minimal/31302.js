"use strict";
Error . prototype . toString . call ( { } ) ; 
