"use strict";
var x = {}; Object.setPrototypeOf(x, ArrayBuffer.prototype); x.detached;
