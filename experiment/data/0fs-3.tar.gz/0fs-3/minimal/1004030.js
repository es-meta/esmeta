"use strict";
Number . prototype . toPrecision ( 0n ) ; 
