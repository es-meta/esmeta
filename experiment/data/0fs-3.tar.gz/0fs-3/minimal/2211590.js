"use strict";
Object . seal ( { 1 : 0 } ) ; 
