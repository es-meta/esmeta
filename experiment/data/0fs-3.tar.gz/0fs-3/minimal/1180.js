"use strict";
Math.log10.call(0);
