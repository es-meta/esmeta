"use strict";
Math . atan2 ( 1 , ~ typeof x ) ; 
