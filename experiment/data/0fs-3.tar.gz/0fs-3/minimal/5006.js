"use strict";
Reflect.getPrototypeOf.call(0);
