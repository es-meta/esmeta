"use strict";
Math.atan2.call(0, 0, 0);
